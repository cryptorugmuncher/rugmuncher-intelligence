--
-- PostgreSQL database dump
--

\restrict IxEfzzDWRWMK8dTs3YfXUNth6wmW8CNjkazBGwaGoVzqz2PSNQZIFFQGWyomfwD

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aggregate_routing_analytics(); Type: FUNCTION; Schema: public; Owner: rmi_user
--

CREATE FUNCTION public.aggregate_routing_analytics() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO routing_analytics_hourly (
        hour, routing_group_id, endpoint_id,
        total_requests, successful_requests, failed_requests,
        avg_latency_ms, min_latency_ms, max_latency_ms
    )
    SELECT 
        DATE_TRUNC('hour', timestamp) as hour,
        routing_group_id,
        endpoint_id,
        COUNT(*),
        SUM(CASE WHEN success THEN 1 ELSE 0 END),
        SUM(CASE WHEN NOT success THEN 1 ELSE 0 END),
        AVG(latency_ms),
        MIN(latency_ms),
        MAX(latency_ms)
    FROM route_requests
    WHERE timestamp > NOW() - INTERVAL '1 hour'
    GROUP BY DATE_TRUNC('hour', timestamp), routing_group_id, endpoint_id
    ON CONFLICT (hour, routing_group_id, endpoint_id) DO UPDATE SET
        total_requests = EXCLUDED.total_requests,
        successful_requests = EXCLUDED.successful_requests,
        failed_requests = EXCLUDED.failed_requests,
        avg_latency_ms = EXCLUDED.avg_latency_ms,
        min_latency_ms = EXCLUDED.min_latency_ms,
        max_latency_ms = EXCLUDED.max_latency_ms;
END;
$$;


ALTER FUNCTION public.aggregate_routing_analytics() OWNER TO rmi_user;

--
-- Name: award_badge(uuid, uuid); Type: FUNCTION; Schema: public; Owner: rmi_user
--

CREATE FUNCTION public.award_badge(p_user_id uuid, p_badge_id uuid) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_xp INTEGER;
BEGIN
    -- Check if already has badge
    IF EXISTS (SELECT 1 FROM user_badges WHERE user_id = p_user_id AND badge_id = p_badge_id) THEN
        RETURN FALSE;
    END IF;
    
    -- Get XP value
    SELECT xp_value INTO v_xp FROM badges WHERE id = p_badge_id;
    
    -- Award badge
    INSERT INTO user_badges (user_id, badge_id, earned_via)
    VALUES (p_user_id, p_badge_id, 'automatic');
    
    -- Log unlock
    INSERT INTO badge_unlock_log (user_id, badge_id)
    VALUES (p_user_id, p_badge_id);
    
    -- Update user stats with XP
    UPDATE user_stats 
    SET total_xp = total_xp + v_xp,
        updated_at = NOW()
    WHERE user_id = p_user_id;
    
    RETURN TRUE;
END;
$$;


ALTER FUNCTION public.award_badge(p_user_id uuid, p_badge_id uuid) OWNER TO rmi_user;

--
-- Name: check_and_award_badges(uuid); Type: FUNCTION; Schema: public; Owner: rmi_user
--

CREATE FUNCTION public.check_and_award_badges(p_user_id uuid) RETURNS TABLE(badge_id uuid, badge_name character varying, badge_emoji character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT b.id, b.name, b.emoji
    FROM badges b
    WHERE NOT EXISTS (
        SELECT 1 FROM user_badges ub 
        WHERE ub.user_id = p_user_id AND ub.badge_id = b.id
    )
    AND (
        -- Check conditions based on badge type
        (b.condition_type = 'post_count' AND (
            SELECT post_count >= (b.condition_config->>'value')::INTEGER 
            FROM user_stats WHERE user_id = p_user_id
        ))
        OR
        (b.condition_type = 'comment_count' AND (
            SELECT comment_count >= (b.condition_config->>'value')::INTEGER 
            FROM user_stats WHERE user_id = p_user_id
        ))
        OR
        (b.condition_type = 'streak' AND (
            SELECT current_streak >= (b.condition_config->>'value')::INTEGER 
            FROM user_streaks WHERE user_id = p_user_id
        ))
        OR
        (b.condition_type = 'verified_alpha' AND (
            SELECT verified_alpha_count >= (b.condition_config->>'value')::INTEGER 
            FROM user_stats WHERE user_id = p_user_id
        ))
        OR
        (b.condition_type = 'follower_count' AND (
            SELECT follower_count >= (b.condition_config->>'value')::INTEGER 
            FROM user_stats WHERE user_id = p_user_id
        ))
        OR
        (b.condition_type = 'total_upvotes' AND (
            SELECT total_upvotes_received >= (b.condition_config->>'value')::INTEGER 
            FROM user_stats WHERE user_id = p_user_id
        ))
        OR
        (b.condition_type = 'verified_scam_reports' AND (
            SELECT verified_scam_reports >= (b.condition_config->>'value')::INTEGER 
            FROM user_stats WHERE user_id = p_user_id
        ))
    );
END;
$$;


ALTER FUNCTION public.check_and_award_badges(p_user_id uuid) OWNER TO rmi_user;

--
-- Name: get_revenue(date, date, character varying); Type: FUNCTION; Schema: public; Owner: rmi_user
--

CREATE FUNCTION public.get_revenue(start_date date, end_date date, p_product character varying DEFAULT NULL::character varying) RETURNS TABLE(date date, product character varying, revenue numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        DATE(t.created_at),
        t.product::VARCHAR,
        SUM(t.amount)::DECIMAL
    FROM transactions t
    WHERE t.status = 'completed'
        AND DATE(t.created_at) BETWEEN start_date AND end_date
        AND (p_product IS NULL OR t.product = p_product)
    GROUP BY DATE(t.created_at), t.product;
END;
$$;


ALTER FUNCTION public.get_revenue(start_date date, end_date date, p_product character varying) OWNER TO rmi_user;

--
-- Name: increment_api_calls(uuid); Type: FUNCTION; Schema: public; Owner: rmi_user
--

CREATE FUNCTION public.increment_api_calls(user_uuid uuid) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE users 
    SET total_api_calls = total_api_calls + 1 
    WHERE id = user_uuid;
END;
$$;


ALTER FUNCTION public.increment_api_calls(user_uuid uuid) OWNER TO rmi_user;

--
-- Name: update_badge_progress(uuid, character varying, integer); Type: FUNCTION; Schema: public; Owner: rmi_user
--

CREATE FUNCTION public.update_badge_progress(p_user_id uuid, p_badge_id character varying, p_current_value integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_badge UUID;
    v_target INTEGER;
    v_progress DECIMAL(5,2);
BEGIN
    -- Get badge details
    SELECT id, (condition_config->>'value')::INTEGER 
    INTO v_badge, v_target
    FROM badges 
    WHERE badge_id = p_badge_id;
    
    IF v_badge IS NULL THEN
        RETURN;
    END IF;
    
    -- Calculate progress
    v_progress := LEAST(100, (p_current_value::DECIMAL / v_target) * 100);
    
    -- Insert or update progress
    INSERT INTO badge_progress (user_id, badge_id, current_value, target_value, progress_percentage)
    VALUES (p_user_id, v_badge, p_current_value, v_target, v_progress)
    ON CONFLICT (user_id, badge_id) 
    DO UPDATE SET 
        current_value = p_current_value,
        progress_percentage = v_progress,
        last_updated = NOW();
END;
$$;


ALTER FUNCTION public.update_badge_progress(p_user_id uuid, p_badge_id character varying, p_current_value integer) OWNER TO rmi_user;

--
-- Name: update_post_comment_count(); Type: FUNCTION; Schema: public; Owner: rmi_user
--

CREATE FUNCTION public.update_post_comment_count() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' AND NEW.is_deleted = FALSE THEN
        UPDATE public.forum_posts SET comment_count = comment_count + 1 WHERE id = NEW.post_id;
    ELSIF TG_OP = 'UPDATE' AND OLD.is_deleted = FALSE AND NEW.is_deleted = TRUE THEN
        UPDATE public.forum_posts SET comment_count = comment_count - 1 WHERE id = NEW.post_id;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_post_comment_count() OWNER TO rmi_user;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: rmi_user
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO rmi_user;

--
-- Name: update_user_streak(uuid); Type: FUNCTION; Schema: public; Owner: rmi_user
--

CREATE FUNCTION public.update_user_streak(p_user_id uuid) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_last_activity DATE;
    v_current_streak INTEGER;
    v_new_streak INTEGER;
BEGIN
    -- Get current streak info
    SELECT last_activity_date, current_streak 
    INTO v_last_activity, v_current_streak
    FROM user_streaks 
    WHERE user_id = p_user_id;
    
    -- If first activity
    IF v_last_activity IS NULL THEN
        INSERT INTO user_streaks (user_id, current_streak, longest_streak, streak_start_date, last_activity_date)
        VALUES (p_user_id, 1, 1, CURRENT_DATE, CURRENT_DATE);
        RETURN 1;
    END IF;
    
    -- Check if already active today
    IF v_last_activity = CURRENT_DATE THEN
        RETURN v_current_streak;
    END IF;
    
    -- Check if consecutive day
    IF v_last_activity = CURRENT_DATE - 1 THEN
        v_new_streak := v_current_streak + 1;
    ELSE
        v_new_streak := 1; -- Streak broken
    END IF;
    
    -- Update streak
    UPDATE user_streaks
    SET current_streak = v_new_streak,
        longest_streak = GREATEST(longest_streak, v_new_streak),
        last_activity_date = CURRENT_DATE,
        total_days_active = total_days_active + 1,
        streak_start_date = CASE WHEN v_new_streak = 1 THEN CURRENT_DATE ELSE streak_start_date END,
        updated_at = NOW()
    WHERE user_id = p_user_id;
    
    -- Update user_stats with new streak
    UPDATE user_stats
    SET current_streak = v_new_streak,
        longest_streak = GREATEST(longest_streak, v_new_streak),
        last_post_date = CURRENT_DATE
    WHERE user_id = p_user_id;
    
    RETURN v_new_streak;
END;
$$;


ALTER FUNCTION public.update_user_streak(p_user_id uuid) OWNER TO rmi_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_logs; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.access_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    wallet_id uuid,
    tx_request_id uuid,
    action character varying(100) NOT NULL,
    performed_by uuid,
    ip_address inet,
    user_agent text,
    device_fingerprint character varying(255),
    geo_location character varying(255),
    auth_method character varying(50) DEFAULT 'jwt'::character varying,
    success boolean NOT NULL,
    failure_reason text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.access_logs OWNER TO rmi_user;

--
-- Name: routing_alerts; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.routing_alerts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    severity character varying(50) NOT NULL,
    component_id uuid,
    component_type character varying(50),
    endpoint_id uuid,
    routing_group_id uuid,
    alert_type character varying(50) NOT NULL,
    metrics jsonb DEFAULT '{}'::jsonb,
    suggested_action text,
    status character varying(50) DEFAULT 'open'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    acknowledged_at timestamp with time zone,
    acknowledged_by uuid,
    resolved_at timestamp with time zone,
    resolved_by uuid,
    resolution_notes text,
    auto_resolved boolean DEFAULT false,
    notifications_sent jsonb DEFAULT '[]'::jsonb,
    CONSTRAINT routing_alerts_alert_type_check CHECK (((alert_type)::text = ANY ((ARRAY['endpoint_down'::character varying, 'endpoint_degraded'::character varying, 'rate_limited'::character varying, 'banned'::character varying, 'failover_triggered'::character varying, 'auto_provisioned'::character varying, 'high_error_rate'::character varying, 'latency_spike'::character varying, 'certificate_expiring'::character varying, 'security_incident'::character varying])::text[]))),
    CONSTRAINT routing_alerts_severity_check CHECK (((severity)::text = ANY ((ARRAY['critical'::character varying, 'high'::character varying, 'medium'::character varying, 'low'::character varying, 'info'::character varying])::text[]))),
    CONSTRAINT routing_alerts_status_check CHECK (((status)::text = ANY ((ARRAY['open'::character varying, 'acknowledged'::character varying, 'resolved'::character varying, 'ignored'::character varying])::text[])))
);


ALTER TABLE public.routing_alerts OWNER TO rmi_user;

--
-- Name: active_alerts_summary; Type: VIEW; Schema: public; Owner: rmi_user
--

CREATE VIEW public.active_alerts_summary AS
 SELECT severity,
    alert_type,
    component_type,
    count(*) AS count,
    min(created_at) AS oldest_alert
   FROM public.routing_alerts
  WHERE ((status)::text = ANY ((ARRAY['open'::character varying, 'acknowledged'::character varying])::text[]))
  GROUP BY severity, alert_type, component_type;


ALTER VIEW public.active_alerts_summary OWNER TO rmi_user;

--
-- Name: admin_logs; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.admin_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    admin_id uuid NOT NULL,
    action character varying(100) NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id character varying(255) NOT NULL,
    details jsonb DEFAULT '{}'::jsonb,
    reason text,
    ip_address inet,
    user_agent text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.admin_logs OWNER TO rmi_user;

--
-- Name: admin_recovery_keys; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.admin_recovery_keys (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    key_shares jsonb DEFAULT '[]'::jsonb,
    last_verified timestamp without time zone DEFAULT now(),
    recovery_procedures jsonb DEFAULT '[]'::jsonb,
    requires_physical_presence boolean DEFAULT true,
    requires_multiple_admins integer DEFAULT 2,
    is_active boolean DEFAULT true,
    never_expires boolean DEFAULT true,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.admin_recovery_keys OWNER TO rmi_user;

--
-- Name: admin_recovery_requests; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.admin_recovery_requests (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    reason text NOT NULL,
    initiated_by uuid,
    status character varying(50) DEFAULT 'pending_verification'::character varying,
    requires_physical_presence boolean DEFAULT true,
    requires_multiple_admins integer DEFAULT 2,
    verification_steps jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone
);


ALTER TABLE public.admin_recovery_requests OWNER TO rmi_user;

--
-- Name: ai_provider_health; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.ai_provider_health (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    provider_name character varying(100) NOT NULL,
    status character varying(20) DEFAULT 'healthy'::character varying,
    last_check timestamp without time zone DEFAULT now(),
    consecutive_failures integer DEFAULT 0,
    avg_response_time_ms integer,
    success_rate numeric(5,2) DEFAULT 100.00
);


ALTER TABLE public.ai_provider_health OWNER TO rmi_user;

--
-- Name: ai_provider_usage; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.ai_provider_usage (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    provider_name character varying(100) NOT NULL,
    date date DEFAULT CURRENT_DATE NOT NULL,
    requests_count integer DEFAULT 0,
    tokens_used integer DEFAULT 0,
    cost_usd numeric(10,6) DEFAULT 0
);


ALTER TABLE public.ai_provider_usage OWNER TO rmi_user;

--
-- Name: ai_request_log; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.ai_request_log (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    provider_name character varying(100) NOT NULL,
    model_name character varying(100),
    task_type character varying(50),
    request_time timestamp without time zone DEFAULT now(),
    response_time_ms integer,
    tokens_input integer,
    tokens_output integer,
    cost_usd numeric(10,6),
    success boolean DEFAULT true,
    error_message text
);


ALTER TABLE public.ai_request_log OWNER TO rmi_user;

--
-- Name: ai_website_requests; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.ai_website_requests (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    project_id uuid,
    request_type character varying(50) NOT NULL,
    description text NOT NULL,
    target_audience text,
    tone character varying(50) DEFAULT 'professional'::character varying,
    target_page_id uuid,
    target_component_id uuid,
    status character varying(50) DEFAULT 'pending'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    created_by uuid
);


ALTER TABLE public.ai_website_requests OWNER TO rmi_user;

--
-- Name: ai_website_results; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.ai_website_results (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    request_id uuid,
    generated_components jsonb DEFAULT '[]'::jsonb,
    design_rationale text,
    seo_suggestions jsonb DEFAULT '[]'::jsonb,
    improvement_suggestions jsonb DEFAULT '[]'::jsonb,
    status character varying(50),
    errors jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ai_website_results OWNER TO rmi_user;

--
-- Name: airdrop_eligible_wallets; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.airdrop_eligible_wallets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    wallet_address character varying(255) NOT NULL,
    chain character varying(50) DEFAULT 'solana'::character varying,
    held_crm_v1 boolean DEFAULT false,
    held_amount numeric(20,9),
    snapshot_date timestamp with time zone,
    verification_tx_hash character varying(255),
    verified_at timestamp with time zone,
    reward_tier character varying(20) DEFAULT 'standard'::character varying,
    base_reward_amount numeric(20,9) DEFAULT 0,
    bonus_amount numeric(20,9) DEFAULT 0,
    claimed boolean DEFAULT false,
    claimed_at timestamp with time zone,
    claimed_by uuid,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.airdrop_eligible_wallets OWNER TO rmi_user;

--
-- Name: api_credential_updates; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.api_credential_updates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    credential_id uuid,
    service_name character varying(255) NOT NULL,
    old_credential_hash character varying(64),
    new_credential_hash character varying(64),
    rollout_status character varying(50) DEFAULT 'pending'::character varying,
    rollout_percentage integer DEFAULT 0,
    affected_services jsonb DEFAULT '[]'::jsonb,
    updated_services jsonb DEFAULT '[]'::jsonb,
    failed_services jsonb DEFAULT '[]'::jsonb,
    can_rollback boolean DEFAULT true,
    rollback_window_minutes integer DEFAULT 60,
    initiated_by uuid,
    initiated_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone
);


ALTER TABLE public.api_credential_updates OWNER TO rmi_user;

--
-- Name: api_endpoints; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.api_endpoints (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    provider_type character varying(50) NOT NULL,
    base_url text NOT NULL,
    description text,
    region character varying(50),
    priority integer DEFAULT 1,
    weight integer DEFAULT 1,
    rate_limit_requests integer DEFAULT 100,
    rate_limit_window integer DEFAULT 60,
    rate_limit_strategy character varying(50) DEFAULT 'exponential_backoff'::character varying,
    health_check_enabled boolean DEFAULT true,
    health_check_interval integer DEFAULT 30,
    health_check_endpoint character varying(255),
    health_check_timeout integer DEFAULT 10,
    failover_enabled boolean DEFAULT true,
    failover_threshold integer DEFAULT 3,
    auto_provision_backup boolean DEFAULT false,
    requires_proxy boolean DEFAULT false,
    proxy_rotation boolean DEFAULT false,
    fingerprint_randomization boolean DEFAULT false,
    credential_id uuid,
    status character varying(50) DEFAULT 'healthy'::character varying,
    current_latency_ms numeric(10,2) DEFAULT 0,
    uptime_percentage numeric(5,2) DEFAULT 100.0,
    last_check_at timestamp with time zone,
    last_success_at timestamp with time zone,
    last_failure_at timestamp with time zone,
    failure_count integer DEFAULT 0,
    success_count integer DEFAULT 0,
    current_requests_remaining integer DEFAULT 100,
    rate_limit_reset_at timestamp with time zone,
    is_backup boolean DEFAULT false,
    parent_endpoint_id uuid,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT api_endpoints_priority_check CHECK (((priority >= 1) AND (priority <= 10))),
    CONSTRAINT api_endpoints_provider_type_check CHECK (((provider_type)::text = ANY ((ARRAY['data_provider'::character varying, 'rpc_node'::character varying, 'telegram'::character varying, 'twitter'::character varying, 'webhook'::character varying, 'ai_service'::character varying, 'storage'::character varying, 'analytics'::character varying, 'payment'::character varying, 'other'::character varying])::text[]))),
    CONSTRAINT api_endpoints_status_check CHECK (((status)::text = ANY ((ARRAY['healthy'::character varying, 'degraded'::character varying, 'down'::character varying, 'banned'::character varying, 'rate_limited'::character varying, 'maintenance'::character varying])::text[]))),
    CONSTRAINT api_endpoints_weight_check CHECK (((weight >= 1) AND (weight <= 100)))
);


ALTER TABLE public.api_endpoints OWNER TO rmi_user;

--
-- Name: api_logs; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.api_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    endpoint character varying(500) NOT NULL,
    method character varying(10) NOT NULL,
    product character varying(50),
    status_code integer,
    response_time_ms integer,
    rate_limit_remaining integer,
    rate_limit_reset timestamp without time zone,
    ip_address inet,
    user_agent text,
    request_size_bytes integer,
    response_size_bytes integer,
    error_message text,
    error_code character varying(100),
    cache_hit boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT valid_method CHECK (((method)::text = ANY ((ARRAY['GET'::character varying, 'POST'::character varying, 'PUT'::character varying, 'PATCH'::character varying, 'DELETE'::character varying])::text[])))
);


ALTER TABLE public.api_logs OWNER TO rmi_user;

--
-- Name: app_suggestions; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.app_suggestions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    category character varying(50) NOT NULL,
    target_audience jsonb DEFAULT '[]'::jsonb,
    market_size character varying(20),
    competition_level character varying(20),
    development_cost_low numeric(12,2),
    development_cost_high numeric(12,2),
    monthly_revenue_potential numeric(12,2),
    time_to_revenue_months integer,
    roi_estimate numeric(8,2),
    complexity character varying(20),
    required_integrations jsonb DEFAULT '[]'::jsonb,
    tech_stack jsonb DEFAULT '[]'::jsonb,
    key_features jsonb DEFAULT '[]'::jsonb,
    mvp_features jsonb DEFAULT '[]'::jsonb,
    priority_score numeric(5,2),
    strategic_value character varying(20),
    status character varying(50) DEFAULT 'suggested'::character varying,
    similar_apps jsonb DEFAULT '[]'::jsonb,
    research_links jsonb DEFAULT '[]'::jsonb,
    suggested_at timestamp without time zone DEFAULT now(),
    suggested_by character varying(100) DEFAULT 'system'::character varying
);


ALTER TABLE public.app_suggestions OWNER TO rmi_user;

--
-- Name: approval_policies; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.approval_policies (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    policy_name character varying(255) NOT NULL,
    wallet_types jsonb DEFAULT '[]'::jsonb,
    chains jsonb DEFAULT '[]'::jsonb,
    min_amount numeric(24,8) DEFAULT 0,
    max_amount numeric(24,8) DEFAULT 999999999,
    required_approvals integer DEFAULT 1,
    required_approvers jsonb DEFAULT '[]'::jsonb,
    require_different_devices boolean DEFAULT false,
    require_time_delay integer DEFAULT 0,
    risk_threshold integer DEFAULT 50,
    require_2fa boolean DEFAULT true,
    require_biometric boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.approval_policies OWNER TO rmi_user;

--
-- Name: auto_content_suggestions; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.auto_content_suggestions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    source_type character varying(50) NOT NULL,
    source_topic character varying(255),
    suggested_headline text NOT NULL,
    suggested_body text NOT NULL,
    suggested_hashtags jsonb DEFAULT '[]'::jsonb,
    suggested_cta text,
    recommended_platforms jsonb NOT NULL,
    recommended_time timestamp without time zone,
    recommended_narrative character varying(50),
    confidence_score integer DEFAULT 0,
    reasoning text,
    status character varying(50) DEFAULT 'pending'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    created_by character varying(50) DEFAULT 'ai'::character varying
);


ALTER TABLE public.auto_content_suggestions OWNER TO rmi_user;

--
-- Name: badge_categories; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.badge_categories (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    display_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.badge_categories OWNER TO rmi_user;

--
-- Name: badge_leaderboard; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.badge_leaderboard (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    badge_count integer DEFAULT 0,
    total_xp integer DEFAULT 0,
    legendary_badges integer DEFAULT 0,
    period character varying(20) DEFAULT 'all_time'::character varying NOT NULL,
    period_start date,
    period_end date,
    rank integer,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.badge_leaderboard OWNER TO rmi_user;

--
-- Name: badge_progress; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.badge_progress (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    badge_id uuid NOT NULL,
    current_value integer DEFAULT 0,
    target_value integer NOT NULL,
    progress_percentage numeric(5,2) DEFAULT 0,
    last_updated timestamp with time zone DEFAULT now()
);


ALTER TABLE public.badge_progress OWNER TO rmi_user;

--
-- Name: badge_unlock_log; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.badge_unlock_log (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    badge_id uuid NOT NULL,
    unlocked_at timestamp with time zone DEFAULT now(),
    notified boolean DEFAULT false,
    notification_seen_at timestamp with time zone,
    shared_to_twitter boolean DEFAULT false,
    shared_at timestamp with time zone
);


ALTER TABLE public.badge_unlock_log OWNER TO rmi_user;

--
-- Name: badges; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.badges (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    badge_id character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    emoji character varying(10) NOT NULL,
    description text NOT NULL,
    rarity character varying(20) NOT NULL,
    category_id uuid,
    condition_type character varying(50) NOT NULL,
    condition_config jsonb NOT NULL,
    xp_value integer DEFAULT 0,
    is_hidden boolean DEFAULT false,
    is_limited boolean DEFAULT false,
    limited_quantity integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT badges_rarity_check CHECK (((rarity)::text = ANY ((ARRAY['common'::character varying, 'uncommon'::character varying, 'rare'::character varying, 'epic'::character varying, 'legendary'::character varying, 'mythic'::character varying])::text[])))
);


ALTER TABLE public.badges OWNER TO rmi_user;

--
-- Name: ban_prevention_configs; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.ban_prevention_configs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) DEFAULT 'global'::character varying,
    jitter_requests boolean DEFAULT true,
    jitter_min_ms integer DEFAULT 100,
    jitter_max_ms integer DEFAULT 500,
    rotate_user_agents boolean DEFAULT true,
    user_agent_pool jsonb DEFAULT '[]'::jsonb,
    randomize_fingerprint boolean DEFAULT true,
    tls_fingerprints jsonb DEFAULT '[]'::jsonb,
    distribute_geographically boolean DEFAULT true,
    preferred_regions jsonb DEFAULT '["us-east", "eu-west", "ap-south"]'::jsonb,
    mimic_human_behavior boolean DEFAULT true,
    business_hours_only boolean DEFAULT false,
    random_session_duration boolean DEFAULT true,
    stay_below_limit_percentage numeric(5,2) DEFAULT 80.0,
    burst_protection boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.ban_prevention_configs OWNER TO rmi_user;

--
-- Name: bot_advisor_insights; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.bot_advisor_insights (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    category character varying(50) NOT NULL,
    priority character varying(20) NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    context jsonb DEFAULT '{}'::jsonb,
    data_points jsonb DEFAULT '[]'::jsonb,
    trend_direction character varying(20),
    confidence numeric(5,2),
    suggested_actions jsonb DEFAULT '[]'::jsonb,
    suggested_actions_detailed jsonb DEFAULT '[]'::jsonb,
    estimated_impact_usd numeric(12,2),
    estimated_impact_description text,
    status character varying(20) DEFAULT 'active'::character varying,
    acknowledged boolean DEFAULT false,
    acknowledged_by uuid,
    acknowledged_at timestamp without time zone,
    implemented boolean DEFAULT false,
    implemented_at timestamp without time zone,
    implementation_notes text,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT bot_advisor_insights_confidence_check CHECK (((confidence >= (0)::numeric) AND (confidence <= (100)::numeric))),
    CONSTRAINT valid_insight_category CHECK (((category)::text = ANY ((ARRAY['financial'::character varying, 'legal'::character varying, 'operational'::character varying, 'strategic'::character varying, 'technical'::character varying])::text[]))),
    CONSTRAINT valid_insight_priority CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying])::text[])))
);


ALTER TABLE public.bot_advisor_insights OWNER TO rmi_user;

--
-- Name: bot_logs; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.bot_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    platform character varying(50) NOT NULL,
    chat_id character varying(255),
    command character varying(100),
    command_args jsonb,
    response_text text,
    response_type character varying(50),
    processing_time_ms integer,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.bot_logs OWNER TO rmi_user;

--
-- Name: bot_protection_rules; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.bot_protection_rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    rule_name character varying(255) NOT NULL,
    patterns jsonb DEFAULT '[]'::jsonb,
    max_requests_per_minute integer DEFAULT 10,
    max_requests_per_hour integer DEFAULT 100,
    action_on_detect character varying(50) DEFAULT 'block'::character varying,
    auto_freeze boolean DEFAULT true,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.bot_protection_rules OWNER TO rmi_user;

--
-- Name: briefing_templates; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.briefing_templates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    enabled_sections jsonb DEFAULT '[]'::jsonb,
    custom_metrics jsonb DEFAULT '[]'::jsonb,
    alert_thresholds jsonb DEFAULT '{}'::jsonb,
    schedule character varying(50) DEFAULT 'daily'::character varying,
    delivery_time time without time zone,
    timezone character varying(50) DEFAULT 'UTC'::character varying,
    email_recipients jsonb DEFAULT '[]'::jsonb,
    webhook_url text,
    include_charts boolean DEFAULT true,
    include_raw_data boolean DEFAULT false,
    format character varying(20) DEFAULT 'html'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.briefing_templates OWNER TO rmi_user;

--
-- Name: chain_configs; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.chain_configs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    chain character varying(50) NOT NULL,
    rpc_endpoints jsonb DEFAULT '[]'::jsonb,
    chain_id integer,
    derivation_path character varying(100),
    address_prefix character varying(50),
    confirmation_blocks integer DEFAULT 6,
    max_gas_price numeric(18,8) DEFAULT 0,
    is_active boolean DEFAULT true
);


ALTER TABLE public.chain_configs OWNER TO rmi_user;

--
-- Name: comparison_items; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.comparison_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    aspect character varying(255) NOT NULL,
    llc_structure text NOT NULL,
    dao_structure text NOT NULL,
    changes_required jsonb DEFAULT '[]'::jsonb,
    estimated_impact text,
    cost_estimate numeric(12,2),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.comparison_items OWNER TO rmi_user;

--
-- Name: compliance_requirements; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.compliance_requirements (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    area character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    wyoming_statute character varying(255),
    legal_reference text,
    current_status character varying(50) DEFAULT 'not_started'::character varying,
    previous_status character varying(50),
    status_changed_at timestamp without time zone,
    requirements jsonb DEFAULT '[]'::jsonb,
    evidence_required jsonb DEFAULT '[]'::jsonb,
    evidence_submitted jsonb DEFAULT '[]'::jsonb,
    reviewed_by uuid,
    reviewed_at timestamp without time zone,
    issues_found jsonb DEFAULT '[]'::jsonb,
    remediation_plan text,
    remediation_deadline timestamp without time zone,
    priority character varying(50) DEFAULT 'medium'::character varying,
    is_blocker boolean DEFAULT false,
    fund_separation_verified boolean,
    commingling_detected boolean,
    commingling_details text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.compliance_requirements OWNER TO rmi_user;

--
-- Name: content_calendars; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.content_calendars (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone NOT NULL,
    content_ids jsonb DEFAULT '[]'::jsonb,
    narrative_distribution jsonb DEFAULT '{}'::jsonb,
    platform_distribution jsonb DEFAULT '{}'::jsonb,
    target_posts_per_day integer DEFAULT 3,
    target_engagement_rate numeric(5,2) DEFAULT 5.0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.content_calendars OWNER TO rmi_user;

--
-- Name: content_performance; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.content_performance (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    content_id uuid,
    platform character varying(50) NOT NULL,
    impressions integer DEFAULT 0,
    reach integer DEFAULT 0,
    engagements integer DEFAULT 0,
    engagement_rate numeric(5,2) DEFAULT 0,
    likes integer DEFAULT 0,
    comments integer DEFAULT 0,
    shares integer DEFAULT 0,
    clicks integer DEFAULT 0,
    saves integer DEFAULT 0,
    profile_visits integer DEFAULT 0,
    follows integer DEFAULT 0,
    top_locations jsonb DEFAULT '[]'::jsonb,
    age_distribution jsonb DEFAULT '{}'::jsonb,
    device_breakdown jsonb DEFAULT '{}'::jsonb,
    best_hour integer,
    peak_engagement_time timestamp without time zone,
    collected_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.content_performance OWNER TO rmi_user;

--
-- Name: content_pieces; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.content_pieces (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(255) NOT NULL,
    content_type character varying(50) NOT NULL,
    platforms jsonb NOT NULL,
    headline text NOT NULL,
    body_text text NOT NULL,
    hashtags jsonb DEFAULT '[]'::jsonb,
    mentions jsonb DEFAULT '[]'::jsonb,
    call_to_action text,
    images jsonb DEFAULT '[]'::jsonb,
    videos jsonb DEFAULT '[]'::jsonb,
    gifs jsonb DEFAULT '[]'::jsonb,
    links jsonb DEFAULT '[]'::jsonb,
    platform_versions jsonb DEFAULT '{}'::jsonb,
    narrative_focus character varying(50) NOT NULL,
    target_audience jsonb DEFAULT '[]'::jsonb,
    key_messages jsonb DEFAULT '[]'::jsonb,
    status character varying(50) DEFAULT 'draft'::character varying,
    priority integer DEFAULT 3,
    scheduled_for timestamp without time zone,
    timezone character varying(50) DEFAULT 'UTC'::character varying,
    auto_post boolean DEFAULT false,
    predicted_engagement integer DEFAULT 0,
    best_posting_time character varying(10),
    actual_engagement jsonb DEFAULT '{}'::jsonb,
    impressions integer DEFAULT 0,
    clicks integer DEFAULT 0,
    shares integer DEFAULT 0,
    likes integer DEFAULT 0,
    comments integer DEFAULT 0,
    tags jsonb DEFAULT '[]'::jsonb,
    campaign_id uuid,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by uuid,
    approved_by uuid,
    approved_at timestamp without time zone,
    published_at timestamp without time zone,
    CONSTRAINT valid_content_status CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'pending_review'::character varying, 'approved'::character varying, 'scheduled'::character varying, 'published'::character varying, 'failed'::character varying, 'archived'::character varying])::text[])))
);


ALTER TABLE public.content_pieces OWNER TO rmi_user;

--
-- Name: content_templates; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.content_templates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    template_name character varying(255) NOT NULL,
    content_type character varying(50) NOT NULL,
    narrative_focus character varying(50) NOT NULL,
    headline_template text NOT NULL,
    body_template text NOT NULL,
    cta_template text,
    variables jsonb DEFAULT '[]'::jsonb,
    example_fill jsonb DEFAULT '{}'::jsonb,
    platform_tips jsonb DEFAULT '{}'::jsonb,
    times_used integer DEFAULT 0,
    avg_engagement numeric(5,2) DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.content_templates OWNER TO rmi_user;

--
-- Name: contract_deployments; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.contract_deployments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    chain character varying(50) NOT NULL,
    contract_type character varying(50) NOT NULL,
    contract_address character varying(255),
    deployer_address character varying(255) NOT NULL,
    transaction_hash character varying(255),
    status character varying(50) DEFAULT 'pending'::character varying,
    deployment_log jsonb DEFAULT '[]'::jsonb,
    config jsonb NOT NULL,
    verified boolean DEFAULT false,
    verified_at timestamp without time zone,
    verification_source text,
    deployment_cost_eth numeric(18,8) DEFAULT 0,
    deployment_cost_usd numeric(12,2) DEFAULT 0,
    gas_used integer DEFAULT 0,
    explorer_url text,
    dexscreener_url text,
    dextools_url text,
    deployed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    deployed_by uuid,
    CONSTRAINT valid_deployment_status CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'pending'::character varying, 'deploying'::character varying, 'deployed'::character varying, 'verified'::character varying, 'failed'::character varying, 'paused'::character varying])::text[])))
);


ALTER TABLE public.contract_deployments OWNER TO rmi_user;

--
-- Name: contract_templates; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.contract_templates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    contract_type character varying(50) NOT NULL,
    chain character varying(50) NOT NULL,
    version character varying(20) NOT NULL,
    solidity_code text,
    bytecode text,
    abi jsonb,
    configurable_params jsonb DEFAULT '[]'::jsonb,
    default_params jsonb DEFAULT '{}'::jsonb,
    description text,
    audited boolean DEFAULT false,
    auditor character varying(255),
    audit_report_url text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.contract_templates OWNER TO rmi_user;

--
-- Name: credential_access_logs; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.credential_access_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    credential_id uuid,
    action character varying(100) NOT NULL,
    performed_by uuid,
    ip_address inet,
    user_agent text,
    device_fingerprint character varying(255),
    geo_location character varying(255),
    success boolean NOT NULL,
    failure_reason text,
    api_endpoint_called character varying(255),
    request_details jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.credential_access_logs OWNER TO rmi_user;

--
-- Name: credential_pool_credentials; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.credential_pool_credentials (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    pool_id uuid NOT NULL,
    credential_id uuid NOT NULL,
    is_active boolean DEFAULT true,
    usage_count integer DEFAULT 0,
    added_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.credential_pool_credentials OWNER TO rmi_user;

--
-- Name: credential_pools; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.credential_pools (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    provider_type character varying(50) NOT NULL,
    max_accounts integer DEFAULT 10,
    provision_trigger character varying(50) DEFAULT 'on_failure'::character varying,
    threshold_percentage numeric(5,2) DEFAULT 50.0,
    rotate_credentials boolean DEFAULT true,
    rotation_interval_days integer DEFAULT 30,
    auto_generate_emails boolean DEFAULT true,
    email_provider character varying(50) DEFAULT 'protonmail'::character varying,
    email_domain character varying(255),
    total_provisioned integer DEFAULT 0,
    last_provisioned_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT credential_pools_max_accounts_check CHECK (((max_accounts >= 1) AND (max_accounts <= 100))),
    CONSTRAINT credential_pools_provision_trigger_check CHECK (((provision_trigger)::text = ANY ((ARRAY['on_failure'::character varying, 'at_threshold'::character varying, 'manual_only'::character varying])::text[])))
);


ALTER TABLE public.credential_pools OWNER TO rmi_user;

--
-- Name: critical_alerts; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.critical_alerts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    alert_type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    details jsonb DEFAULT '{}'::jsonb,
    source_system character varying(100) NOT NULL,
    source_metric character varying(100),
    threshold_breached numeric(18,8),
    current_value numeric(18,8),
    status character varying(50) DEFAULT 'active'::character varying,
    acknowledged_by uuid,
    acknowledged_at timestamp without time zone,
    resolved_by uuid,
    resolved_at timestamp without time zone,
    escalation_level integer DEFAULT 1,
    escalated_at timestamp without time zone,
    recommended_actions jsonb DEFAULT '[]'::jsonb,
    actions_taken jsonb DEFAULT '[]'::jsonb,
    notifications_sent jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    expires_at timestamp without time zone,
    CONSTRAINT valid_alert_severity CHECK (((severity)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying, 'emergency'::character varying])::text[]))),
    CONSTRAINT valid_alert_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'acknowledged'::character varying, 'resolving'::character varying, 'resolved'::character varying])::text[])))
);


ALTER TABLE public.critical_alerts OWNER TO rmi_user;

--
-- Name: crm_holders; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.crm_holders (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    wallet_address character varying(255) NOT NULL,
    balance numeric(20,8) NOT NULL,
    balance_usd numeric(12,2),
    first_purchase_at timestamp without time zone,
    first_purchase_tx character varying(255),
    is_contract boolean DEFAULT false,
    exchange_name character varying(100),
    last_updated timestamp without time zone DEFAULT now(),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.crm_holders OWNER TO rmi_user;

--
-- Name: crm_staking; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.crm_staking (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    wallet_address character varying(255) NOT NULL,
    amount numeric(20,8) NOT NULL,
    tier character varying(50),
    rewards_earned numeric(20,8) DEFAULT 0,
    last_claim_at timestamp without time zone,
    status character varying(50) DEFAULT 'active'::character varying,
    unstake_requested_at timestamp without time zone,
    unstake_completes_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT valid_staking_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'unstaking'::character varying, 'completed'::character varying])::text[])))
);


ALTER TABLE public.crm_staking OWNER TO rmi_user;

--
-- Name: crm_v1_wallets; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.crm_v1_wallets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    wallet_address character varying(255) NOT NULL,
    chain character varying(50) NOT NULL,
    reported_balance numeric(24,8) DEFAULT 0 NOT NULL,
    reported_balance_usd numeric(12,2) DEFAULT 0 NOT NULL,
    transaction_count integer DEFAULT 0,
    first_seen timestamp without time zone,
    last_seen timestamp without time zone,
    status character varying(50) DEFAULT 'pending'::character varying,
    verification_notes text,
    verified_by uuid,
    verified_at timestamp without time zone,
    eligible_for_v2 boolean DEFAULT false,
    v2_allocation numeric(24,8) DEFAULT 0,
    v2_claimed boolean DEFAULT false,
    v2_claimed_at timestamp without time zone,
    tags jsonb DEFAULT '[]'::jsonb,
    risk_score integer DEFAULT 0,
    associations jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT crm_v1_wallets_risk_score_check CHECK (((risk_score >= 0) AND (risk_score <= 100))),
    CONSTRAINT valid_v1_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'verified'::character varying, 'disputed'::character varying, 'confirmed'::character varying, 'excluded'::character varying])::text[])))
);


ALTER TABLE public.crm_v1_wallets OWNER TO rmi_user;

--
-- Name: cross_checks; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.cross_checks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    wallet_id uuid,
    check_type character varying(50) NOT NULL,
    source character varying(255),
    data_hash character varying(64),
    verified boolean DEFAULT false,
    discrepancies jsonb DEFAULT '[]'::jsonb,
    confidence_score numeric(5,2),
    raw_data jsonb,
    checked_at timestamp without time zone DEFAULT now(),
    checked_by uuid,
    CONSTRAINT cross_checks_confidence_score_check CHECK (((confidence_score >= (0)::numeric) AND (confidence_score <= (100)::numeric)))
);


ALTER TABLE public.cross_checks OWNER TO rmi_user;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    product character varying(50) NOT NULL,
    transaction_type character varying(50) NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying,
    status character varying(50) DEFAULT 'pending'::character varying,
    tier character varying(50),
    billing_period character varying(20),
    scan_type character varying(100),
    wallet_address character varying(255),
    payment_provider character varying(50),
    provider_transaction_id character varying(255),
    description text,
    metadata jsonb DEFAULT '{}'::jsonb,
    refunded_at timestamp without time zone,
    refund_amount numeric(12,2),
    refund_reason text,
    created_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    CONSTRAINT valid_product CHECK (((product)::text = ANY ((ARRAY['munchmaps'::character varying, 'rugmunch_bot'::character varying, 'crm_v2'::character varying, 'investigation_platform'::character varying])::text[]))),
    CONSTRAINT valid_transaction_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'completed'::character varying, 'failed'::character varying, 'refunded'::character varying])::text[]))),
    CONSTRAINT valid_transaction_type CHECK (((transaction_type)::text = ANY ((ARRAY['subscription'::character varying, 'pay_per_scan'::character varying, 'api_usage'::character varying, 'professional_service'::character varying, 'enterprise_custom'::character varying, 'refund'::character varying])::text[])))
);


ALTER TABLE public.transactions OWNER TO rmi_user;

--
-- Name: daily_revenue_summary; Type: VIEW; Schema: public; Owner: rmi_user
--

CREATE VIEW public.daily_revenue_summary AS
 SELECT date(created_at) AS date,
    product,
    transaction_type,
    count(*) AS transaction_count,
    sum(amount) AS total_revenue,
    count(DISTINCT user_id) AS unique_customers
   FROM public.transactions
  WHERE ((status)::text = 'completed'::text)
  GROUP BY (date(created_at)), product, transaction_type;


ALTER VIEW public.daily_revenue_summary OWNER TO rmi_user;

--
-- Name: dao_proposals; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.dao_proposals (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    proposer uuid,
    action_type character varying(50) NOT NULL,
    target_contract character varying(255),
    call_data text,
    value_eth numeric(18,8) DEFAULT 0,
    votes_for numeric(24,8) DEFAULT 0,
    votes_against numeric(24,8) DEFAULT 0,
    votes_abstain numeric(24,8) DEFAULT 0,
    quorum_required numeric(24,8) NOT NULL,
    voters jsonb DEFAULT '[]'::jsonb,
    status character varying(50) DEFAULT 'pending'::character varying,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone NOT NULL,
    executed_at timestamp without time zone,
    executed_by uuid,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT valid_proposal_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'active'::character varying, 'passed'::character varying, 'failed'::character varying, 'executed'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.dao_proposals OWNER TO rmi_user;

--
-- Name: dao_treasury; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.dao_treasury (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    chain character varying(50) NOT NULL,
    treasury_address character varying(255) NOT NULL,
    native_balance numeric(24,8) DEFAULT 0,
    native_balance_usd numeric(12,2) DEFAULT 0,
    token_balances jsonb DEFAULT '[]'::jsonb,
    total_token_value_usd numeric(12,2) DEFAULT 0,
    total_value_usd numeric(12,2) DEFAULT 0,
    allocated_to_operations numeric(12,2) DEFAULT 0,
    allocated_to_development numeric(12,2) DEFAULT 0,
    allocated_to_marketing numeric(12,2) DEFAULT 0,
    allocated_to_liquidity numeric(12,2) DEFAULT 0,
    unallocated numeric(12,2) DEFAULT 0,
    inflows_24h numeric(12,2) DEFAULT 0,
    outflows_24h numeric(12,2) DEFAULT 0,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.dao_treasury OWNER TO rmi_user;

--
-- Name: dashboard_configs; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.dashboard_configs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    widgets jsonb DEFAULT '[]'::jsonb,
    theme character varying(50) DEFAULT 'cyberpunk'::character varying,
    timezone character varying(50) DEFAULT 'UTC'::character varying,
    default_time_range character varying(50) DEFAULT '24h'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.dashboard_configs OWNER TO rmi_user;

--
-- Name: design_revisions; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.design_revisions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    page_id uuid,
    revision_number integer NOT NULL,
    page_content jsonb NOT NULL,
    change_summary text,
    change_type character varying(50),
    created_by uuid,
    created_by_type character varying(50) DEFAULT 'user'::character varying,
    review_status character varying(50) DEFAULT 'pending'::character varying,
    reviewed_by uuid,
    reviewed_at timestamp without time zone,
    review_notes text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.design_revisions OWNER TO rmi_user;

--
-- Name: discount_code_usage; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.discount_code_usage (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code_id uuid,
    user_id uuid,
    order_id character varying(255),
    discount_amount numeric(10,2),
    used_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.discount_code_usage OWNER TO rmi_user;

--
-- Name: discount_codes; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.discount_codes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code character varying(50) NOT NULL,
    discount_type character varying(20) DEFAULT 'percentage'::character varying,
    discount_value numeric(10,2) NOT NULL,
    max_uses integer DEFAULT 3,
    used_count integer DEFAULT 0,
    max_uses_per_user integer DEFAULT 3,
    valid_from timestamp with time zone DEFAULT now(),
    valid_until timestamp with time zone,
    is_active boolean DEFAULT true,
    eligible_wallet_id uuid,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.discount_codes OWNER TO rmi_user;

--
-- Name: education_bookmarks; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.education_bookmarks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    content_id uuid,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.education_bookmarks OWNER TO rmi_user;

--
-- Name: education_categories; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.education_categories (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    slug character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    icon character varying(100),
    color character varying(7) DEFAULT '#10b981'::character varying,
    sort_order integer DEFAULT 0,
    content_count integer DEFAULT 0,
    total_views integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.education_categories OWNER TO rmi_user;

--
-- Name: education_content; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.education_content (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    category_id uuid,
    slug character varying(100) NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    content text NOT NULL,
    content_type character varying(20) DEFAULT 'article'::character varying,
    difficulty character varying(20) DEFAULT 'beginner'::character varying,
    thumbnail_url text,
    video_url text,
    attachments jsonb DEFAULT '[]'::jsonb,
    estimated_read_time integer,
    tags text[] DEFAULT '{}'::text[],
    keywords text[] DEFAULT '{}'::text[],
    view_count integer DEFAULT 0,
    like_count integer DEFAULT 0,
    completion_count integer DEFAULT 0,
    is_published boolean DEFAULT false,
    is_featured boolean DEFAULT false,
    is_premium boolean DEFAULT false,
    author_id uuid,
    reviewed_by uuid,
    published_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.education_content OWNER TO rmi_user;

--
-- Name: education_likes; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.education_likes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    content_id uuid,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.education_likes OWNER TO rmi_user;

--
-- Name: education_progress; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.education_progress (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    content_id uuid,
    progress_percent integer DEFAULT 0,
    is_completed boolean DEFAULT false,
    completed_at timestamp with time zone,
    time_spent_seconds integer DEFAULT 0,
    last_position text,
    quiz_score integer,
    quiz_answers jsonb,
    last_accessed_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.education_progress OWNER TO rmi_user;

--
-- Name: encrypted_wallets; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.encrypted_wallets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    wallet_name character varying(255) NOT NULL,
    wallet_type character varying(50) NOT NULL,
    chain character varying(50) NOT NULL,
    address character varying(255) NOT NULL,
    public_key text,
    encryption_version integer DEFAULT 3,
    encrypted_private_key text NOT NULL,
    encrypted_key_part_2 text,
    encrypted_key_part_3 text,
    primary_storage character varying(100) NOT NULL,
    backup_storage_1 character varying(100),
    backup_storage_2 character varying(100),
    offline_backup_exists boolean DEFAULT false,
    key_derivation_salt character varying(128) NOT NULL,
    encryption_iv character varying(64),
    key_shares_required integer DEFAULT 2,
    key_shares_total integer DEFAULT 3,
    status character varying(50) DEFAULT 'pending_approval'::character varying,
    is_multisig boolean DEFAULT false,
    multisig_threshold integer DEFAULT 1,
    multisig_total_signers integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT now(),
    last_rotated timestamp without time zone,
    rotation_schedule_days integer DEFAULT 90,
    next_rotation_due timestamp without time zone,
    rotation_count integer DEFAULT 0,
    security_level character varying(20) DEFAULT 'high'::character varying,
    access_count integer DEFAULT 0,
    last_accessed timestamp without time zone,
    last_accessed_by uuid,
    balance numeric(24,8) DEFAULT 0,
    balance_usd numeric(12,2) DEFAULT 0,
    last_balance_update timestamp without time zone,
    tags jsonb DEFAULT '[]'::jsonb,
    notes text,
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT valid_security_level CHECK (((security_level)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying, 'maximum'::character varying])::text[]))),
    CONSTRAINT valid_wallet_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'rotated'::character varying, 'frozen'::character varying, 'compromised'::character varying, 'archived'::character varying, 'pending_approval'::character varying])::text[])))
);


ALTER TABLE public.encrypted_wallets OWNER TO rmi_user;

--
-- Name: health_check_results; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.health_check_results (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    endpoint_id uuid NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now(),
    status character varying(50) NOT NULL,
    latency_ms numeric(10,2) NOT NULL,
    http_status integer,
    error_message text,
    dns_resolution_ms numeric(10,2),
    connection_ms numeric(10,2),
    tls_handshake_ms numeric(10,2),
    time_to_first_byte_ms numeric(10,2),
    response_valid boolean DEFAULT true,
    response_checksum character varying(64)
);


ALTER TABLE public.health_check_results OWNER TO rmi_user;

--
-- Name: endpoint_health_summary; Type: VIEW; Schema: public; Owner: rmi_user
--

CREATE VIEW public.endpoint_health_summary AS
 SELECT e.id,
    e.name,
    e.provider_type,
    e.status,
    e.current_latency_ms,
    e.uptime_percentage,
    e.last_check_at,
    e.failure_count,
    count(h.id) AS checks_last_hour
   FROM (public.api_endpoints e
     LEFT JOIN public.health_check_results h ON (((e.id = h.endpoint_id) AND (h."timestamp" > (now() - '01:00:00'::interval)))))
  GROUP BY e.id, e.name, e.provider_type, e.status, e.current_latency_ms, e.uptime_percentage, e.last_check_at, e.failure_count;


ALTER VIEW public.endpoint_health_summary OWNER TO rmi_user;

--
-- Name: final_investigations; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.final_investigations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    tokens_investigated jsonb DEFAULT '[]'::jsonb,
    platforms_investigated jsonb DEFAULT '[]'::jsonb,
    time_period_start timestamp without time zone NOT NULL,
    time_period_end timestamp without time zone NOT NULL,
    lead_investigator uuid,
    investigators jsonb DEFAULT '[]'::jsonb,
    status character varying(50) DEFAULT 'open'::character varying,
    findings jsonb DEFAULT '[]'::jsonb,
    executive_summary text,
    key_conclusions jsonb DEFAULT '[]'::jsonb,
    recommendations jsonb DEFAULT '[]'::jsonb,
    legal_implications jsonb DEFAULT '[]'::jsonb,
    recommended_legal_actions jsonb DEFAULT '[]'::jsonb,
    full_report_url text,
    redacted_report_url text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    closed_at timestamp without time zone
);


ALTER TABLE public.final_investigations OWNER TO rmi_user;

--
-- Name: forum_categories; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.forum_categories (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    slug character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    icon character varying(100),
    color character varying(7) DEFAULT '#3b82f6'::character varying,
    post_count integer DEFAULT 0,
    subscriber_count integer DEFAULT 0,
    is_private boolean DEFAULT false,
    requires_verification boolean DEFAULT false,
    allow_anonymous boolean DEFAULT false,
    created_by uuid,
    moderators uuid[] DEFAULT '{}'::uuid[],
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.forum_categories OWNER TO rmi_user;

--
-- Name: forum_comment_votes; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.forum_comment_votes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    comment_id uuid,
    vote_type character varying(10) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.forum_comment_votes OWNER TO rmi_user;

--
-- Name: forum_comments; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.forum_comments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    post_id uuid,
    author_id uuid,
    parent_comment_id uuid,
    content text NOT NULL,
    content_type character varying(20) DEFAULT 'markdown'::character varying,
    upvotes integer DEFAULT 0,
    downvotes integer DEFAULT 0,
    is_deleted boolean DEFAULT false,
    is_anonymous boolean DEFAULT false,
    is_solution boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.forum_comments OWNER TO rmi_user;

--
-- Name: forum_posts; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.forum_posts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    category_id uuid,
    author_id uuid,
    title character varying(300) NOT NULL,
    content text NOT NULL,
    content_type character varying(20) DEFAULT 'markdown'::character varying,
    images text[] DEFAULT '{}'::text[],
    attachments jsonb DEFAULT '[]'::jsonb,
    upvotes integer DEFAULT 0,
    downvotes integer DEFAULT 0,
    view_count integer DEFAULT 0,
    comment_count integer DEFAULT 0,
    is_pinned boolean DEFAULT false,
    is_locked boolean DEFAULT false,
    is_deleted boolean DEFAULT false,
    is_anonymous boolean DEFAULT false,
    is_scam_report boolean DEFAULT false,
    reported_wallet_addresses text[] DEFAULT '{}'::text[],
    reported_token_address character varying(255),
    scam_type character varying(50),
    scam_status character varying(20) DEFAULT 'reported'::character varying,
    evidence_links text[] DEFAULT '{}'::text[],
    last_activity_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.forum_posts OWNER TO rmi_user;

--
-- Name: forum_subscriptions; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.forum_subscriptions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    category_id uuid,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.forum_subscriptions OWNER TO rmi_user;

--
-- Name: forum_votes; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.forum_votes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    post_id uuid,
    vote_type character varying(10) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.forum_votes OWNER TO rmi_user;

--
-- Name: fund_separation_accounts; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.fund_separation_accounts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    account_name character varying(255) NOT NULL,
    account_type character varying(50) NOT NULL,
    wallet_address character varying(255),
    bank_account character varying(255),
    opening_balance numeric(12,2) DEFAULT 0,
    current_balance numeric(12,2) DEFAULT 0,
    currency character varying(10) DEFAULT 'USD'::character varying,
    purpose text,
    allowed_uses jsonb DEFAULT '[]'::jsonb,
    prohibited_uses jsonb DEFAULT '[]'::jsonb,
    transactions jsonb DEFAULT '[]'::jsonb,
    last_reconciled timestamp without time zone,
    reconciliation_status character varying(50) DEFAULT 'pending'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.fund_separation_accounts OWNER TO rmi_user;

--
-- Name: generated_emails; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.generated_emails (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email_address character varying(255) NOT NULL,
    display_name character varying(255),
    provider character varying(50) NOT NULL,
    domain character varying(100) NOT NULL,
    purpose character varying(255) NOT NULL,
    associated_services jsonb DEFAULT '[]'::jsonb,
    password_credential_id uuid,
    recovery_email character varying(255),
    recovery_phone character varying(50),
    is_active boolean DEFAULT true,
    is_flagged boolean DEFAULT false,
    flag_reason text,
    forwards_to character varying(255),
    auto_delete_after_days integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    last_used timestamp without time zone
);


ALTER TABLE public.generated_emails OWNER TO rmi_user;

--
-- Name: historical_timelines; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.historical_timelines (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    entity_id uuid NOT NULL,
    entity_type character varying(50) NOT NULL,
    events jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.historical_timelines OWNER TO rmi_user;

--
-- Name: intelligence_briefings; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.intelligence_briefings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    date date NOT NULL,
    generated_at timestamp without time zone DEFAULT now(),
    sections jsonb DEFAULT '{}'::jsonb NOT NULL,
    total_revenue_24h numeric(12,2) DEFAULT 0,
    total_users_24h integer DEFAULT 0,
    api_calls_24h integer DEFAULT 0,
    new_investigations integer DEFAULT 0,
    crm_v1_wallets_verified integer DEFAULT 0,
    crm_v1_anomalies integer DEFAULT 0,
    crm_v2_contracts_deployed integer DEFAULT 0,
    crm_v2_holders integer DEFAULT 0,
    priority_alerts jsonb DEFAULT '[]'::jsonb,
    insights jsonb DEFAULT '[]'::jsonb,
    recommendations jsonb DEFAULT '[]'::jsonb,
    sent_to jsonb DEFAULT '[]'::jsonb,
    opened_by jsonb DEFAULT '[]'::jsonb,
    sent_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.intelligence_briefings OWNER TO rmi_user;

--
-- Name: investigation_findings; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.investigation_findings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    investigation_id uuid,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    finding_type character varying(50) NOT NULL,
    severity character varying(20) DEFAULT 'medium'::character varying,
    confidence integer DEFAULT 50,
    evidence jsonb DEFAULT '[]'::jsonb,
    witnesses jsonb DEFAULT '[]'::jsonb,
    documents jsonb DEFAULT '[]'::jsonb,
    related_findings jsonb DEFAULT '[]'::jsonb,
    related_addresses jsonb DEFAULT '[]'::jsonb,
    status character varying(50) DEFAULT 'open'::character varying,
    created_by uuid,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.investigation_findings OWNER TO rmi_user;

--
-- Name: key_shares; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.key_shares (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    wallet_id uuid NOT NULL,
    share_index integer NOT NULL,
    encrypted_share text NOT NULL,
    storage_location character varying(100) NOT NULL,
    requires_approval boolean DEFAULT true,
    approvers_required integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT now(),
    last_accessed timestamp without time zone
);


ALTER TABLE public.key_shares OWNER TO rmi_user;

--
-- Name: launch_failure_analyses; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.launch_failure_analyses (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    token_launch_id uuid,
    failure_type character varying(50) NOT NULL,
    severity character varying(20) DEFAULT 'high'::character varying,
    failure_date timestamp without time zone NOT NULL,
    first_detected_date timestamp without time zone,
    root_causes jsonb DEFAULT '[]'::jsonb,
    contributing_factors jsonb DEFAULT '[]'::jsonb,
    technical_problems jsonb DEFAULT '[]'::jsonb,
    contract_vulnerabilities jsonb DEFAULT '[]'::jsonb,
    tokenomics_flaws jsonb DEFAULT '[]'::jsonb,
    liquidity_issues jsonb DEFAULT '[]'::jsonb,
    market_conditions text,
    platform_problems jsonb DEFAULT '[]'::jsonb,
    fee_structure_issues jsonb DEFAULT '[]'::jsonb,
    financial_loss_usd numeric(12,2),
    holder_count_at_failure integer,
    reputation_impact character varying(20) DEFAULT 'medium'::character varying,
    lessons_learned jsonb DEFAULT '[]'::jsonb,
    what_could_have_prevented jsonb DEFAULT '[]'::jsonb,
    recommendations jsonb DEFAULT '[]'::jsonb,
    investigated_by uuid,
    investigation_date timestamp without time zone,
    investigation_notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.launch_failure_analyses OWNER TO rmi_user;

--
-- Name: legal_compliance; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.legal_compliance (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    check_type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    status character varying(50) DEFAULT 'not_started'::character varying,
    priority character varying(20) DEFAULT 'medium'::character varying,
    wyoming_requirement text,
    wyoming_statute_reference character varying(255),
    due_date timestamp without time zone,
    completed_at timestamp without time zone,
    reminder_days integer DEFAULT 30,
    required_documents jsonb DEFAULT '[]'::jsonb,
    uploaded_documents jsonb DEFAULT '[]'::jsonb,
    verified_by uuid,
    verified_at timestamp without time zone,
    notes text,
    fund_separation_verified boolean,
    commingling_detected boolean,
    commingling_details text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT valid_compliance_status CHECK (((status)::text = ANY ((ARRAY['not_started'::character varying, 'in_progress'::character varying, 'complete'::character varying, 'overdue'::character varying, 'warning'::character varying, 'not_applicable'::character varying])::text[])))
);


ALTER TABLE public.legal_compliance OWNER TO rmi_user;

--
-- Name: legal_opinions; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.legal_opinions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    topic character varying(255) NOT NULL,
    summary text NOT NULL,
    detailed_analysis text,
    legal_risks jsonb DEFAULT '[]'::jsonb,
    mitigation_strategies jsonb DEFAULT '[]'::jsonb,
    recommended_actions jsonb DEFAULT '[]'::jsonb,
    alternative_approaches jsonb DEFAULT '[]'::jsonb,
    attorney_name character varying(255),
    attorney_firm character varying(255),
    date_issued timestamp without time zone,
    status character varying(50) DEFAULT 'draft'::character varying,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.legal_opinions OWNER TO rmi_user;

--
-- Name: monthly_revenue_summary; Type: VIEW; Schema: public; Owner: rmi_user
--

CREATE VIEW public.monthly_revenue_summary AS
 SELECT date_trunc('month'::text, created_at) AS month,
    product,
    count(*) AS transaction_count,
    sum(amount) AS total_revenue,
    count(DISTINCT user_id) AS unique_customers
   FROM public.transactions
  WHERE ((status)::text = 'completed'::text)
  GROUP BY (date_trunc('month'::text, created_at)), product;


ALTER VIEW public.monthly_revenue_summary OWNER TO rmi_user;

--
-- Name: munchmaps_scans; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.munchmaps_scans (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    wallet_address character varying(255) NOT NULL,
    chain character varying(50) NOT NULL,
    wallet_type character varying(100),
    risk_score integer,
    scan_type character varying(50),
    results jsonb,
    report_url text,
    scan_cost numeric(8,2),
    data_sources_used integer,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT munchmaps_scans_risk_score_check CHECK (((risk_score >= 0) AND (risk_score <= 100)))
);


ALTER TABLE public.munchmaps_scans OWNER TO rmi_user;

--
-- Name: newsletter_campaigns; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.newsletter_campaigns (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    html_content text,
    text_content text,
    template_id uuid,
    target_tiers jsonb DEFAULT '[]'::jsonb,
    target_tags jsonb DEFAULT '[]'::jsonb,
    exclude_tags jsonb DEFAULT '[]'::jsonb,
    scheduled_at timestamp without time zone,
    sent_at timestamp without time zone,
    status character varying(50) DEFAULT 'draft'::character varying,
    recipients_count integer DEFAULT 0,
    delivered_count integer DEFAULT 0,
    opened_count integer DEFAULT 0,
    clicked_count integer DEFAULT 0,
    bounced_count integer DEFAULT 0,
    complained_count integer DEFAULT 0,
    unsubscribed_count integer DEFAULT 0,
    open_rate numeric(5,2) DEFAULT 0,
    click_rate numeric(5,2) DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    created_by uuid,
    CONSTRAINT valid_campaign_status CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'scheduled'::character varying, 'sending'::character varying, 'sent'::character varying, 'cancelled'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE public.newsletter_campaigns OWNER TO rmi_user;

--
-- Name: newsletter_subscribers; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.newsletter_subscribers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    status character varying(50) DEFAULT 'pending_confirmation'::character varying,
    tier character varying(50) DEFAULT 'free'::character varying,
    first_name character varying(100),
    last_name character varying(100),
    company character varying(255),
    wallet_address character varying(255),
    is_crm_v1_holder boolean DEFAULT false,
    is_crm_v2_holder boolean DEFAULT false,
    crm_tokens_held numeric(24,8) DEFAULT 0,
    preferences jsonb DEFAULT '{"daily_briefing": true, "market_updates": true, "weekly_summary": true, "product_releases": true, "promotional_offers": false, "educational_content": true}'::jsonb,
    emails_sent integer DEFAULT 0,
    emails_opened integer DEFAULT 0,
    emails_clicked integer DEFAULT 0,
    last_opened timestamp without time zone,
    last_clicked timestamp without time zone,
    engagement_score numeric(5,2) DEFAULT 0,
    payment_status character varying(50),
    payment_due_date timestamp without time zone,
    payment_amount numeric(12,2) DEFAULT 0,
    subscription_expires timestamp without time zone,
    tags jsonb DEFAULT '[]'::jsonb,
    source character varying(255),
    confirmed boolean DEFAULT false,
    confirmed_at timestamp without time zone,
    confirmation_token character varying(255),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    unsubscribed_at timestamp without time zone,
    CONSTRAINT valid_subscriber_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'unsubscribed'::character varying, 'bounced'::character varying, 'complained'::character varying, 'pending_confirmation'::character varying])::text[]))),
    CONSTRAINT valid_subscription_tier CHECK (((tier)::text = ANY ((ARRAY['free'::character varying, 'basic'::character varying, 'premium'::character varying, 'vip'::character varying])::text[])))
);


ALTER TABLE public.newsletter_subscribers OWNER TO rmi_user;

--
-- Name: notification_configs; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.notification_configs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) DEFAULT 'default'::character varying,
    telegram_bot_token character varying(255),
    telegram_chat_id character varying(255),
    email_smtp_host character varying(255),
    email_smtp_port integer DEFAULT 587,
    email_username character varying(255),
    email_credential_id uuid,
    email_recipients jsonb DEFAULT '[]'::jsonb,
    webhook_url text,
    webhook_secret_credential_id uuid,
    notify_on_severity jsonb DEFAULT '["critical", "high"]'::jsonb,
    notify_on_component jsonb DEFAULT '[]'::jsonb,
    daily_digest_enabled boolean DEFAULT true,
    digest_time time without time zone DEFAULT '09:00:00'::time without time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.notification_configs OWNER TO rmi_user;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.notifications (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    type character varying(50) NOT NULL,
    title character varying(200),
    message text,
    link character varying(500),
    is_read boolean DEFAULT false,
    read_at timestamp with time zone,
    actor_id uuid,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO rmi_user;

--
-- Name: password_parts; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.password_parts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    wallet_id uuid NOT NULL,
    part_name character varying(50) NOT NULL,
    encrypted_part character varying(512) NOT NULL,
    storage_location character varying(100) NOT NULL,
    auto_rotate boolean DEFAULT true,
    last_rotated timestamp without time zone DEFAULT now(),
    next_rotation timestamp without time zone,
    rotation_interval_days integer DEFAULT 7,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.password_parts OWNER TO rmi_user;

--
-- Name: password_policies; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.password_policies (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    policy_name character varying(255) NOT NULL,
    min_length integer DEFAULT 16,
    max_length integer DEFAULT 64,
    require_uppercase boolean DEFAULT true,
    require_lowercase boolean DEFAULT true,
    require_numbers boolean DEFAULT true,
    require_special boolean DEFAULT true,
    special_chars character varying(100) DEFAULT '!@#$%^&*()_+-=[]{}|;:,.<>?'::character varying,
    avoid_ambiguous boolean DEFAULT true,
    prevent_dictionary boolean DEFAULT true,
    prevent_patterns boolean DEFAULT true,
    prevent_reuse integer DEFAULT 5,
    max_age_days integer DEFAULT 90,
    notify_before_days integer DEFAULT 7,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.password_policies OWNER TO rmi_user;

--
-- Name: platform_infiltrations; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.platform_infiltrations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    token_launch_id uuid,
    platform_name character varying(255) NOT NULL,
    fees jsonb DEFAULT '[]'::jsonb,
    hidden_costs jsonb DEFAULT '[]'::jsonb,
    unexpected_fees jsonb DEFAULT '[]'::jsonb,
    platform_control_issues jsonb DEFAULT '[]'::jsonb,
    censorship_attempts jsonb DEFAULT '[]'::jsonb,
    delisting_threats jsonb DEFAULT '[]'::jsonb,
    detected_manipulation jsonb DEFAULT '[]'::jsonb,
    suspicious_transactions jsonb DEFAULT '[]'::jsonb,
    total_fees_paid_usd numeric(12,2) DEFAULT 0,
    total_hidden_costs_usd numeric(12,2) DEFAULT 0,
    estimated_platform_extracted_value numeric(12,2) DEFAULT 0,
    first_issue_date timestamp without time zone,
    last_issue_date timestamp without time zone,
    evidence_links jsonb DEFAULT '[]'::jsonb,
    screenshots jsonb DEFAULT '[]'::jsonb,
    transaction_hashes jsonb DEFAULT '[]'::jsonb,
    notes text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.platform_infiltrations OWNER TO rmi_user;

--
-- Name: posting_schedules; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.posting_schedules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    platform character varying(50) NOT NULL,
    best_days jsonb DEFAULT '[]'::jsonb,
    best_hours jsonb DEFAULT '[]'::jsonb,
    posts_per_day integer DEFAULT 3,
    min_interval_hours integer DEFAULT 2,
    content_distribution jsonb DEFAULT '{}'::jsonb,
    narrative_distribution jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.posting_schedules OWNER TO rmi_user;

--
-- Name: provisioned_accounts; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.provisioned_accounts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    credential_pool_id uuid NOT NULL,
    credential_id uuid NOT NULL,
    provider_type character varying(50) NOT NULL,
    account_email character varying(255),
    endpoint_id uuid,
    provisioned_at timestamp with time zone DEFAULT now(),
    provisioned_reason character varying(50) NOT NULL,
    triggered_by_endpoint_id uuid,
    status character varying(50) DEFAULT 'active'::character varying,
    requests_made integer DEFAULT 0,
    last_used_at timestamp with time zone,
    estimated_monthly_cost numeric(10,2) DEFAULT 0.0,
    CONSTRAINT provisioned_accounts_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'suspended'::character varying, 'banned'::character varying, 'expired'::character varying])::text[])))
);


ALTER TABLE public.provisioned_accounts OWNER TO rmi_user;

--
-- Name: revenue_streams; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.revenue_streams (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    source character varying(255) NOT NULL,
    category character varying(50),
    monthly_revenue numeric(12,2) DEFAULT 0,
    monthly_costs numeric(12,2) DEFAULT 0,
    monthly_profit numeric(12,2) DEFAULT 0,
    profit_margin numeric(5,2) DEFAULT 0,
    growth_rate_mom numeric(8,2) DEFAULT 0,
    growth_rate_yoy numeric(8,2) DEFAULT 0,
    projected_3m numeric(12,2) DEFAULT 0,
    projected_6m numeric(12,2) DEFAULT 0,
    projected_12m numeric(12,2) DEFAULT 0,
    status character varying(50) DEFAULT 'active'::character varying,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.revenue_streams OWNER TO rmi_user;

--
-- Name: route_requests; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.route_requests (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now(),
    routing_group_id uuid,
    endpoint_id uuid,
    method character varying(10) NOT NULL,
    path text NOT NULL,
    source_ip inet,
    user_agent text,
    latency_ms numeric(10,2) NOT NULL,
    response_status integer NOT NULL,
    response_size_bytes integer DEFAULT 0,
    success boolean NOT NULL,
    error_message text,
    cached boolean DEFAULT false,
    rate_limited boolean DEFAULT false,
    retry_count integer DEFAULT 0
);


ALTER TABLE public.route_requests OWNER TO rmi_user;

--
-- Name: routing_analytics_hourly; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.routing_analytics_hourly (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    hour timestamp with time zone NOT NULL,
    routing_group_id uuid,
    endpoint_id uuid,
    total_requests integer DEFAULT 0,
    successful_requests integer DEFAULT 0,
    failed_requests integer DEFAULT 0,
    cached_requests integer DEFAULT 0,
    rate_limited_requests integer DEFAULT 0,
    avg_latency_ms numeric(10,2),
    min_latency_ms numeric(10,2),
    max_latency_ms numeric(10,2),
    p95_latency_ms numeric(10,2),
    p99_latency_ms numeric(10,2),
    error_4xx_count integer DEFAULT 0,
    error_5xx_count integer DEFAULT 0,
    timeout_count integer DEFAULT 0
);


ALTER TABLE public.routing_analytics_hourly OWNER TO rmi_user;

--
-- Name: routing_group_endpoints; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.routing_group_endpoints (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    routing_group_id uuid NOT NULL,
    endpoint_id uuid NOT NULL,
    is_active boolean DEFAULT true,
    added_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.routing_group_endpoints OWNER TO rmi_user;

--
-- Name: routing_groups; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.routing_groups (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    provider_type character varying(50) NOT NULL,
    strategy character varying(50) DEFAULT 'intelligent'::character varying,
    latency_threshold_ms integer DEFAULT 2000,
    error_rate_threshold numeric(5,4) DEFAULT 0.05,
    auto_provision_enabled boolean DEFAULT false,
    max_backup_endpoints integer DEFAULT 3,
    provision_credential_pool uuid,
    overall_status character varying(50) DEFAULT 'healthy'::character varying,
    current_latency_ms numeric(10,2) DEFAULT 0,
    total_requests_today integer DEFAULT 0,
    error_rate numeric(5,4) DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT routing_groups_max_backup_endpoints_check CHECK (((max_backup_endpoints >= 0) AND (max_backup_endpoints <= 10))),
    CONSTRAINT routing_groups_strategy_check CHECK (((strategy)::text = ANY ((ARRAY['round_robin'::character varying, 'weighted'::character varying, 'least_latency'::character varying, 'geographic'::character varying, 'failover_only'::character varying, 'intelligent'::character varying])::text[])))
);


ALTER TABLE public.routing_groups OWNER TO rmi_user;

--
-- Name: routing_group_status; Type: VIEW; Schema: public; Owner: rmi_user
--

CREATE VIEW public.routing_group_status AS
 SELECT g.id,
    g.name,
    g.provider_type,
    g.strategy,
    count(e.endpoint_id) AS total_endpoints,
    sum(
        CASE
            WHEN ((ep.status)::text = 'healthy'::text) THEN 1
            ELSE 0
        END) AS healthy_count,
    sum(
        CASE
            WHEN ((ep.status)::text = 'degraded'::text) THEN 1
            ELSE 0
        END) AS degraded_count,
    sum(
        CASE
            WHEN ((ep.status)::text = 'down'::text) THEN 1
            ELSE 0
        END) AS down_count,
    avg(ep.current_latency_ms) AS avg_latency_ms
   FROM ((public.routing_groups g
     LEFT JOIN public.routing_group_endpoints e ON (((g.id = e.routing_group_id) AND (e.is_active = true))))
     LEFT JOIN public.api_endpoints ep ON ((e.endpoint_id = ep.id)))
  GROUP BY g.id, g.name, g.provider_type, g.strategy;


ALTER VIEW public.routing_group_status OWNER TO rmi_user;

--
-- Name: routing_rules; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.routing_rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    priority integer DEFAULT 100,
    enabled boolean DEFAULT true,
    source_ip_pattern character varying(255),
    path_pattern character varying(255),
    header_conditions jsonb DEFAULT '{}'::jsonb,
    time_window_start time without time zone,
    time_window_end time without time zone,
    target_routing_group_id uuid,
    add_headers jsonb DEFAULT '{}'::jsonb,
    rate_limit_override integer,
    cache_ttl integer,
    require_auth boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.routing_rules OWNER TO rmi_user;

--
-- Name: security_alerts; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.security_alerts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    alert_type character varying(100) NOT NULL,
    severity character varying(20) NOT NULL,
    wallet_id uuid,
    tx_request_id uuid,
    description text NOT NULL,
    evidence jsonb DEFAULT '{}'::jsonb,
    status character varying(50) DEFAULT 'open'::character varying,
    resolved_by uuid,
    resolved_at timestamp without time zone,
    auto_actions jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.security_alerts OWNER TO rmi_user;

--
-- Name: service_accounts; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.service_accounts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    service_name character varying(255) NOT NULL,
    service_category character varying(50) NOT NULL,
    account_email character varying(255) NOT NULL,
    account_username character varying(255),
    account_type character varying(50) DEFAULT 'free'::character varying,
    credentials jsonb DEFAULT '[]'::jsonb,
    is_active boolean DEFAULT true,
    is_verified boolean DEFAULT false,
    verification_pending boolean DEFAULT false,
    usage_limits jsonb DEFAULT '{}'::jsonb,
    current_usage jsonb DEFAULT '{}'::jsonb,
    billing_cycle character varying(50),
    next_billing_date timestamp without time zone,
    cost_per_month numeric(10,2) DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.service_accounts OWNER TO rmi_user;

--
-- Name: stored_credentials; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.stored_credentials (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    service_name character varying(255) NOT NULL,
    service_category character varying(50) NOT NULL,
    credential_type character varying(50) NOT NULL,
    encrypted_value text NOT NULL,
    encrypted_backup text,
    encryption_salt character varying(128) NOT NULL,
    encryption_version integer DEFAULT 3,
    username character varying(255),
    email character varying(255),
    account_id character varying(255),
    api_endpoint text,
    login_url text,
    dashboard_url text,
    docs_url text,
    auto_rotate boolean DEFAULT false,
    rotation_frequency character varying(50) DEFAULT 'never'::character varying,
    last_rotated timestamp without time zone,
    next_rotation timestamp without time zone,
    rotation_count integer DEFAULT 0,
    status character varying(50) DEFAULT 'active'::character varying,
    expires_at timestamp without time zone,
    access_count integer DEFAULT 0,
    last_accessed timestamp without time zone,
    last_accessed_by uuid,
    description text,
    tags jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by uuid,
    CONSTRAINT valid_credential_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'expired'::character varying, 'rotating'::character varying, 'compromised'::character varying, 'revoked'::character varying, 'pending'::character varying])::text[])))
);


ALTER TABLE public.stored_credentials OWNER TO rmi_user;

--
-- Name: system_alerts; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.system_alerts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    severity character varying(20) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    source character varying(100),
    status character varying(50) DEFAULT 'active'::character varying,
    resolved_at timestamp without time zone,
    resolved_by uuid,
    resolution_notes text,
    acknowledged_at timestamp without time zone,
    acknowledged_by uuid,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT valid_alert_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'acknowledged'::character varying, 'resolved'::character varying])::text[]))),
    CONSTRAINT valid_severity CHECK (((severity)::text = ANY ((ARRAY['info'::character varying, 'warning'::character varying, 'critical'::character varying])::text[])))
);


ALTER TABLE public.system_alerts OWNER TO rmi_user;

--
-- Name: system_config; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.system_config (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    key character varying(255) NOT NULL,
    value jsonb NOT NULL,
    description text,
    updated_by uuid,
    updated_at timestamp without time zone DEFAULT now(),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.system_config OWNER TO rmi_user;

--
-- Name: token_holder_snapshots; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.token_holder_snapshots (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    token_launch_id uuid,
    snapshot_date timestamp without time zone NOT NULL,
    total_holders integer NOT NULL,
    total_supply numeric(24,8) NOT NULL,
    circulating_supply numeric(24,8),
    top_holders jsonb DEFAULT '[]'::jsonb,
    distribution_stats jsonb DEFAULT '{}'::jsonb,
    transactions_24h integer DEFAULT 0,
    volume_24h_usd numeric(12,2) DEFAULT 0,
    price_usd numeric(18,8),
    market_cap_usd numeric(18,2),
    block_number integer,
    snapshot_source character varying(50)
);


ALTER TABLE public.token_holder_snapshots OWNER TO rmi_user;

--
-- Name: token_launches; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.token_launches (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    token_symbol character varying(50) NOT NULL,
    token_name character varying(255) NOT NULL,
    token_type character varying(50) NOT NULL,
    launch_date timestamp without time zone NOT NULL,
    platform character varying(50) NOT NULL,
    platform_specific character varying(255),
    contract_address character varying(255),
    deployer_address character varying(255),
    transaction_hash character varying(255),
    total_supply numeric(24,8) NOT NULL,
    initial_circulating_supply numeric(24,8),
    initial_price_usd numeric(18,8),
    team_allocation_percent numeric(5,2) DEFAULT 0,
    team_allocation_locked boolean DEFAULT false,
    team_vesting_schedule jsonb,
    initial_liquidity_usd numeric(12,2),
    liquidity_locked boolean DEFAULT false,
    liquidity_lock_duration_days integer,
    launch_status character varying(50) NOT NULL,
    current_status character varying(50) DEFAULT 'active'::character varying,
    launch_narrative text,
    actual_outcome text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.token_launches OWNER TO rmi_user;

--
-- Name: transaction_requests; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.transaction_requests (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    wallet_id uuid NOT NULL,
    tx_type character varying(50) NOT NULL,
    recipient_address character varying(255) NOT NULL,
    amount numeric(24,8) NOT NULL,
    currency character varying(50) NOT NULL,
    contract_address character varying(255),
    contract_data text,
    gas_limit integer,
    gas_price numeric(18,8),
    max_fee_per_gas numeric(18,8),
    required_approvals integer DEFAULT 2,
    approvals_received integer DEFAULT 0,
    approvers jsonb DEFAULT '[]'::jsonb,
    status character varying(50) DEFAULT 'pending'::character varying,
    expires_at timestamp without time zone NOT NULL,
    risk_score integer DEFAULT 0,
    risk_flags jsonb DEFAULT '[]'::jsonb,
    executed_at timestamp without time zone,
    executed_by uuid,
    tx_hash character varying(255),
    created_at timestamp without time zone DEFAULT now(),
    created_by uuid,
    CONSTRAINT valid_tx_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying, 'expired'::character varying, 'executed'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.transaction_requests OWNER TO rmi_user;

--
-- Name: transition_milestones; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.transition_milestones (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    phase character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    target_date timestamp without time zone,
    completed_date timestamp without time zone,
    dependencies jsonb DEFAULT '[]'::jsonb,
    blocking jsonb DEFAULT '[]'::jsonb,
    status character varying(50) DEFAULT 'pending'::character varying,
    completion_percentage integer DEFAULT 0,
    deliverables jsonb DEFAULT '[]'::jsonb,
    owner uuid,
    contributors jsonb DEFAULT '[]'::jsonb,
    notes text,
    risks jsonb DEFAULT '[]'::jsonb,
    is_blocker boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.transition_milestones OWNER TO rmi_user;

--
-- Name: transition_reports; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.transition_reports (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    generated_at timestamp without time zone DEFAULT now(),
    period_start timestamp without time zone NOT NULL,
    period_end timestamp without time zone NOT NULL,
    executive_summary text,
    key_findings jsonb DEFAULT '[]'::jsonb,
    recommendations jsonb DEFAULT '[]'::jsonb,
    milestone_progress jsonb DEFAULT '[]'::jsonb,
    compliance_matrix jsonb DEFAULT '[]'::jsonb,
    transition_costs jsonb DEFAULT '{}'::jsonb,
    budget_vs_actual jsonb DEFAULT '{}'::jsonb,
    immediate_actions jsonb DEFAULT '[]'::jsonb,
    upcoming_deadlines jsonb DEFAULT '[]'::jsonb,
    generated_by uuid
);


ALTER TABLE public.transition_reports OWNER TO rmi_user;

--
-- Name: trending_topics; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.trending_topics (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    topic character varying(255) NOT NULL,
    keywords jsonb DEFAULT '[]'::jsonb,
    platform character varying(50) NOT NULL,
    trend_score integer NOT NULL,
    volume_24h integer DEFAULT 0,
    velocity character varying(20) DEFAULT 'stable'::character varying,
    category character varying(50),
    sentiment character varying(20),
    relevance_to_rugmunch integer DEFAULT 0,
    recommended_action text,
    sources jsonb DEFAULT '[]'::jsonb,
    detected_at timestamp without time zone DEFAULT now(),
    expires_at timestamp without time zone
);


ALTER TABLE public.trending_topics OWNER TO rmi_user;

--
-- Name: user_activity; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.user_activity (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    activity_type character varying(50) NOT NULL,
    entity_type character varying(50),
    entity_id uuid,
    metadata jsonb DEFAULT '{}'::jsonb,
    ip_address inet,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_activity OWNER TO rmi_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    username character varying(100),
    full_name character varying(255),
    company character varying(255),
    phone character varying(50),
    country character varying(100),
    password_hash character varying(255),
    is_verified boolean DEFAULT false,
    is_admin boolean DEFAULT false,
    is_law_enforcement boolean DEFAULT false,
    le_badge_number character varying(100),
    le_agency character varying(255),
    le_verified_at timestamp without time zone,
    le_verified_by uuid,
    status character varying(50) DEFAULT 'active'::character varying,
    suspended_at timestamp without time zone,
    suspension_reason text,
    suspended_by uuid,
    subscriptions jsonb DEFAULT '{}'::jsonb,
    total_api_calls integer DEFAULT 0,
    total_scans integer DEFAULT 0,
    total_spent numeric(12,2) DEFAULT 0,
    last_login timestamp without time zone,
    login_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT valid_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'suspended'::character varying, 'pending_verification'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO rmi_user;

--
-- Name: user_activity_summary; Type: VIEW; Schema: public; Owner: rmi_user
--

CREATE VIEW public.user_activity_summary AS
 SELECT u.id,
    u.email,
    u.status,
    u.created_at,
    u.total_api_calls,
    u.total_scans,
    u.total_spent,
    count(DISTINCT t.id) AS transaction_count,
    max(t.created_at) AS last_transaction_at
   FROM (public.users u
     LEFT JOIN public.transactions t ON (((u.id = t.user_id) AND ((t.status)::text = 'completed'::text))))
  GROUP BY u.id, u.email, u.status, u.created_at, u.total_api_calls, u.total_scans, u.total_spent;


ALTER VIEW public.user_activity_summary OWNER TO rmi_user;

--
-- Name: user_badges; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.user_badges (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    badge_id uuid NOT NULL,
    earned_at timestamp with time zone DEFAULT now(),
    earned_via character varying(50),
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.user_badges OWNER TO rmi_user;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    session_token character varying(255) NOT NULL,
    ip_address inet,
    user_agent text,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_sessions OWNER TO rmi_user;

--
-- Name: user_social_connections; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.user_social_connections (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    provider character varying(20) NOT NULL,
    provider_user_id character varying(255) NOT NULL,
    username character varying(255),
    access_token text,
    refresh_token text,
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_social_connections OWNER TO rmi_user;

--
-- Name: user_stats; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.user_stats (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    post_count integer DEFAULT 0,
    comment_count integer DEFAULT 0,
    alpha_calls_count integer DEFAULT 0,
    verified_alpha_count integer DEFAULT 0,
    viral_memes_count integer DEFAULT 0,
    total_upvotes_received integer DEFAULT 0,
    total_downvotes_received integer DEFAULT 0,
    helpful_marks_received integer DEFAULT 0,
    follower_count integer DEFAULT 0,
    following_count integer DEFAULT 0,
    current_streak integer DEFAULT 0,
    longest_streak integer DEFAULT 0,
    last_post_date date,
    wallet_connected boolean DEFAULT false,
    portfolio_value numeric(20,2),
    total_trades integer DEFAULT 0,
    winning_trades integer DEFAULT 0,
    losing_trades integer DEFAULT 0,
    best_trade_return numeric(10,2),
    worst_trade_return numeric(10,2),
    scam_reports_submitted integer DEFAULT 0,
    verified_scam_reports integer DEFAULT 0,
    total_xp integer DEFAULT 0,
    current_level integer DEFAULT 1,
    updated_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_stats OWNER TO rmi_user;

--
-- Name: user_streaks; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.user_streaks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    current_streak integer DEFAULT 0,
    longest_streak integer DEFAULT 0,
    streak_start_date date,
    last_activity_date date,
    total_days_active integer DEFAULT 0,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_streaks OWNER TO rmi_user;

--
-- Name: wallet_rotations; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.wallet_rotations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    old_wallet_id uuid,
    new_wallet_id uuid,
    rotation_reason character varying(100) NOT NULL,
    initiated_by uuid,
    approved_by jsonb DEFAULT '[]'::jsonb,
    funds_transferred boolean DEFAULT false,
    transfer_amount numeric(24,8) DEFAULT 0,
    transfer_tx_hash character varying(255),
    status character varying(50) DEFAULT 'pending_approval'::character varying,
    started_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    verification_hash character varying(128) NOT NULL
);


ALTER TABLE public.wallet_rotations OWNER TO rmi_user;

--
-- Name: wallet_verification_attempts; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.wallet_verification_attempts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    wallet_address character varying(255) NOT NULL,
    user_id uuid,
    method character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    message text,
    signature text,
    verified_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.wallet_verification_attempts OWNER TO rmi_user;

--
-- Name: website_pages; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.website_pages (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    project_id uuid,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    page_type character varying(50) NOT NULL,
    meta_title character varying(255),
    meta_description text,
    meta_keywords jsonb DEFAULT '[]'::jsonb,
    og_image text,
    components jsonb DEFAULT '[]'::jsonb,
    custom_css text,
    custom_js text,
    views integer DEFAULT 0,
    unique_visitors integer DEFAULT 0,
    avg_time_on_page numeric(10,2) DEFAULT 0,
    bounce_rate numeric(5,2) DEFAULT 0,
    status character varying(50) DEFAULT 'draft'::character varying,
    is_published boolean DEFAULT false,
    published_version character varying(50),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    last_published_at timestamp without time zone
);


ALTER TABLE public.website_pages OWNER TO rmi_user;

--
-- Name: website_projects; Type: TABLE; Schema: public; Owner: rmi_user
--

CREATE TABLE public.website_projects (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    domain character varying(255) NOT NULL,
    description text,
    brand_colors jsonb DEFAULT '{}'::jsonb,
    brand_fonts jsonb DEFAULT '{}'::jsonb,
    logo_url text,
    favicon_url text,
    meta_title character varying(255),
    meta_description text,
    meta_keywords jsonb DEFAULT '[]'::jsonb,
    google_analytics_id character varying(100),
    pixel_id character varying(100),
    status character varying(50) DEFAULT 'development'::character varying,
    is_published boolean DEFAULT false,
    published_at timestamp without time zone,
    pages jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by uuid
);


ALTER TABLE public.website_projects OWNER TO rmi_user;

--
-- Data for Name: access_logs; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.access_logs (id, wallet_id, tx_request_id, action, performed_by, ip_address, user_agent, device_fingerprint, geo_location, auth_method, success, failure_reason, created_at) FROM stdin;
\.


--
-- Data for Name: admin_logs; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.admin_logs (id, admin_id, action, target_type, target_id, details, reason, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: admin_recovery_keys; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.admin_recovery_keys (id, key_shares, last_verified, recovery_procedures, requires_physical_presence, requires_multiple_admins, is_active, never_expires, updated_at) FROM stdin;
\.


--
-- Data for Name: admin_recovery_requests; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.admin_recovery_requests (id, reason, initiated_by, status, requires_physical_presence, requires_multiple_admins, verification_steps, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: ai_provider_health; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.ai_provider_health (id, provider_name, status, last_check, consecutive_failures, avg_response_time_ms, success_rate) FROM stdin;
\.


--
-- Data for Name: ai_provider_usage; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.ai_provider_usage (id, provider_name, date, requests_count, tokens_used, cost_usd) FROM stdin;
\.


--
-- Data for Name: ai_request_log; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.ai_request_log (id, provider_name, model_name, task_type, request_time, response_time_ms, tokens_input, tokens_output, cost_usd, success, error_message) FROM stdin;
\.


--
-- Data for Name: ai_website_requests; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.ai_website_requests (id, project_id, request_type, description, target_audience, tone, target_page_id, target_component_id, status, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: ai_website_results; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.ai_website_results (id, request_id, generated_components, design_rationale, seo_suggestions, improvement_suggestions, status, errors, created_at) FROM stdin;
\.


--
-- Data for Name: airdrop_eligible_wallets; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.airdrop_eligible_wallets (id, wallet_address, chain, held_crm_v1, held_amount, snapshot_date, verification_tx_hash, verified_at, reward_tier, base_reward_amount, bonus_amount, claimed, claimed_at, claimed_by, created_at) FROM stdin;
\.


--
-- Data for Name: api_credential_updates; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.api_credential_updates (id, credential_id, service_name, old_credential_hash, new_credential_hash, rollout_status, rollout_percentage, affected_services, updated_services, failed_services, can_rollback, rollback_window_minutes, initiated_by, initiated_at, completed_at) FROM stdin;
\.


--
-- Data for Name: api_endpoints; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.api_endpoints (id, name, provider_type, base_url, description, region, priority, weight, rate_limit_requests, rate_limit_window, rate_limit_strategy, health_check_enabled, health_check_interval, health_check_endpoint, health_check_timeout, failover_enabled, failover_threshold, auto_provision_backup, requires_proxy, proxy_rotation, fingerprint_randomization, credential_id, status, current_latency_ms, uptime_percentage, last_check_at, last_success_at, last_failure_at, failure_count, success_count, current_requests_remaining, rate_limit_reset_at, is_backup, parent_endpoint_id, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: api_logs; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.api_logs (id, user_id, endpoint, method, product, status_code, response_time_ms, rate_limit_remaining, rate_limit_reset, ip_address, user_agent, request_size_bytes, response_size_bytes, error_message, error_code, cache_hit, created_at) FROM stdin;
\.


--
-- Data for Name: app_suggestions; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.app_suggestions (id, name, description, category, target_audience, market_size, competition_level, development_cost_low, development_cost_high, monthly_revenue_potential, time_to_revenue_months, roi_estimate, complexity, required_integrations, tech_stack, key_features, mvp_features, priority_score, strategic_value, status, similar_apps, research_links, suggested_at, suggested_by) FROM stdin;
\.


--
-- Data for Name: approval_policies; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.approval_policies (id, policy_name, wallet_types, chains, min_amount, max_amount, required_approvals, required_approvers, require_different_devices, require_time_delay, risk_threshold, require_2fa, require_biometric, is_active, created_at, updated_at) FROM stdin;
90f86c9b-19f3-4a40-af58-0e4b917e14ed	Small Transfer (< $1K)	["operational", "marketing"]	[]	0.00000000	1000.00000000	1	[]	f	0	50	t	f	t	2026-04-09 19:34:56.386387	2026-04-09 19:34:56.386387
00be3631-92f0-4a11-8e90-8ff22f6a97de	Medium Transfer ($1K - $10K)	["operational", "marketing", "development"]	[]	1000.00000000	10000.00000000	2	[]	f	0	50	t	f	t	2026-04-09 19:34:56.386387	2026-04-09 19:34:56.386387
e55c4985-c71a-4fd9-ad59-3dd89eab96ce	Large Transfer ($10K - $100K)	["treasury", "reserve"]	[]	10000.00000000	100000.00000000	2	[]	f	24	50	t	f	t	2026-04-09 19:34:56.386387	2026-04-09 19:34:56.386387
7ddfe352-02b1-45ff-9c6f-331f699591f7	Massive Transfer (> $100K)	["treasury", "cold_storage"]	[]	100000.00000000	999999999.00000000	3	[]	f	48	50	t	f	t	2026-04-09 19:34:56.386387	2026-04-09 19:34:56.386387
adf16a9e-6ce8-4e90-a0f8-0ded173b20a9	Critical Wallet Operations	["treasury", "cold_storage"]	[]	0.00000000	999999999.00000000	3	[]	f	0	50	t	f	t	2026-04-09 19:34:56.386387	2026-04-09 19:34:56.386387
\.


--
-- Data for Name: auto_content_suggestions; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.auto_content_suggestions (id, source_type, source_topic, suggested_headline, suggested_body, suggested_hashtags, suggested_cta, recommended_platforms, recommended_time, recommended_narrative, confidence_score, reasoning, status, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: badge_categories; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.badge_categories (id, name, description, display_order, created_at) FROM stdin;
863988a2-a6f8-48ef-8cb4-3234402d7be9	trading	Trading and portfolio achievements	1	2026-04-10 13:16:27.455093+02
98699e2e-99b9-402e-b715-9f589d87b7d8	community	Community engagement and social	2	2026-04-10 13:16:27.455093+02
23f0ee23-2eda-4407-a5dd-efce0e3d88c2	content	Content creation and alpha calling	3	2026-04-10 13:16:27.455093+02
a85b3d8b-4b87-46c2-93ee-d6c1ab9af4a4	security	Scam fighting and security	4	2026-04-10 13:16:27.455093+02
424ab542-4f6c-4030-8e47-6ae85fbf4066	special	Special and hidden badges	5	2026-04-10 13:16:27.455093+02
\.


--
-- Data for Name: badge_leaderboard; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.badge_leaderboard (id, user_id, badge_count, total_xp, legendary_badges, period, period_start, period_end, rank, updated_at) FROM stdin;
\.


--
-- Data for Name: badge_progress; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.badge_progress (id, user_id, badge_id, current_value, target_value, progress_percentage, last_updated) FROM stdin;
\.


--
-- Data for Name: badge_unlock_log; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.badge_unlock_log (id, user_id, badge_id, unlocked_at, notified, notification_seen_at, shared_to_twitter, shared_at) FROM stdin;
\.


--
-- Data for Name: badges; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.badges (id, badge_id, name, emoji, description, rarity, category_id, condition_type, condition_config, xp_value, is_hidden, is_limited, limited_quantity, created_at, updated_at) FROM stdin;
bc9a1db5-d499-4928-9cff-e2134aa13097	first_post	First Blood	🎯	Made your first post in The Trenches	common	23f0ee23-2eda-4407-a5dd-efce0e3d88c2	post_count	{"value": 1}	10	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
8fbfcfe6-3397-42cb-bdf7-6f4dc3b66507	wallet_verified	Verified	✅	Verified wallet ownership	common	98699e2e-99b9-402e-b715-9f589d87b7d8	wallet_connect	{"value": 1}	10	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
aa51574c-e741-44bf-a274-6bedf4dfde8a	first_comment	First Words	💬	Left your first comment	common	98699e2e-99b9-402e-b715-9f589d87b7d8	comment_count	{"value": 1}	10	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
b330c850-e72d-4ccc-b47b-d275113340be	smooth_brain	Smooth Brain	🧠	Posted "what does this button do?"	common	424ab542-4f6c-4030-8e47-6ae85fbf4066	specific_phrase	{"value": "what does this button do"}	15	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
3131a058-5b15-40dd-a30c-2c975f2689bf	gas_victim	Gas Victim	⛽	Paid $500+ in gas for failed tx	common	863988a2-a6f8-48ef-8cb4-3234402d7be9	gas_spent	{"value": 500}	10	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
4624af7f-949c-4d5a-83b2-7df724b6eb51	paper_hands	Paper Hands	📄	Sold at 10% loss or less	common	863988a2-a6f8-48ef-8cb4-3234402d7be9	sell_loss	{"value": 10}	5	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
46fe5857-4d78-4f5f-80fa-b435a8fdbc97	fomo_buyer	Ape Strong	🦧	FOMO'd top 5 times	common	863988a2-a6f8-48ef-8cb4-3234402d7be9	fomo_count	{"value": 5}	15	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
8a7e1154-3c95-42a1-a3a6-c0390150dcca	three_day_streak	Warming Up	🔥	Posted 3 days in a row	common	98699e2e-99b9-402e-b715-9f589d87b7d8	streak	{"value": 3}	20	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
4f1d474c-9803-4554-a328-13c4351a845d	cap	Cap	🧢	Caught lying about gains	common	424ab542-4f6c-4030-8e47-6ae85fbf4066	caught_lying	{"value": 1}	5	t	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
d691d01c-ef32-4533-b5e5-24a704719701	diamond_hands	Diamond Hands	💎	Held through 50%+ dump	uncommon	863988a2-a6f8-48ef-8cb4-3234402d7be9	hold_through_dump	{"value": 50}	50	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
0a803b57-a50a-4e4c-bee9-301f8295e0ea	seven_day_streak	Week Warrior	🔥🔥	Posted 7 days straight	uncommon	98699e2e-99b9-402e-b715-9f589d87b7d8	streak	{"value": 7}	50	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
d9979068-6fa9-40fa-9a01-67d7b3883105	helper	Helper	🤝	50 answers marked helpful	uncommon	98699e2e-99b9-402e-b715-9f589d87b7d8	helpful_count	{"value": 50}	50	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
e86fbc03-8d5c-4ed0-b5b9-a8c7078eb671	content_creator	Content Creator	📝	Made 50 posts	uncommon	23f0ee23-2eda-4407-a5dd-efce0e3d88c2	post_count	{"value": 50}	40	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
bb31566b-2384-40c0-930c-305d1d90a7c8	scout	Scout	🔍	Posted first alpha	uncommon	23f0ee23-2eda-4407-a5dd-efce0e3d88c2	alpha_count	{"value": 1}	30	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
69c512b5-fca2-4c9b-aa30-ad11f068debe	degen	Degen	🎲	100+ trades in 30 days	uncommon	863988a2-a6f8-48ef-8cb4-3234402d7be9	trade_count_month	{"value": 100}	40	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
3e8db309-192e-4550-af32-ca5410eee165	rekt	Rekt	💸	Lost 50%+ in one trade	uncommon	863988a2-a6f8-48ef-8cb4-3234402d7be9	single_loss	{"value": 50}	25	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
b6aaaae8-bdef-4723-b055-74618895c914	vampire	Night Owl	🦇	Posted 10 times 12am-5am	uncommon	98699e2e-99b9-402e-b715-9f589d87b7d8	night_posts	{"value": 10}	30	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
ed511f81-7bf2-4a89-a66c-e9804cfcea33	vocal	Vocal	🗣️	100 comments	uncommon	98699e2e-99b9-402e-b715-9f589d87b7d8	comment_count	{"value": 100}	35	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
2aaa585c-a2cb-429e-a3cb-bf53fca20b8c	liked	Liked	❤️	Received 1000 upvotes total	uncommon	98699e2e-99b9-402e-b715-9f589d87b7d8	total_upvotes	{"value": 1000}	40	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
b43d3e63-a0cd-417f-9805-28099a3f36e4	alpha_caller	Alpha Caller	🎯	10 verified alpha calls	rare	23f0ee23-2eda-4407-a5dd-efce0e3d88c2	verified_alpha	{"value": 10}	150	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
d034a581-4036-49a7-bab5-426ca1ecdd32	meme_lord	Meme Lord	🎭	10 viral memes (1k+ shares)	rare	23f0ee23-2eda-4407-a5dd-efce0e3d88c2	viral_memes	{"value": 10}	120	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
6c5a427f-85bc-4898-b2e0-6acaaa31d54f	iron_hands	Iron Hands	🛡️	Held through 80%+ crash	rare	863988a2-a6f8-48ef-8cb4-3234402d7be9	hold_through_dump	{"value": 80}	150	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
9e7cd272-c277-4eed-aa5a-41bc1ed69982	storyteller	Storyteller	📖	10 posts with 100+ upvotes	rare	23f0ee23-2eda-4407-a5dd-efce0e3d88c2	high_upvote_posts	{"value": 10}	100	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
4643fb34-506b-426d-9963-e8ead9170eee	guardian	Guardian	🛡️	10 verified scam reports	rare	a85b3d8b-4b87-46c2-93ee-d6c1ab9af4a4	verified_scam_reports	{"value": 10}	150	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
bcff86a3-7d9d-4b20-a6ae-c3027c9ec49d	moon_shot	Moon Shot	🚀	10x on single position	rare	863988a2-a6f8-48ef-8cb4-3234402d7be9	trade_return	{"value": 1000}	120	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
585aee68-1bbe-40d7-9fd1-c58b70697281	whale	Whale	🐋	$100k+ portfolio verified	rare	863988a2-a6f8-48ef-8cb4-3234402d7be9	portfolio_value	{"value": 100000}	100	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
f20be7f5-e42c-45d9-94bd-5dd32d76f498	thirty_day_streak	Monthly Grinder	🔥🔥🔥	Posted 30 days in a row	rare	98699e2e-99b9-402e-b715-9f589d87b7d8	streak	{"value": 30}	150	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
8d734d40-ebc8-46ff-8cce-11546e25c275	hot_take	Hot Take	🔥	Post with 500+ upvotes	rare	23f0ee23-2eda-4407-a5dd-efce0e3d88c2	single_post_upvotes	{"value": 500}	100	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
b1dfa0da-c314-407c-a734-86beb90d584c	influencer	Influencer	🌟	1000 followers	rare	98699e2e-99b9-402e-b715-9f589d87b7d8	follower_count	{"value": 1000}	120	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
49b67519-1a61-408e-8457-044a1cb2aa95	alpha_king	Alpha King	👑	25 verified calls, 80% hit rate	legendary	23f0ee23-2eda-4407-a5dd-efce0e3d88c2	alpha_king	{"calls": 25, "accuracy": 80}	500	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
bf7ee83a-18ea-4aaa-bb25-dc2ca316d49d	fud_lord	FUD Lord	🧌	Posted bearish take that aged like milk	legendary	424ab542-4f6c-4030-8e47-6ae85fbf4066	fud_lord	{"value": 1}	400	t	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
7ad7e413-f683-48f2-bd28-62a8cc2369c2	titanium_hands	Titanium Hands	💎✨	Held 1yr+ through multiple cycles	legendary	863988a2-a6f8-48ef-8cb4-3234402d7be9	hold_duration	{"value": 365}	500	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
5e8dd994-266d-4646-a57d-82734d430b7f	sentinel	Sentinel	🏰	50 verified scam reports	legendary	a85b3d8b-4b87-46c2-93ee-d6c1ab9af4a4	verified_scam_reports	{"value": 50}	500	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
e3eed8e4-9912-464c-91bf-0f2fa303206e	legendary_caller	Legendary Caller	🔮	100x+ gain verified	legendary	863988a2-a6f8-48ef-8cb4-3234402d7be9	trade_return	{"value": 10000}	500	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
bb094d7b-f299-4c0b-8971-536c484193d6	hall_of_fame	Hall of Fame	🏆	5 posts with 1000+ upvotes	legendary	23f0ee23-2eda-4407-a5dd-efce0e3d88c2	legendary_posts	{"value": 5}	400	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
9b4420a3-9437-493d-9750-71514df8429e	og	OG	🎖️	First 1000 users	legendary	424ab542-4f6c-4030-8e47-6ae85fbf4066	early_user	{"value": 1000}	300	f	t	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
a16fe174-66c9-499e-9fd1-2082232e01d1	hundred_day_streak	Absolute Unit	🔥🔥🔥🔥	Posted 100 days straight	legendary	98699e2e-99b9-402e-b715-9f589d87b7d8	streak	{"value": 100}	500	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
537d4317-0710-478b-a94c-135a18c93ef2	celebrity	Celebrity	👑	5000 followers	legendary	98699e2e-99b9-402e-b715-9f589d87b7d8	follower_count	{"value": 5000}	400	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
6af5142c-9b37-4f4d-8a66-8410bf155d58	leviathan	Leviathan	🐋	$1M+ portfolio verified	legendary	863988a2-a6f8-48ef-8cb4-3234402d7be9	portfolio_value	{"value": 1000000}	500	f	f	\N	2026-04-10 13:16:27.588465+02	2026-04-10 13:16:27.588465+02
\.


--
-- Data for Name: ban_prevention_configs; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.ban_prevention_configs (id, name, jitter_requests, jitter_min_ms, jitter_max_ms, rotate_user_agents, user_agent_pool, randomize_fingerprint, tls_fingerprints, distribute_geographically, preferred_regions, mimic_human_behavior, business_hours_only, random_session_duration, stay_below_limit_percentage, burst_protection, created_at, updated_at) FROM stdin;
c425a151-e92c-4163-a92c-877bfd817810	global	t	100	500	t	[]	t	[]	t	["us-east", "eu-west", "ap-south"]	t	f	t	80.00	t	2026-04-09 19:34:57.619977+02	2026-04-09 19:34:57.619977+02
\.


--
-- Data for Name: bot_advisor_insights; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.bot_advisor_insights (id, category, priority, title, description, context, data_points, trend_direction, confidence, suggested_actions, suggested_actions_detailed, estimated_impact_usd, estimated_impact_description, status, acknowledged, acknowledged_by, acknowledged_at, implemented, implemented_at, implementation_notes, created_at) FROM stdin;
\.


--
-- Data for Name: bot_logs; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.bot_logs (id, user_id, platform, chat_id, command, command_args, response_text, response_type, processing_time_ms, created_at) FROM stdin;
\.


--
-- Data for Name: bot_protection_rules; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.bot_protection_rules (id, rule_name, patterns, max_requests_per_minute, max_requests_per_hour, action_on_detect, auto_freeze, is_active, created_at) FROM stdin;
5c147f28-f57c-410b-b957-8341618eb12a	Rapid Request Detection	["rapid_requests"]	10	100	block	t	t	2026-04-09 19:34:56.393821
32431e81-5a6f-4d13-bde8-fa1ce4fb74b5	Unusual Hours Detection	["unusual_hours"]	5	50	require_approval	f	t	2026-04-09 19:34:56.393821
594cf4dd-9819-4247-91f3-ed0c147177f1	IP Switching Detection	["ip_switching"]	5	30	block	t	t	2026-04-09 19:34:56.393821
24244e65-91de-4e32-8e40-a7514ef82dba	Pattern Recognition	["automated_patterns"]	8	80	require_approval	t	t	2026-04-09 19:34:56.393821
\.


--
-- Data for Name: briefing_templates; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.briefing_templates (id, name, enabled_sections, custom_metrics, alert_thresholds, schedule, delivery_time, timezone, email_recipients, webhook_url, include_charts, include_raw_data, format, created_at, updated_at) FROM stdin;
8eab3045-10a2-4bae-8d51-11d0bf9943c9	Daily Executive Briefing	["market_overview", "crm_v1_status", "crm_v2_progress", "financial_summary", "system_health", "recommendations"]	[]	{}	daily	09:00:00	UTC	["admin@rmi.io"]	\N	t	f	html	2026-04-09 19:34:55.373222	2026-04-09 19:34:55.373222
\.


--
-- Data for Name: chain_configs; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.chain_configs (id, chain, rpc_endpoints, chain_id, derivation_path, address_prefix, confirmation_blocks, max_gas_price, is_active) FROM stdin;
\.


--
-- Data for Name: comparison_items; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.comparison_items (id, aspect, llc_structure, dao_structure, changes_required, estimated_impact, cost_estimate, created_at) FROM stdin;
1ff9b3a1-c828-4f37-87d4-36c9ddeb2ce7	Governance	Member-managed or Manager-managed	Token-weighted voting by all holders	["Create governance smart contracts", "Implement voting mechanisms", "Establish proposal thresholds"]	Fundamental - all decisions become transparent and on-chain	15000.00	2026-04-09 19:34:55.820779
3d493f93-b048-44ed-9397-a8250303c89d	Decision Making	Centralized with managers/members	Decentralized voting by token holders	["Draft governance charter", "Set voting periods", "Define quorum requirements"]	Significant - slower but more democratic	5000.00	2026-04-09 19:34:55.820779
509d5142-8bf0-4616-a7bc-76a30eb12b3e	Profit Distribution	Member distributions at discretion	Automatic via smart contract dividends	["Develop dividend distribution contract", "Set distribution triggers", "Implement tax withholding"]	High - eliminates discretion but ensures fairness	10000.00	2026-04-09 19:34:55.820779
089869f3-8f38-4584-8167-1368648b2512	Liability Protection	Limited liability for members	Uncertain legal status - evolving	["Legal review of DAO structure", "Consider liability insurance", "Document risk disclosures"]	Medium - legal uncertainty	20000.00	2026-04-09 19:34:55.820779
02e4073a-8e20-4623-9f66-37df65c80a21	Tax Treatment	Pass-through to members	Uncertain - potential entity-level taxation	["Consult crypto tax specialist", "Document all transactions", "Prepare for IRS scrutiny"]	High - significant uncertainty	15000.00	2026-04-09 19:34:55.820779
da9f320a-031b-447e-895e-3bf8ffa9f906	Operational Control	Managers control operations	Community votes on major decisions	["Define operational vs governance decisions", "Create operational multisig", "Establish emergency powers"]	High - loss of operational agility	8000.00	2026-04-09 19:34:55.820779
\.


--
-- Data for Name: compliance_requirements; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.compliance_requirements (id, area, title, description, wyoming_statute, legal_reference, current_status, previous_status, status_changed_at, requirements, evidence_required, evidence_submitted, reviewed_by, reviewed_at, issues_found, remediation_plan, remediation_deadline, priority, is_blocker, fund_separation_verified, commingling_detected, commingling_details, created_at, updated_at) FROM stdin;
d73059cd-851d-47a5-a56d-6be43936cefe	legal_structure	Wyoming DAO LLC Registration	Register as Wyoming DAO LLC under new legislation	W.S. 17-31-101 et seq.	\N	in_progress	\N	\N	["File registration documents", "Pay registration fees", "Publish notice"]	[]	[]	\N	\N	[]	\N	\N	critical	t	\N	\N	\N	2026-04-09 19:34:55.836363	2026-04-09 19:34:55.836363
d598caf1-9d3a-4764-8b73-311e61c5911b	smart_contract_audit	Governance Contract Audit	Complete professional audit of governance contracts	Best practice	\N	not_started	\N	\N	["Hire audit firm", "Fix identified issues", "Publish audit report"]	[]	[]	\N	\N	[]	\N	\N	critical	t	\N	\N	\N	2026-04-09 19:34:55.836363	2026-04-09 19:34:55.836363
573de685-8388-4aa3-9f11-5dddc4eda511	governance_framework	Governance Charter	Draft and ratify DAO governance charter	Operating Agreement	\N	in_progress	\N	\N	["Draft charter", "Legal review", "Member vote"]	[]	[]	\N	\N	[]	\N	\N	high	t	\N	\N	\N	2026-04-09 19:34:55.836363	2026-04-09 19:34:55.836363
3a028439-b999-4c38-aa6f-e64ad8af46c2	tax_obligations	Tax Structure Analysis	Analyze tax implications of DAO structure	IRS guidance	\N	not_started	\N	\N	["Consult tax attorney", "Document positions", "File appropriate forms"]	[]	[]	\N	\N	[]	\N	\N	high	f	\N	\N	\N	2026-04-09 19:34:55.836363	2026-04-09 19:34:55.836363
097f6f9e-8207-4610-a659-c7ba02acdc12	treasury_management	Treasury Multisig Setup	Establish secure treasury management with multisig	Fiduciary duty	\N	not_started	\N	\N	["Select signers", "Set thresholds", "Test transactions"]	[]	[]	\N	\N	[]	\N	\N	high	t	\N	\N	\N	2026-04-09 19:34:55.836363	2026-04-09 19:34:55.836363
0dcbfd7c-7a45-4978-9297-80ff0f82d58d	member_agreements	Member Onboarding	Onboard all token holders as DAO members	Membership requirements	\N	not_started	\N	\N	["Verify holdings", "Execute agreements", "Grant access"]	[]	[]	\N	\N	[]	\N	\N	medium	f	\N	\N	\N	2026-04-09 19:34:55.836363	2026-04-09 19:34:55.836363
\.


--
-- Data for Name: content_calendars; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.content_calendars (id, name, description, start_date, end_date, content_ids, narrative_distribution, platform_distribution, target_posts_per_day, target_engagement_rate, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: content_performance; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.content_performance (id, content_id, platform, impressions, reach, engagements, engagement_rate, likes, comments, shares, clicks, saves, profile_visits, follows, top_locations, age_distribution, device_breakdown, best_hour, peak_engagement_time, collected_at) FROM stdin;
\.


--
-- Data for Name: content_pieces; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.content_pieces (id, title, content_type, platforms, headline, body_text, hashtags, mentions, call_to_action, images, videos, gifs, links, platform_versions, narrative_focus, target_audience, key_messages, status, priority, scheduled_for, timezone, auto_post, predicted_engagement, best_posting_time, actual_engagement, impressions, clicks, shares, likes, comments, tags, campaign_id, created_at, updated_at, created_by, approved_by, approved_at, published_at) FROM stdin;
\.


--
-- Data for Name: content_templates; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.content_templates (id, template_name, content_type, narrative_focus, headline_template, body_template, cta_template, variables, example_fill, platform_tips, times_used, avg_engagement, is_active, created_at) FROM stdin;
179845fc-5f8a-4521-ae38-a6b51a408af8	Scam Alert	alert	scam_prevention	🚨 {scam_type} Alert: {headline}	We've detected a new {scam_type} targeting crypto users. {details}\\n\\nHow to protect yourself:\\n{protection_steps}	Share this to protect others	[]	{}	{}	0	0.00	t	2026-04-09 19:34:57.042931
f6b67dd2-1578-411d-bfd4-136603996632	Security Tip	education	wallet_security	💡 Wallet Security Tip: {tip_title}	Keep your crypto safe with these best practices:\\n\\n{tip_content}	Join our security newsletter	[]	{}	{}	0	0.00	t	2026-04-09 19:34:57.042931
f210b1b6-45e7-4705-8f02-d9c1ec86abfc	Investigation Update	news	investigation	🔍 Investigation Update: {case_name}	Our team has made progress on the {case_name} investigation. Here's what we found:\\n\\n{findings}	Support our work	[]	{}	{}	0	0.00	t	2026-04-09 19:34:57.042931
03577f37-f0ef-4a6b-b831-fb92478d4d10	Community Win	community	community_protection	✅ Community Protection Win!	Thanks to our vigilant community, we prevented {prevention_details}. Together we're making crypto safer!	Join the community	[]	{}	{}	0	0.00	t	2026-04-09 19:34:57.042931
\.


--
-- Data for Name: contract_deployments; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.contract_deployments (id, name, chain, contract_type, contract_address, deployer_address, transaction_hash, status, deployment_log, config, verified, verified_at, verification_source, deployment_cost_eth, deployment_cost_usd, gas_used, explorer_url, dexscreener_url, dextools_url, deployed_at, created_at, deployed_by) FROM stdin;
\.


--
-- Data for Name: contract_templates; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.contract_templates (id, name, contract_type, chain, version, solidity_code, bytecode, abi, configurable_params, default_params, description, audited, auditor, audit_report_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: credential_access_logs; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.credential_access_logs (id, credential_id, action, performed_by, ip_address, user_agent, device_fingerprint, geo_location, success, failure_reason, api_endpoint_called, request_details, created_at) FROM stdin;
\.


--
-- Data for Name: credential_pool_credentials; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.credential_pool_credentials (id, pool_id, credential_id, is_active, usage_count, added_at) FROM stdin;
\.


--
-- Data for Name: credential_pools; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.credential_pools (id, name, description, provider_type, max_accounts, provision_trigger, threshold_percentage, rotate_credentials, rotation_interval_days, auto_generate_emails, email_provider, email_domain, total_provisioned, last_provisioned_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: critical_alerts; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.critical_alerts (id, alert_type, severity, title, description, details, source_system, source_metric, threshold_breached, current_value, status, acknowledged_by, acknowledged_at, resolved_by, resolved_at, escalation_level, escalated_at, recommended_actions, actions_taken, notifications_sent, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: crm_holders; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.crm_holders (id, wallet_address, balance, balance_usd, first_purchase_at, first_purchase_tx, is_contract, exchange_name, last_updated, created_at) FROM stdin;
\.


--
-- Data for Name: crm_staking; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.crm_staking (id, user_id, wallet_address, amount, tier, rewards_earned, last_claim_at, status, unstake_requested_at, unstake_completes_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: crm_v1_wallets; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.crm_v1_wallets (id, wallet_address, chain, reported_balance, reported_balance_usd, transaction_count, first_seen, last_seen, status, verification_notes, verified_by, verified_at, eligible_for_v2, v2_allocation, v2_claimed, v2_claimed_at, tags, risk_score, associations, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cross_checks; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.cross_checks (id, wallet_id, check_type, source, data_hash, verified, discrepancies, confidence_score, raw_data, checked_at, checked_by) FROM stdin;
\.


--
-- Data for Name: dao_proposals; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.dao_proposals (id, title, description, proposer, action_type, target_contract, call_data, value_eth, votes_for, votes_against, votes_abstain, quorum_required, voters, status, start_time, end_time, executed_at, executed_by, created_at) FROM stdin;
\.


--
-- Data for Name: dao_treasury; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.dao_treasury (id, chain, treasury_address, native_balance, native_balance_usd, token_balances, total_token_value_usd, total_value_usd, allocated_to_operations, allocated_to_development, allocated_to_marketing, allocated_to_liquidity, unallocated, inflows_24h, outflows_24h, updated_at) FROM stdin;
\.


--
-- Data for Name: dashboard_configs; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.dashboard_configs (id, user_id, widgets, theme, timezone, default_time_range, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: design_revisions; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.design_revisions (id, page_id, revision_number, page_content, change_summary, change_type, created_by, created_by_type, review_status, reviewed_by, reviewed_at, review_notes, created_at) FROM stdin;
\.


--
-- Data for Name: discount_code_usage; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.discount_code_usage (id, code_id, user_id, order_id, discount_amount, used_at) FROM stdin;
\.


--
-- Data for Name: discount_codes; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.discount_codes (id, code, discount_type, discount_value, max_uses, used_count, max_uses_per_user, valid_from, valid_until, is_active, eligible_wallet_id, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: education_bookmarks; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.education_bookmarks (id, user_id, content_id, notes, created_at) FROM stdin;
\.


--
-- Data for Name: education_categories; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.education_categories (id, slug, name, description, icon, color, sort_order, content_count, total_views, created_at) FROM stdin;
32e67863-c461-4296-b63a-17bfe0b3d2f0	crypto-basics	Crypto Basics	Fundamentals of cryptocurrency and blockchain	📚	#10b981	1	0	0	2026-04-10 13:17:35.973546+02
e2bc6cfb-e932-4d00-b699-076eae280bb9	wallet-security	Wallet Security	How to secure your crypto wallets	🔐	#10b981	2	0	0	2026-04-10 13:17:35.973546+02
39eb7175-ca69-46b4-abd0-ac3a26659539	scam-prevention	Scam Prevention	Learn to identify and avoid scams	🛡️	#10b981	3	0	0	2026-04-10 13:17:35.973546+02
c3620673-87a7-43ab-b6d1-138fd78f59f7	defi-guides	DeFi Guides	Understanding decentralized finance	💰	#10b981	4	0	0	2026-04-10 13:17:35.973546+02
4ac927d4-cf69-4e6a-8503-67f6f0af45bc	trading-basics	Trading Basics	Introduction to crypto trading	📈	#10b981	5	0	0	2026-04-10 13:17:35.973546+02
723b73a9-f37c-4d11-8919-32f0a4685044	technical-analysis	Technical Analysis	Chart reading and indicators	📊	#10b981	6	0	0	2026-04-10 13:17:35.973546+02
1baf341b-2863-478e-aa65-6a600f81f8ad	nft-guide	NFT Guide	Understanding NFTs and markets	🖼️	#10b981	7	0	0	2026-04-10 13:17:35.973546+02
cdd45971-7382-43bd-a9e1-578062f5dd62	advanced-topics	Advanced Topics	Deep dives into complex topics	🔬	#10b981	8	0	0	2026-04-10 13:17:35.973546+02
\.


--
-- Data for Name: education_content; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.education_content (id, category_id, slug, title, description, content, content_type, difficulty, thumbnail_url, video_url, attachments, estimated_read_time, tags, keywords, view_count, like_count, completion_count, is_published, is_featured, is_premium, author_id, reviewed_by, published_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: education_likes; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.education_likes (id, user_id, content_id, created_at) FROM stdin;
\.


--
-- Data for Name: education_progress; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.education_progress (id, user_id, content_id, progress_percent, is_completed, completed_at, time_spent_seconds, last_position, quiz_score, quiz_answers, last_accessed_at, created_at) FROM stdin;
\.


--
-- Data for Name: encrypted_wallets; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.encrypted_wallets (id, wallet_name, wallet_type, chain, address, public_key, encryption_version, encrypted_private_key, encrypted_key_part_2, encrypted_key_part_3, primary_storage, backup_storage_1, backup_storage_2, offline_backup_exists, key_derivation_salt, encryption_iv, key_shares_required, key_shares_total, status, is_multisig, multisig_threshold, multisig_total_signers, created_at, last_rotated, rotation_schedule_days, next_rotation_due, rotation_count, security_level, access_count, last_accessed, last_accessed_by, balance, balance_usd, last_balance_update, tags, notes, updated_at) FROM stdin;
\.


--
-- Data for Name: final_investigations; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.final_investigations (id, title, description, tokens_investigated, platforms_investigated, time_period_start, time_period_end, lead_investigator, investigators, status, findings, executive_summary, key_conclusions, recommendations, legal_implications, recommended_legal_actions, full_report_url, redacted_report_url, created_at, updated_at, closed_at) FROM stdin;
\.


--
-- Data for Name: forum_categories; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.forum_categories (id, slug, name, description, icon, color, post_count, subscriber_count, is_private, requires_verification, allow_anonymous, created_by, moderators, created_at, updated_at) FROM stdin;
cfc3d75e-a3c7-46be-b2d6-0098d1704d92	scam-reports	Scam Reports	Report and discuss crypto scams and rug pulls	🚨	#ef4444	0	0	f	f	f	\N	{}	2026-04-10 13:17:35.965276+02	2026-04-10 13:17:35.965276+02
8b56a836-759d-490c-bcc3-a8b5c2f07b92	rug-pulls	Rug Pulls	Specific discussions about rug pull incidents	💀	#dc2626	0	0	f	f	f	\N	{}	2026-04-10 13:17:35.965276+02	2026-04-10 13:17:35.965276+02
30b86511-bc62-4f74-b072-d6fb121a89a5	honeypots	Honeypots	Identify and analyze honeypot scams	🍯	#f59e0b	0	0	f	f	f	\N	{}	2026-04-10 13:17:35.965276+02	2026-04-10 13:17:35.965276+02
560d62a8-b8b8-4f23-8971-d3f271c25f9c	phishing	Phishing Alerts	Phishing attempts and wallet drainers	🎣	#3b82f6	0	0	f	f	f	\N	{}	2026-04-10 13:17:35.965276+02	2026-04-10 13:17:35.965276+02
ff19589d-af9f-4ec9-b9df-3398097e11e6	general	General Crypto	General cryptocurrency discussions	💬	#10b981	0	0	f	f	f	\N	{}	2026-04-10 13:17:35.965276+02	2026-04-10 13:17:35.965276+02
f9b5c919-b9d4-4bcf-a184-e3cde44f2d28	announcements	Announcements	Official RMI announcements	📢	#8b5cf6	0	0	f	f	f	\N	{}	2026-04-10 13:17:35.965276+02	2026-04-10 13:17:35.965276+02
\.


--
-- Data for Name: forum_comment_votes; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.forum_comment_votes (id, user_id, comment_id, vote_type, created_at) FROM stdin;
\.


--
-- Data for Name: forum_comments; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.forum_comments (id, post_id, author_id, parent_comment_id, content, content_type, upvotes, downvotes, is_deleted, is_anonymous, is_solution, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: forum_posts; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.forum_posts (id, category_id, author_id, title, content, content_type, images, attachments, upvotes, downvotes, view_count, comment_count, is_pinned, is_locked, is_deleted, is_anonymous, is_scam_report, reported_wallet_addresses, reported_token_address, scam_type, scam_status, evidence_links, last_activity_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: forum_subscriptions; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.forum_subscriptions (id, user_id, category_id, created_at) FROM stdin;
\.


--
-- Data for Name: forum_votes; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.forum_votes (id, user_id, post_id, vote_type, created_at) FROM stdin;
\.


--
-- Data for Name: fund_separation_accounts; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.fund_separation_accounts (id, account_name, account_type, wallet_address, bank_account, opening_balance, current_balance, currency, purpose, allowed_uses, prohibited_uses, transactions, last_reconciled, reconciliation_status, created_at, updated_at) FROM stdin;
210edeb9-6fe5-466c-b0a2-9d64d9bfc6c3	RMI Operating Account	business	\N	\N	0.00	0.00	USD	Day-to-day business operations	["Salaries", "Software", "Marketing", "Office expenses"]	["Personal expenses", "Non-business investments"]	[]	\N	pending	2026-04-09 19:34:55.375394	2026-04-09 19:34:55.375394
038d4f0b-9b62-4bb4-bd68-92405f7d3b28	RMI Treasury Wallet	treasury	\N	\N	0.00	0.00	USD	Crypto treasury and investments	["Staking", "Yield farming", "Strategic investments"]	["Operational expenses", "Personal use"]	[]	\N	pending	2026-04-09 19:34:55.375394	2026-04-09 19:34:55.375394
2811f910-c759-47cb-8443-9453bcbc3e7d	RMI Development Fund	operational	\N	\N	0.00	0.00	USD	Product development expenses	["Contractor payments", "Infrastructure", "Development tools"]	["Personal expenses", "Non-dev costs"]	[]	\N	pending	2026-04-09 19:34:55.375394	2026-04-09 19:34:55.375394
\.


--
-- Data for Name: generated_emails; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.generated_emails (id, email_address, display_name, provider, domain, purpose, associated_services, password_credential_id, recovery_email, recovery_phone, is_active, is_flagged, flag_reason, forwards_to, auto_delete_after_days, created_at, last_used) FROM stdin;
\.


--
-- Data for Name: health_check_results; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.health_check_results (id, endpoint_id, "timestamp", status, latency_ms, http_status, error_message, dns_resolution_ms, connection_ms, tls_handshake_ms, time_to_first_byte_ms, response_valid, response_checksum) FROM stdin;
\.


--
-- Data for Name: historical_timelines; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.historical_timelines (id, entity_id, entity_type, events, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: intelligence_briefings; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.intelligence_briefings (id, date, generated_at, sections, total_revenue_24h, total_users_24h, api_calls_24h, new_investigations, crm_v1_wallets_verified, crm_v1_anomalies, crm_v2_contracts_deployed, crm_v2_holders, priority_alerts, insights, recommendations, sent_to, opened_by, sent_at, created_at) FROM stdin;
\.


--
-- Data for Name: investigation_findings; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.investigation_findings (id, investigation_id, title, description, finding_type, severity, confidence, evidence, witnesses, documents, related_findings, related_addresses, status, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: key_shares; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.key_shares (id, wallet_id, share_index, encrypted_share, storage_location, requires_approval, approvers_required, created_at, last_accessed) FROM stdin;
\.


--
-- Data for Name: launch_failure_analyses; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.launch_failure_analyses (id, token_launch_id, failure_type, severity, failure_date, first_detected_date, root_causes, contributing_factors, technical_problems, contract_vulnerabilities, tokenomics_flaws, liquidity_issues, market_conditions, platform_problems, fee_structure_issues, financial_loss_usd, holder_count_at_failure, reputation_impact, lessons_learned, what_could_have_prevented, recommendations, investigated_by, investigation_date, investigation_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: legal_compliance; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.legal_compliance (id, check_type, title, description, status, priority, wyoming_requirement, wyoming_statute_reference, due_date, completed_at, reminder_days, required_documents, uploaded_documents, verified_by, verified_at, notes, fund_separation_verified, commingling_detected, commingling_details, created_at, updated_at) FROM stdin;
c8e84154-8c5b-48ad-8cb7-bd0ca4327b31	fund_separation	Business/Personal Fund Separation	Ensure all business funds are completely separated from personal funds	not_started	critical	Wyoming LLC Act requires maintenance of separate records	\N	\N	\N	30	["Bank statements", "Transaction logs"]	[]	\N	\N	\N	\N	\N	\N	2026-04-09 19:34:55.369903	2026-04-09 19:34:55.369903
b775d03e-0052-4990-93e9-489b78927c71	llc_filing	Articles of Organization Filing	File or verify Articles of Organization with Wyoming Secretary of State	not_started	critical	W.S. 17-29-201	\N	\N	\N	30	["Articles of Organization", "Filing receipt"]	[]	\N	\N	\N	\N	\N	\N	2026-04-09 19:34:55.369903	2026-04-09 19:34:55.369903
52c5220f-22c3-4aa3-bab4-838eaa49e24b	operating_agreement	Operating Agreement	Draft and execute comprehensive Operating Agreement	not_started	high	Required for LLC governance	\N	\N	\N	30	["Signed Operating Agreement", "Member signatures"]	[]	\N	\N	\N	\N	\N	\N	2026-04-09 19:34:55.369903	2026-04-09 19:34:55.369903
93e07712-331a-4223-ab2d-136643b4bec0	tax_documentation	EIN and Tax Setup	Obtain EIN and set up tax accounts	not_started	high	IRS requirement	\N	\N	\N	30	["EIN confirmation", "Tax registration"]	[]	\N	\N	\N	\N	\N	\N	2026-04-09 19:34:55.369903	2026-04-09 19:34:55.369903
01f20279-2d33-4101-8ce8-7bbf2f74a384	dao_charter	DAO Charter Documentation	Document DAO governance structure and charter	not_started	medium	Best practice for DAO LLCs	\N	\N	\N	30	["Charter document", "Governance framework"]	[]	\N	\N	\N	\N	\N	\N	2026-04-09 19:34:55.369903	2026-04-09 19:34:55.369903
10da3946-5c4d-489e-8e4f-7dd04a352261	annual_report	Annual Report Filing	File annual report with Wyoming	not_started	high	W.S. 17-29-209 - Due annually	\N	\N	\N	30	["Annual report form", "Filing fee"]	[]	\N	\N	\N	\N	\N	\N	2026-04-09 19:34:55.369903	2026-04-09 19:34:55.369903
\.


--
-- Data for Name: legal_opinions; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.legal_opinions (id, topic, summary, detailed_analysis, legal_risks, mitigation_strategies, recommended_actions, alternative_approaches, attorney_name, attorney_firm, date_issued, status, created_at) FROM stdin;
\.


--
-- Data for Name: munchmaps_scans; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.munchmaps_scans (id, user_id, wallet_address, chain, wallet_type, risk_score, scan_type, results, report_url, scan_cost, data_sources_used, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: newsletter_campaigns; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.newsletter_campaigns (id, name, subject, html_content, text_content, template_id, target_tiers, target_tags, exclude_tags, scheduled_at, sent_at, status, recipients_count, delivered_count, opened_count, clicked_count, bounced_count, complained_count, unsubscribed_count, open_rate, click_rate, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: newsletter_subscribers; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.newsletter_subscribers (id, email, status, tier, first_name, last_name, company, wallet_address, is_crm_v1_holder, is_crm_v2_holder, crm_tokens_held, preferences, emails_sent, emails_opened, emails_clicked, last_opened, last_clicked, engagement_score, payment_status, payment_due_date, payment_amount, subscription_expires, tags, source, confirmed, confirmed_at, confirmation_token, created_at, updated_at, unsubscribed_at) FROM stdin;
\.


--
-- Data for Name: notification_configs; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.notification_configs (id, name, telegram_bot_token, telegram_chat_id, email_smtp_host, email_smtp_port, email_username, email_credential_id, email_recipients, webhook_url, webhook_secret_credential_id, notify_on_severity, notify_on_component, daily_digest_enabled, digest_time, created_at, updated_at) FROM stdin;
dd6ed80f-a62a-4776-8da9-05ec30b8f13b	default	\N	\N	\N	587	\N	\N	[]	\N	\N	["critical", "high"]	[]	t	09:00:00	2026-04-09 19:34:57.624943+02	2026-04-09 19:34:57.624943+02
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.notifications (id, user_id, type, title, message, link, is_read, read_at, actor_id, created_at) FROM stdin;
\.


--
-- Data for Name: password_parts; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.password_parts (id, wallet_id, part_name, encrypted_part, storage_location, auto_rotate, last_rotated, next_rotation, rotation_interval_days, created_at) FROM stdin;
\.


--
-- Data for Name: password_policies; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.password_policies (id, policy_name, min_length, max_length, require_uppercase, require_lowercase, require_numbers, require_special, special_chars, avoid_ambiguous, prevent_dictionary, prevent_patterns, prevent_reuse, max_age_days, notify_before_days, is_active, created_at) FROM stdin;
02391c82-7ce6-41ff-840f-583ef94528cc	Default High Security	32	64	t	t	t	t	!@#$%^&*()_+-=[]{}|;:,.<>?	t	t	t	5	90	7	t	2026-04-09 19:34:56.811453
ee185e1f-4ad6-4685-a845-78ce4601d28e	API Keys	64	128	t	t	t	t	!@#$%^&*()_+-=[]{}|;:,.<>?	t	t	t	5	30	7	t	2026-04-09 19:34:56.811453
f9fde1e9-4161-4354-9fbb-3ea0f0ef73ad	Service Accounts	24	48	t	t	t	t	!@#$%^&*()_+-=[]{}|;:,.<>?	t	t	t	5	60	7	t	2026-04-09 19:34:56.811453
\.


--
-- Data for Name: platform_infiltrations; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.platform_infiltrations (id, token_launch_id, platform_name, fees, hidden_costs, unexpected_fees, platform_control_issues, censorship_attempts, delisting_threats, detected_manipulation, suspicious_transactions, total_fees_paid_usd, total_hidden_costs_usd, estimated_platform_extracted_value, first_issue_date, last_issue_date, evidence_links, screenshots, transaction_hashes, notes, created_at) FROM stdin;
\.


--
-- Data for Name: posting_schedules; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.posting_schedules (id, platform, best_days, best_hours, posts_per_day, min_interval_hours, content_distribution, narrative_distribution, is_active, updated_at) FROM stdin;
302b686e-efb9-4069-a1a5-26c143e45a4f	twitter	["tuesday", "wednesday", "thursday"]	[9, 12, 15, 18]	4	2	{"news": 30, "alert": 20, "community": 25, "education": 25}	{"threat_intel": 25, "scam_prevention": 30, "wallet_security": 25, "community_protection": 20}	t	2026-04-09 19:34:57.044993
0e21bd8d-d56c-42f9-b0d8-0e20bb57530f	telegram	["monday", "wednesday", "friday", "saturday"]	[10, 14, 19, 21]	3	3	{"news": 30, "alert": 40, "community": 10, "education": 20}	{"threat_intel": 35, "investigation": 20, "scam_prevention": 30, "community_protection": 15}	t	2026-04-09 19:34:57.044993
\.


--
-- Data for Name: provisioned_accounts; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.provisioned_accounts (id, credential_pool_id, credential_id, provider_type, account_email, endpoint_id, provisioned_at, provisioned_reason, triggered_by_endpoint_id, status, requests_made, last_used_at, estimated_monthly_cost) FROM stdin;
\.


--
-- Data for Name: revenue_streams; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.revenue_streams (id, name, source, category, monthly_revenue, monthly_costs, monthly_profit, profit_margin, growth_rate_mom, growth_rate_yoy, projected_3m, projected_6m, projected_12m, status, updated_at) FROM stdin;
\.


--
-- Data for Name: route_requests; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.route_requests (id, "timestamp", routing_group_id, endpoint_id, method, path, source_ip, user_agent, latency_ms, response_status, response_size_bytes, success, error_message, cached, rate_limited, retry_count) FROM stdin;
\.


--
-- Data for Name: routing_alerts; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.routing_alerts (id, title, description, severity, component_id, component_type, endpoint_id, routing_group_id, alert_type, metrics, suggested_action, status, created_at, acknowledged_at, acknowledged_by, resolved_at, resolved_by, resolution_notes, auto_resolved, notifications_sent) FROM stdin;
\.


--
-- Data for Name: routing_analytics_hourly; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.routing_analytics_hourly (id, hour, routing_group_id, endpoint_id, total_requests, successful_requests, failed_requests, cached_requests, rate_limited_requests, avg_latency_ms, min_latency_ms, max_latency_ms, p95_latency_ms, p99_latency_ms, error_4xx_count, error_5xx_count, timeout_count) FROM stdin;
\.


--
-- Data for Name: routing_group_endpoints; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.routing_group_endpoints (id, routing_group_id, endpoint_id, is_active, added_at) FROM stdin;
\.


--
-- Data for Name: routing_groups; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.routing_groups (id, name, description, provider_type, strategy, latency_threshold_ms, error_rate_threshold, auto_provision_enabled, max_backup_endpoints, provision_credential_pool, overall_status, current_latency_ms, total_requests_today, error_rate, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: routing_rules; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.routing_rules (id, name, priority, enabled, source_ip_pattern, path_pattern, header_conditions, time_window_start, time_window_end, target_routing_group_id, add_headers, rate_limit_override, cache_ttl, require_auth, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: security_alerts; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.security_alerts (id, alert_type, severity, wallet_id, tx_request_id, description, evidence, status, resolved_by, resolved_at, auto_actions, created_at) FROM stdin;
\.


--
-- Data for Name: service_accounts; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.service_accounts (id, service_name, service_category, account_email, account_username, account_type, credentials, is_active, is_verified, verification_pending, usage_limits, current_usage, billing_cycle, next_billing_date, cost_per_month, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stored_credentials; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.stored_credentials (id, service_name, service_category, credential_type, encrypted_value, encrypted_backup, encryption_salt, encryption_version, username, email, account_id, api_endpoint, login_url, dashboard_url, docs_url, auto_rotate, rotation_frequency, last_rotated, next_rotation, rotation_count, status, expires_at, access_count, last_accessed, last_accessed_by, description, tags, metadata, created_at, updated_at, created_by) FROM stdin;
\.


--
-- Data for Name: system_alerts; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.system_alerts (id, severity, title, message, source, status, resolved_at, resolved_by, resolution_notes, acknowledged_at, acknowledged_by, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: system_config; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.system_config (id, key, value, description, updated_by, updated_at, created_at) FROM stdin;
15783c48-0f2f-46cc-8a4e-ce8632b15a73	pricing	{"munchmaps": {"free": {"scans": 5, "monthly": 0, "api_calls": 10}, "starter": {"scans": 100, "monthly": 49, "api_calls": 1000}, "enterprise": {"scans": null, "monthly": 999, "api_calls": 100000}, "professional": {"scans": 500, "monthly": 199, "api_calls": 10000}, "law_enforcement": {"scans": 500, "monthly": 0, "api_calls": 10000}}, "pay_per_scan": {"forensic_deep_scan": 5, "threat_intel_package": 10, "continuous_monitoring": 500, "pig_butcherer_specialist": 15}}	Product pricing configuration	\N	2026-04-09 19:34:54.704502	2026-04-09 19:34:54.704502
\.


--
-- Data for Name: token_holder_snapshots; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.token_holder_snapshots (id, token_launch_id, snapshot_date, total_holders, total_supply, circulating_supply, top_holders, distribution_stats, transactions_24h, volume_24h_usd, price_usd, market_cap_usd, block_number, snapshot_source) FROM stdin;
\.


--
-- Data for Name: token_launches; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.token_launches (id, token_symbol, token_name, token_type, launch_date, platform, platform_specific, contract_address, deployer_address, transaction_hash, total_supply, initial_circulating_supply, initial_price_usd, team_allocation_percent, team_allocation_locked, team_vesting_schedule, initial_liquidity_usd, liquidity_locked, liquidity_lock_duration_days, launch_status, current_status, launch_narrative, actual_outcome, created_at, updated_at) FROM stdin;
b9d39ab3-b13d-4d9a-a04c-ce7040efa2dd	$CRM	CRM Token	erc20	2023-01-15 00:00:00	ethereum	\N	\N	\N	\N	1000000000.00000000	\N	\N	0.00	f	\N	\N	f	\N	failed	investigating	Community rewards and governance token for the Rug Munch ecosystem	\N	2026-04-09 19:34:55.827793	2026-04-09 19:34:55.827793
7f4d53ec-f591-42f1-aa4c-97c9fd78f32f	$cryptorugmunch	Crypto Rug Munch	erc20	2022-06-01 00:00:00	bsc	\N	\N	\N	\N	1000000000000.00000000	\N	\N	0.00	f	\N	\N	f	\N	failed	investigating	Meme token with utility features for the community	\N	2026-04-09 19:34:55.827793	2026-04-09 19:34:55.827793
\.


--
-- Data for Name: transaction_requests; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.transaction_requests (id, wallet_id, tx_type, recipient_address, amount, currency, contract_address, contract_data, gas_limit, gas_price, max_fee_per_gas, required_approvals, approvals_received, approvers, status, expires_at, risk_score, risk_flags, executed_at, executed_by, tx_hash, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.transactions (id, user_id, product, transaction_type, amount, currency, status, tier, billing_period, scan_type, wallet_address, payment_provider, provider_transaction_id, description, metadata, refunded_at, refund_amount, refund_reason, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: transition_milestones; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.transition_milestones (id, phase, title, description, target_date, completed_date, dependencies, blocking, status, completion_percentage, deliverables, owner, contributors, notes, risks, is_blocker, created_at, updated_at) FROM stdin;
0ba0a964-3081-488c-94e1-fdde0a63dbd6	assessment	Current State Assessment	Complete assessment of current LLC structure and requirements	\N	\N	[]	[]	completed	100	[]	\N	[]	\N	[]	f	2026-04-09 19:34:55.833733	2026-04-09 19:34:55.833733
7ea56c47-1016-4004-81c4-59a7fa1ee661	planning	DAO Structure Design	Design optimal DAO governance structure for Wyoming legal framework	\N	\N	[]	[]	completed	100	[]	\N	[]	\N	[]	f	2026-04-09 19:34:55.833733	2026-04-09 19:34:55.833733
14db1650-e55a-47a5-8289-c67687307759	documentation	Operating Agreement Update	Draft new operating agreement for DAO LLC structure	\N	\N	[]	[]	in_progress	60	[]	\N	[]	\N	[]	t	2026-04-09 19:34:55.833733	2026-04-09 19:34:55.833733
1b1abc15-93d8-4f1c-8ad8-7ddcec35135d	smart_contract_deployment	Governance Contract Deployment	Deploy and audit governance smart contracts	\N	\N	[]	[]	not_started	0	[]	\N	[]	\N	[]	t	2026-04-09 19:34:55.833733	2026-04-09 19:34:55.833733
98853ac7-67cc-403a-a419-076e9627e802	governance_setup	Initial Governance Setup	Configure initial governance parameters and permissions	\N	\N	[]	[]	not_started	0	[]	\N	[]	\N	[]	f	2026-04-09 19:34:55.833733	2026-04-09 19:34:55.833733
bde9d155-f300-4d7f-92aa-db3aacc4b644	treasury_migration	Treasury Migration Plan	Plan and execute migration of treasury to DAO control	\N	\N	[]	[]	not_started	0	[]	\N	[]	\N	[]	t	2026-04-09 19:34:55.833733	2026-04-09 19:34:55.833733
331d73f3-f564-4be2-85d5-a096cb3b4655	member_onboarding	Token Holder Onboarding	Onboard existing token holders as DAO members	\N	\N	[]	[]	not_started	0	[]	\N	[]	\N	[]	f	2026-04-09 19:34:55.833733	2026-04-09 19:34:55.833733
912f46d1-3433-44d5-8d7a-e6c4861e033c	testing	Governance Testing	Test governance mechanisms before full activation	\N	\N	[]	[]	not_started	0	[]	\N	[]	\N	[]	f	2026-04-09 19:34:55.833733	2026-04-09 19:34:55.833733
b0f7b73b-5a98-42c4-8135-a0a5751c599e	launch	DAO Launch	Official launch of Autonomous Agent DAO LLC	\N	\N	[]	[]	not_started	0	[]	\N	[]	\N	[]	f	2026-04-09 19:34:55.833733	2026-04-09 19:34:55.833733
\.


--
-- Data for Name: transition_reports; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.transition_reports (id, generated_at, period_start, period_end, executive_summary, key_findings, recommendations, milestone_progress, compliance_matrix, transition_costs, budget_vs_actual, immediate_actions, upcoming_deadlines, generated_by) FROM stdin;
\.


--
-- Data for Name: trending_topics; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.trending_topics (id, topic, keywords, platform, trend_score, volume_24h, velocity, category, sentiment, relevance_to_rugmunch, recommended_action, sources, detected_at, expires_at) FROM stdin;
\.


--
-- Data for Name: user_activity; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.user_activity (id, user_id, activity_type, entity_type, entity_id, metadata, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: user_badges; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.user_badges (id, user_id, badge_id, earned_at, earned_via, metadata) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.user_sessions (id, user_id, session_token, ip_address, user_agent, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_social_connections; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.user_social_connections (id, user_id, provider, provider_user_id, username, access_token, refresh_token, expires_at, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: user_stats; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.user_stats (id, user_id, post_count, comment_count, alpha_calls_count, verified_alpha_count, viral_memes_count, total_upvotes_received, total_downvotes_received, helpful_marks_received, follower_count, following_count, current_streak, longest_streak, last_post_date, wallet_connected, portfolio_value, total_trades, winning_trades, losing_trades, best_trade_return, worst_trade_return, scam_reports_submitted, verified_scam_reports, total_xp, current_level, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_streaks; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.user_streaks (id, user_id, current_streak, longest_streak, streak_start_date, last_activity_date, total_days_active, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.users (id, email, username, full_name, company, phone, country, password_hash, is_verified, is_admin, is_law_enforcement, le_badge_number, le_agency, le_verified_at, le_verified_by, status, suspended_at, suspension_reason, suspended_by, subscriptions, total_api_calls, total_scans, total_spent, last_login, login_count, created_at, updated_at) FROM stdin;
8f6bb683-cec4-445e-b1ed-dcdcf42718a4	admin@rmi.io	admin	RMI Administrator	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	active	\N	\N	\N	{"crm_v2": {"tier": "enterprise"}, "munchmaps": {"tier": "enterprise"}}	0	0	0.00	\N	0	2026-04-09 19:34:54.70189	2026-04-09 19:34:54.70189
\.


--
-- Data for Name: wallet_rotations; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.wallet_rotations (id, old_wallet_id, new_wallet_id, rotation_reason, initiated_by, approved_by, funds_transferred, transfer_amount, transfer_tx_hash, status, started_at, completed_at, verification_hash) FROM stdin;
\.


--
-- Data for Name: wallet_verification_attempts; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.wallet_verification_attempts (id, wallet_address, user_id, method, status, message, signature, verified_at, created_at) FROM stdin;
\.


--
-- Data for Name: website_pages; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.website_pages (id, project_id, name, slug, page_type, meta_title, meta_description, meta_keywords, og_image, components, custom_css, custom_js, views, unique_visitors, avg_time_on_page, bounce_rate, status, is_published, published_version, created_at, updated_at, last_published_at) FROM stdin;
\.


--
-- Data for Name: website_projects; Type: TABLE DATA; Schema: public; Owner: rmi_user
--

COPY public.website_projects (id, name, domain, description, brand_colors, brand_fonts, logo_url, favicon_url, meta_title, meta_description, meta_keywords, google_analytics_id, pixel_id, status, is_published, published_at, pages, created_at, updated_at, created_by) FROM stdin;
\.


--
-- Name: access_logs access_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.access_logs
    ADD CONSTRAINT access_logs_pkey PRIMARY KEY (id);


--
-- Name: admin_logs admin_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.admin_logs
    ADD CONSTRAINT admin_logs_pkey PRIMARY KEY (id);


--
-- Name: admin_recovery_keys admin_recovery_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.admin_recovery_keys
    ADD CONSTRAINT admin_recovery_keys_pkey PRIMARY KEY (id);


--
-- Name: admin_recovery_requests admin_recovery_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.admin_recovery_requests
    ADD CONSTRAINT admin_recovery_requests_pkey PRIMARY KEY (id);


--
-- Name: ai_provider_health ai_provider_health_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.ai_provider_health
    ADD CONSTRAINT ai_provider_health_pkey PRIMARY KEY (id);


--
-- Name: ai_provider_health ai_provider_health_provider_name_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.ai_provider_health
    ADD CONSTRAINT ai_provider_health_provider_name_key UNIQUE (provider_name);


--
-- Name: ai_provider_usage ai_provider_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.ai_provider_usage
    ADD CONSTRAINT ai_provider_usage_pkey PRIMARY KEY (id);


--
-- Name: ai_provider_usage ai_provider_usage_provider_name_date_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.ai_provider_usage
    ADD CONSTRAINT ai_provider_usage_provider_name_date_key UNIQUE (provider_name, date);


--
-- Name: ai_request_log ai_request_log_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.ai_request_log
    ADD CONSTRAINT ai_request_log_pkey PRIMARY KEY (id);


--
-- Name: ai_website_requests ai_website_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.ai_website_requests
    ADD CONSTRAINT ai_website_requests_pkey PRIMARY KEY (id);


--
-- Name: ai_website_results ai_website_results_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.ai_website_results
    ADD CONSTRAINT ai_website_results_pkey PRIMARY KEY (id);


--
-- Name: airdrop_eligible_wallets airdrop_eligible_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.airdrop_eligible_wallets
    ADD CONSTRAINT airdrop_eligible_wallets_pkey PRIMARY KEY (id);


--
-- Name: airdrop_eligible_wallets airdrop_eligible_wallets_wallet_address_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.airdrop_eligible_wallets
    ADD CONSTRAINT airdrop_eligible_wallets_wallet_address_key UNIQUE (wallet_address);


--
-- Name: api_credential_updates api_credential_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.api_credential_updates
    ADD CONSTRAINT api_credential_updates_pkey PRIMARY KEY (id);


--
-- Name: api_endpoints api_endpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.api_endpoints
    ADD CONSTRAINT api_endpoints_pkey PRIMARY KEY (id);


--
-- Name: api_logs api_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.api_logs
    ADD CONSTRAINT api_logs_pkey PRIMARY KEY (id);


--
-- Name: app_suggestions app_suggestions_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.app_suggestions
    ADD CONSTRAINT app_suggestions_pkey PRIMARY KEY (id);


--
-- Name: approval_policies approval_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.approval_policies
    ADD CONSTRAINT approval_policies_pkey PRIMARY KEY (id);


--
-- Name: auto_content_suggestions auto_content_suggestions_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.auto_content_suggestions
    ADD CONSTRAINT auto_content_suggestions_pkey PRIMARY KEY (id);


--
-- Name: badge_categories badge_categories_name_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.badge_categories
    ADD CONSTRAINT badge_categories_name_key UNIQUE (name);


--
-- Name: badge_categories badge_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.badge_categories
    ADD CONSTRAINT badge_categories_pkey PRIMARY KEY (id);


--
-- Name: badge_leaderboard badge_leaderboard_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.badge_leaderboard
    ADD CONSTRAINT badge_leaderboard_pkey PRIMARY KEY (id);


--
-- Name: badge_leaderboard badge_leaderboard_user_id_period_period_start_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.badge_leaderboard
    ADD CONSTRAINT badge_leaderboard_user_id_period_period_start_key UNIQUE (user_id, period, period_start);


--
-- Name: badge_progress badge_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.badge_progress
    ADD CONSTRAINT badge_progress_pkey PRIMARY KEY (id);


--
-- Name: badge_progress badge_progress_user_id_badge_id_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.badge_progress
    ADD CONSTRAINT badge_progress_user_id_badge_id_key UNIQUE (user_id, badge_id);


--
-- Name: badge_unlock_log badge_unlock_log_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.badge_unlock_log
    ADD CONSTRAINT badge_unlock_log_pkey PRIMARY KEY (id);


--
-- Name: badges badges_badge_id_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.badges
    ADD CONSTRAINT badges_badge_id_key UNIQUE (badge_id);


--
-- Name: badges badges_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.badges
    ADD CONSTRAINT badges_pkey PRIMARY KEY (id);


--
-- Name: ban_prevention_configs ban_prevention_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.ban_prevention_configs
    ADD CONSTRAINT ban_prevention_configs_pkey PRIMARY KEY (id);


--
-- Name: bot_advisor_insights bot_advisor_insights_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.bot_advisor_insights
    ADD CONSTRAINT bot_advisor_insights_pkey PRIMARY KEY (id);


--
-- Name: bot_logs bot_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.bot_logs
    ADD CONSTRAINT bot_logs_pkey PRIMARY KEY (id);


--
-- Name: bot_protection_rules bot_protection_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.bot_protection_rules
    ADD CONSTRAINT bot_protection_rules_pkey PRIMARY KEY (id);


--
-- Name: briefing_templates briefing_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.briefing_templates
    ADD CONSTRAINT briefing_templates_pkey PRIMARY KEY (id);


--
-- Name: chain_configs chain_configs_chain_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.chain_configs
    ADD CONSTRAINT chain_configs_chain_key UNIQUE (chain);


--
-- Name: chain_configs chain_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.chain_configs
    ADD CONSTRAINT chain_configs_pkey PRIMARY KEY (id);


--
-- Name: comparison_items comparison_items_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.comparison_items
    ADD CONSTRAINT comparison_items_pkey PRIMARY KEY (id);


--
-- Name: compliance_requirements compliance_requirements_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.compliance_requirements
    ADD CONSTRAINT compliance_requirements_pkey PRIMARY KEY (id);


--
-- Name: content_calendars content_calendars_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.content_calendars
    ADD CONSTRAINT content_calendars_pkey PRIMARY KEY (id);


--
-- Name: content_performance content_performance_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.content_performance
    ADD CONSTRAINT content_performance_pkey PRIMARY KEY (id);


--
-- Name: content_pieces content_pieces_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.content_pieces
    ADD CONSTRAINT content_pieces_pkey PRIMARY KEY (id);


--
-- Name: content_templates content_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.content_templates
    ADD CONSTRAINT content_templates_pkey PRIMARY KEY (id);


--
-- Name: contract_deployments contract_deployments_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.contract_deployments
    ADD CONSTRAINT contract_deployments_pkey PRIMARY KEY (id);


--
-- Name: contract_templates contract_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.contract_templates
    ADD CONSTRAINT contract_templates_pkey PRIMARY KEY (id);


--
-- Name: credential_access_logs credential_access_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.credential_access_logs
    ADD CONSTRAINT credential_access_logs_pkey PRIMARY KEY (id);


--
-- Name: credential_pool_credentials credential_pool_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.credential_pool_credentials
    ADD CONSTRAINT credential_pool_credentials_pkey PRIMARY KEY (id);


--
-- Name: credential_pool_credentials credential_pool_credentials_pool_id_credential_id_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.credential_pool_credentials
    ADD CONSTRAINT credential_pool_credentials_pool_id_credential_id_key UNIQUE (pool_id, credential_id);


--
-- Name: credential_pools credential_pools_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.credential_pools
    ADD CONSTRAINT credential_pools_pkey PRIMARY KEY (id);


--
-- Name: critical_alerts critical_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.critical_alerts
    ADD CONSTRAINT critical_alerts_pkey PRIMARY KEY (id);


--
-- Name: crm_holders crm_holders_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.crm_holders
    ADD CONSTRAINT crm_holders_pkey PRIMARY KEY (id);


--
-- Name: crm_holders crm_holders_wallet_address_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.crm_holders
    ADD CONSTRAINT crm_holders_wallet_address_key UNIQUE (wallet_address);


--
-- Name: crm_staking crm_staking_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.crm_staking
    ADD CONSTRAINT crm_staking_pkey PRIMARY KEY (id);


--
-- Name: crm_v1_wallets crm_v1_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.crm_v1_wallets
    ADD CONSTRAINT crm_v1_wallets_pkey PRIMARY KEY (id);


--
-- Name: cross_checks cross_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.cross_checks
    ADD CONSTRAINT cross_checks_pkey PRIMARY KEY (id);


--
-- Name: dao_proposals dao_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.dao_proposals
    ADD CONSTRAINT dao_proposals_pkey PRIMARY KEY (id);


--
-- Name: dao_treasury dao_treasury_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.dao_treasury
    ADD CONSTRAINT dao_treasury_pkey PRIMARY KEY (id);


--
-- Name: dashboard_configs dashboard_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.dashboard_configs
    ADD CONSTRAINT dashboard_configs_pkey PRIMARY KEY (id);


--
-- Name: dashboard_configs dashboard_configs_user_id_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.dashboard_configs
    ADD CONSTRAINT dashboard_configs_user_id_key UNIQUE (user_id);


--
-- Name: design_revisions design_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.design_revisions
    ADD CONSTRAINT design_revisions_pkey PRIMARY KEY (id);


--
-- Name: discount_code_usage discount_code_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.discount_code_usage
    ADD CONSTRAINT discount_code_usage_pkey PRIMARY KEY (id);


--
-- Name: discount_codes discount_codes_code_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.discount_codes
    ADD CONSTRAINT discount_codes_code_key UNIQUE (code);


--
-- Name: discount_codes discount_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.discount_codes
    ADD CONSTRAINT discount_codes_pkey PRIMARY KEY (id);


--
-- Name: education_bookmarks education_bookmarks_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.education_bookmarks
    ADD CONSTRAINT education_bookmarks_pkey PRIMARY KEY (id);


--
-- Name: education_bookmarks education_bookmarks_user_id_content_id_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.education_bookmarks
    ADD CONSTRAINT education_bookmarks_user_id_content_id_key UNIQUE (user_id, content_id);


--
-- Name: education_categories education_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.education_categories
    ADD CONSTRAINT education_categories_pkey PRIMARY KEY (id);


--
-- Name: education_categories education_categories_slug_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.education_categories
    ADD CONSTRAINT education_categories_slug_key UNIQUE (slug);


--
-- Name: education_content education_content_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.education_content
    ADD CONSTRAINT education_content_pkey PRIMARY KEY (id);


--
-- Name: education_content education_content_slug_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.education_content
    ADD CONSTRAINT education_content_slug_key UNIQUE (slug);


--
-- Name: education_likes education_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.education_likes
    ADD CONSTRAINT education_likes_pkey PRIMARY KEY (id);


--
-- Name: education_likes education_likes_user_id_content_id_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.education_likes
    ADD CONSTRAINT education_likes_user_id_content_id_key UNIQUE (user_id, content_id);


--
-- Name: education_progress education_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.education_progress
    ADD CONSTRAINT education_progress_pkey PRIMARY KEY (id);


--
-- Name: education_progress education_progress_user_id_content_id_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.education_progress
    ADD CONSTRAINT education_progress_user_id_content_id_key UNIQUE (user_id, content_id);


--
-- Name: encrypted_wallets encrypted_wallets_address_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.encrypted_wallets
    ADD CONSTRAINT encrypted_wallets_address_key UNIQUE (address);


--
-- Name: encrypted_wallets encrypted_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.encrypted_wallets
    ADD CONSTRAINT encrypted_wallets_pkey PRIMARY KEY (id);


--
-- Name: final_investigations final_investigations_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.final_investigations
    ADD CONSTRAINT final_investigations_pkey PRIMARY KEY (id);


--
-- Name: forum_categories forum_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_categories
    ADD CONSTRAINT forum_categories_pkey PRIMARY KEY (id);


--
-- Name: forum_categories forum_categories_slug_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_categories
    ADD CONSTRAINT forum_categories_slug_key UNIQUE (slug);


--
-- Name: forum_comment_votes forum_comment_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_comment_votes
    ADD CONSTRAINT forum_comment_votes_pkey PRIMARY KEY (id);


--
-- Name: forum_comment_votes forum_comment_votes_user_id_comment_id_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_comment_votes
    ADD CONSTRAINT forum_comment_votes_user_id_comment_id_key UNIQUE (user_id, comment_id);


--
-- Name: forum_comments forum_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_comments
    ADD CONSTRAINT forum_comments_pkey PRIMARY KEY (id);


--
-- Name: forum_posts forum_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_pkey PRIMARY KEY (id);


--
-- Name: forum_subscriptions forum_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_subscriptions
    ADD CONSTRAINT forum_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: forum_subscriptions forum_subscriptions_user_id_category_id_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_subscriptions
    ADD CONSTRAINT forum_subscriptions_user_id_category_id_key UNIQUE (user_id, category_id);


--
-- Name: forum_votes forum_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_votes
    ADD CONSTRAINT forum_votes_pkey PRIMARY KEY (id);


--
-- Name: forum_votes forum_votes_user_id_post_id_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_votes
    ADD CONSTRAINT forum_votes_user_id_post_id_key UNIQUE (user_id, post_id);


--
-- Name: fund_separation_accounts fund_separation_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.fund_separation_accounts
    ADD CONSTRAINT fund_separation_accounts_pkey PRIMARY KEY (id);


--
-- Name: generated_emails generated_emails_email_address_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.generated_emails
    ADD CONSTRAINT generated_emails_email_address_key UNIQUE (email_address);


--
-- Name: generated_emails generated_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.generated_emails
    ADD CONSTRAINT generated_emails_pkey PRIMARY KEY (id);


--
-- Name: health_check_results health_check_results_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.health_check_results
    ADD CONSTRAINT health_check_results_pkey PRIMARY KEY (id);


--
-- Name: historical_timelines historical_timelines_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.historical_timelines
    ADD CONSTRAINT historical_timelines_pkey PRIMARY KEY (id);


--
-- Name: intelligence_briefings intelligence_briefings_date_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.intelligence_briefings
    ADD CONSTRAINT intelligence_briefings_date_key UNIQUE (date);


--
-- Name: intelligence_briefings intelligence_briefings_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.intelligence_briefings
    ADD CONSTRAINT intelligence_briefings_pkey PRIMARY KEY (id);


--
-- Name: investigation_findings investigation_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.investigation_findings
    ADD CONSTRAINT investigation_findings_pkey PRIMARY KEY (id);


--
-- Name: key_shares key_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.key_shares
    ADD CONSTRAINT key_shares_pkey PRIMARY KEY (id);


--
-- Name: key_shares key_shares_wallet_id_share_index_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.key_shares
    ADD CONSTRAINT key_shares_wallet_id_share_index_key UNIQUE (wallet_id, share_index);


--
-- Name: launch_failure_analyses launch_failure_analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.launch_failure_analyses
    ADD CONSTRAINT launch_failure_analyses_pkey PRIMARY KEY (id);


--
-- Name: legal_compliance legal_compliance_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.legal_compliance
    ADD CONSTRAINT legal_compliance_pkey PRIMARY KEY (id);


--
-- Name: legal_opinions legal_opinions_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.legal_opinions
    ADD CONSTRAINT legal_opinions_pkey PRIMARY KEY (id);


--
-- Name: munchmaps_scans munchmaps_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.munchmaps_scans
    ADD CONSTRAINT munchmaps_scans_pkey PRIMARY KEY (id);


--
-- Name: newsletter_campaigns newsletter_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.newsletter_campaigns
    ADD CONSTRAINT newsletter_campaigns_pkey PRIMARY KEY (id);


--
-- Name: newsletter_subscribers newsletter_subscribers_email_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.newsletter_subscribers
    ADD CONSTRAINT newsletter_subscribers_email_key UNIQUE (email);


--
-- Name: newsletter_subscribers newsletter_subscribers_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.newsletter_subscribers
    ADD CONSTRAINT newsletter_subscribers_pkey PRIMARY KEY (id);


--
-- Name: notification_configs notification_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.notification_configs
    ADD CONSTRAINT notification_configs_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: password_parts password_parts_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.password_parts
    ADD CONSTRAINT password_parts_pkey PRIMARY KEY (id);


--
-- Name: password_parts password_parts_wallet_id_part_name_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.password_parts
    ADD CONSTRAINT password_parts_wallet_id_part_name_key UNIQUE (wallet_id, part_name);


--
-- Name: password_policies password_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.password_policies
    ADD CONSTRAINT password_policies_pkey PRIMARY KEY (id);


--
-- Name: platform_infiltrations platform_infiltrations_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.platform_infiltrations
    ADD CONSTRAINT platform_infiltrations_pkey PRIMARY KEY (id);


--
-- Name: posting_schedules posting_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.posting_schedules
    ADD CONSTRAINT posting_schedules_pkey PRIMARY KEY (id);


--
-- Name: posting_schedules posting_schedules_platform_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.posting_schedules
    ADD CONSTRAINT posting_schedules_platform_key UNIQUE (platform);


--
-- Name: provisioned_accounts provisioned_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.provisioned_accounts
    ADD CONSTRAINT provisioned_accounts_pkey PRIMARY KEY (id);


--
-- Name: revenue_streams revenue_streams_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.revenue_streams
    ADD CONSTRAINT revenue_streams_pkey PRIMARY KEY (id);


--
-- Name: route_requests route_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.route_requests
    ADD CONSTRAINT route_requests_pkey PRIMARY KEY (id);


--
-- Name: routing_alerts routing_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.routing_alerts
    ADD CONSTRAINT routing_alerts_pkey PRIMARY KEY (id);


--
-- Name: routing_analytics_hourly routing_analytics_hourly_hour_routing_group_id_endpoint_id_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.routing_analytics_hourly
    ADD CONSTRAINT routing_analytics_hourly_hour_routing_group_id_endpoint_id_key UNIQUE (hour, routing_group_id, endpoint_id);


--
-- Name: routing_analytics_hourly routing_analytics_hourly_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.routing_analytics_hourly
    ADD CONSTRAINT routing_analytics_hourly_pkey PRIMARY KEY (id);


--
-- Name: routing_group_endpoints routing_group_endpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.routing_group_endpoints
    ADD CONSTRAINT routing_group_endpoints_pkey PRIMARY KEY (id);


--
-- Name: routing_group_endpoints routing_group_endpoints_routing_group_id_endpoint_id_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.routing_group_endpoints
    ADD CONSTRAINT routing_group_endpoints_routing_group_id_endpoint_id_key UNIQUE (routing_group_id, endpoint_id);


--
-- Name: routing_groups routing_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.routing_groups
    ADD CONSTRAINT routing_groups_pkey PRIMARY KEY (id);


--
-- Name: routing_rules routing_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.routing_rules
    ADD CONSTRAINT routing_rules_pkey PRIMARY KEY (id);


--
-- Name: security_alerts security_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.security_alerts
    ADD CONSTRAINT security_alerts_pkey PRIMARY KEY (id);


--
-- Name: service_accounts service_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.service_accounts
    ADD CONSTRAINT service_accounts_pkey PRIMARY KEY (id);


--
-- Name: stored_credentials stored_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.stored_credentials
    ADD CONSTRAINT stored_credentials_pkey PRIMARY KEY (id);


--
-- Name: system_alerts system_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.system_alerts
    ADD CONSTRAINT system_alerts_pkey PRIMARY KEY (id);


--
-- Name: system_config system_config_key_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_key_key UNIQUE (key);


--
-- Name: system_config system_config_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_pkey PRIMARY KEY (id);


--
-- Name: token_holder_snapshots token_holder_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.token_holder_snapshots
    ADD CONSTRAINT token_holder_snapshots_pkey PRIMARY KEY (id);


--
-- Name: token_launches token_launches_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.token_launches
    ADD CONSTRAINT token_launches_pkey PRIMARY KEY (id);


--
-- Name: transaction_requests transaction_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.transaction_requests
    ADD CONSTRAINT transaction_requests_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: transition_milestones transition_milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.transition_milestones
    ADD CONSTRAINT transition_milestones_pkey PRIMARY KEY (id);


--
-- Name: transition_reports transition_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.transition_reports
    ADD CONSTRAINT transition_reports_pkey PRIMARY KEY (id);


--
-- Name: trending_topics trending_topics_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.trending_topics
    ADD CONSTRAINT trending_topics_pkey PRIMARY KEY (id);


--
-- Name: user_activity user_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.user_activity
    ADD CONSTRAINT user_activity_pkey PRIMARY KEY (id);


--
-- Name: user_badges user_badges_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_pkey PRIMARY KEY (id);


--
-- Name: user_badges user_badges_user_id_badge_id_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_user_id_badge_id_key UNIQUE (user_id, badge_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_session_token_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_session_token_key UNIQUE (session_token);


--
-- Name: user_social_connections user_social_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.user_social_connections
    ADD CONSTRAINT user_social_connections_pkey PRIMARY KEY (id);


--
-- Name: user_social_connections user_social_connections_user_id_provider_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.user_social_connections
    ADD CONSTRAINT user_social_connections_user_id_provider_key UNIQUE (user_id, provider);


--
-- Name: user_stats user_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.user_stats
    ADD CONSTRAINT user_stats_pkey PRIMARY KEY (id);


--
-- Name: user_stats user_stats_user_id_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.user_stats
    ADD CONSTRAINT user_stats_user_id_key UNIQUE (user_id);


--
-- Name: user_streaks user_streaks_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.user_streaks
    ADD CONSTRAINT user_streaks_pkey PRIMARY KEY (id);


--
-- Name: user_streaks user_streaks_user_id_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.user_streaks
    ADD CONSTRAINT user_streaks_user_id_key UNIQUE (user_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: wallet_rotations wallet_rotations_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.wallet_rotations
    ADD CONSTRAINT wallet_rotations_pkey PRIMARY KEY (id);


--
-- Name: wallet_verification_attempts wallet_verification_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.wallet_verification_attempts
    ADD CONSTRAINT wallet_verification_attempts_pkey PRIMARY KEY (id);


--
-- Name: website_pages website_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.website_pages
    ADD CONSTRAINT website_pages_pkey PRIMARY KEY (id);


--
-- Name: website_projects website_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.website_projects
    ADD CONSTRAINT website_projects_pkey PRIMARY KEY (id);


--
-- Name: idx_access_logs_action; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_access_logs_action ON public.access_logs USING btree (action);


--
-- Name: idx_access_logs_created; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_access_logs_created ON public.access_logs USING btree (created_at);


--
-- Name: idx_access_logs_performed_by; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_access_logs_performed_by ON public.access_logs USING btree (performed_by);


--
-- Name: idx_access_logs_wallet; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_access_logs_wallet ON public.access_logs USING btree (wallet_id);


--
-- Name: idx_activity_user; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_activity_user ON public.user_activity USING btree (user_id, created_at DESC);


--
-- Name: idx_admin_logs_action; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_admin_logs_action ON public.admin_logs USING btree (action);


--
-- Name: idx_admin_logs_admin_id; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_admin_logs_admin_id ON public.admin_logs USING btree (admin_id);


--
-- Name: idx_admin_logs_created_at; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_admin_logs_created_at ON public.admin_logs USING btree (created_at);


--
-- Name: idx_admin_logs_target; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_admin_logs_target ON public.admin_logs USING btree (target_type, target_id);


--
-- Name: idx_advisor_insights_acknowledged; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_advisor_insights_acknowledged ON public.bot_advisor_insights USING btree (acknowledged);


--
-- Name: idx_advisor_insights_category; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_advisor_insights_category ON public.bot_advisor_insights USING btree (category);


--
-- Name: idx_advisor_insights_priority; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_advisor_insights_priority ON public.bot_advisor_insights USING btree (priority);


--
-- Name: idx_advisor_insights_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_advisor_insights_status ON public.bot_advisor_insights USING btree (status);


--
-- Name: idx_airdrop_claimed; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_airdrop_claimed ON public.airdrop_eligible_wallets USING btree (claimed);


--
-- Name: idx_airdrop_wallet; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_airdrop_wallet ON public.airdrop_eligible_wallets USING btree (wallet_address);


--
-- Name: idx_alerts_created_at; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_alerts_created_at ON public.system_alerts USING btree (created_at);


--
-- Name: idx_alerts_severity; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_alerts_severity ON public.system_alerts USING btree (severity);


--
-- Name: idx_alerts_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_alerts_status ON public.system_alerts USING btree (status);


--
-- Name: idx_api_endpoints_priority; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_api_endpoints_priority ON public.api_endpoints USING btree (priority);


--
-- Name: idx_api_endpoints_provider_type; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_api_endpoints_provider_type ON public.api_endpoints USING btree (provider_type);


--
-- Name: idx_api_endpoints_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_api_endpoints_status ON public.api_endpoints USING btree (status);


--
-- Name: idx_api_logs_created_at; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_api_logs_created_at ON public.api_logs USING btree (created_at);


--
-- Name: idx_api_logs_endpoint; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_api_logs_endpoint ON public.api_logs USING btree (endpoint);


--
-- Name: idx_api_logs_product; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_api_logs_product ON public.api_logs USING btree (product);


--
-- Name: idx_api_logs_status_code; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_api_logs_status_code ON public.api_logs USING btree (status_code);


--
-- Name: idx_api_logs_user_id; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_api_logs_user_id ON public.api_logs USING btree (user_id);


--
-- Name: idx_app_suggestions_category; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_app_suggestions_category ON public.app_suggestions USING btree (category);


--
-- Name: idx_app_suggestions_priority; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_app_suggestions_priority ON public.app_suggestions USING btree (priority_score);


--
-- Name: idx_app_suggestions_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_app_suggestions_status ON public.app_suggestions USING btree (status);


--
-- Name: idx_auto_suggestions_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_auto_suggestions_status ON public.auto_content_suggestions USING btree (status);


--
-- Name: idx_badge_leaderboard_period; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_badge_leaderboard_period ON public.badge_leaderboard USING btree (period, period_start);


--
-- Name: idx_badge_progress_percentage; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_badge_progress_percentage ON public.badge_progress USING btree (progress_percentage DESC);


--
-- Name: idx_badge_progress_user_id; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_badge_progress_user_id ON public.badge_progress USING btree (user_id);


--
-- Name: idx_badge_unlock_log_user_id; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_badge_unlock_log_user_id ON public.badge_unlock_log USING btree (user_id);


--
-- Name: idx_bot_logs_command; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_bot_logs_command ON public.bot_logs USING btree (command);


--
-- Name: idx_bot_logs_created_at; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_bot_logs_created_at ON public.bot_logs USING btree (created_at);


--
-- Name: idx_bot_logs_platform; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_bot_logs_platform ON public.bot_logs USING btree (platform);


--
-- Name: idx_bot_logs_user_id; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_bot_logs_user_id ON public.bot_logs USING btree (user_id);


--
-- Name: idx_briefings_date; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_briefings_date ON public.intelligence_briefings USING btree (date);


--
-- Name: idx_compliance_requirements_area; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_compliance_requirements_area ON public.compliance_requirements USING btree (area);


--
-- Name: idx_compliance_requirements_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_compliance_requirements_status ON public.compliance_requirements USING btree (current_status);


--
-- Name: idx_content_pieces_narrative; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_content_pieces_narrative ON public.content_pieces USING btree (narrative_focus);


--
-- Name: idx_content_pieces_scheduled; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_content_pieces_scheduled ON public.content_pieces USING btree (scheduled_for);


--
-- Name: idx_content_pieces_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_content_pieces_status ON public.content_pieces USING btree (status);


--
-- Name: idx_content_pieces_type; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_content_pieces_type ON public.content_pieces USING btree (content_type);


--
-- Name: idx_contract_deployments_chain; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_contract_deployments_chain ON public.contract_deployments USING btree (chain);


--
-- Name: idx_contract_deployments_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_contract_deployments_status ON public.contract_deployments USING btree (status);


--
-- Name: idx_contract_deployments_type; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_contract_deployments_type ON public.contract_deployments USING btree (contract_type);


--
-- Name: idx_credential_logs_action; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_credential_logs_action ON public.credential_access_logs USING btree (action);


--
-- Name: idx_credential_logs_created; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_credential_logs_created ON public.credential_access_logs USING btree (created_at);


--
-- Name: idx_credential_logs_credential; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_credential_logs_credential ON public.credential_access_logs USING btree (credential_id);


--
-- Name: idx_critical_alerts_severity; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_critical_alerts_severity ON public.critical_alerts USING btree (severity);


--
-- Name: idx_critical_alerts_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_critical_alerts_status ON public.critical_alerts USING btree (status);


--
-- Name: idx_critical_alerts_type; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_critical_alerts_type ON public.critical_alerts USING btree (alert_type);


--
-- Name: idx_crm_holders_balance; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_crm_holders_balance ON public.crm_holders USING btree (balance DESC);


--
-- Name: idx_crm_holders_created_at; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_crm_holders_created_at ON public.crm_holders USING btree (created_at);


--
-- Name: idx_crm_staking_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_crm_staking_status ON public.crm_staking USING btree (status);


--
-- Name: idx_crm_staking_user_id; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_crm_staking_user_id ON public.crm_staking USING btree (user_id);


--
-- Name: idx_crm_v1_wallets_address; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_crm_v1_wallets_address ON public.crm_v1_wallets USING btree (wallet_address);


--
-- Name: idx_crm_v1_wallets_chain; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_crm_v1_wallets_chain ON public.crm_v1_wallets USING btree (chain);


--
-- Name: idx_crm_v1_wallets_eligible; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_crm_v1_wallets_eligible ON public.crm_v1_wallets USING btree (eligible_for_v2);


--
-- Name: idx_crm_v1_wallets_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_crm_v1_wallets_status ON public.crm_v1_wallets USING btree (status);


--
-- Name: idx_cross_checks_type; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_cross_checks_type ON public.cross_checks USING btree (check_type);


--
-- Name: idx_cross_checks_wallet; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_cross_checks_wallet ON public.cross_checks USING btree (wallet_id);


--
-- Name: idx_dao_proposals_proposer; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_dao_proposals_proposer ON public.dao_proposals USING btree (proposer);


--
-- Name: idx_dao_proposals_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_dao_proposals_status ON public.dao_proposals USING btree (status);


--
-- Name: idx_dao_treasury_chain; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_dao_treasury_chain ON public.dao_treasury USING btree (chain);


--
-- Name: idx_discount_code; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_discount_code ON public.discount_codes USING btree (code);


--
-- Name: idx_education_category; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_education_category ON public.education_content USING btree (category_id);


--
-- Name: idx_education_progress_user; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_education_progress_user ON public.education_progress USING btree (user_id);


--
-- Name: idx_education_published; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_education_published ON public.education_content USING btree (is_published, published_at);


--
-- Name: idx_education_slug; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_education_slug ON public.education_content USING btree (slug);


--
-- Name: idx_encrypted_wallets_address; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_encrypted_wallets_address ON public.encrypted_wallets USING btree (address);


--
-- Name: idx_encrypted_wallets_chain; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_encrypted_wallets_chain ON public.encrypted_wallets USING btree (chain);


--
-- Name: idx_encrypted_wallets_security; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_encrypted_wallets_security ON public.encrypted_wallets USING btree (security_level);


--
-- Name: idx_encrypted_wallets_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_encrypted_wallets_status ON public.encrypted_wallets USING btree (status);


--
-- Name: idx_encrypted_wallets_type; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_encrypted_wallets_type ON public.encrypted_wallets USING btree (wallet_type);


--
-- Name: idx_forum_comments_post; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_forum_comments_post ON public.forum_comments USING btree (post_id);


--
-- Name: idx_forum_posts_activity; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_forum_posts_activity ON public.forum_posts USING btree (last_activity_at DESC);


--
-- Name: idx_forum_posts_author; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_forum_posts_author ON public.forum_posts USING btree (author_id);


--
-- Name: idx_forum_posts_category; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_forum_posts_category ON public.forum_posts USING btree (category_id);


--
-- Name: idx_forum_posts_created; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_forum_posts_created ON public.forum_posts USING btree (created_at DESC);


--
-- Name: idx_forum_posts_scam; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_forum_posts_scam ON public.forum_posts USING btree (is_scam_report, scam_status);


--
-- Name: idx_forum_votes_post; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_forum_votes_post ON public.forum_votes USING btree (post_id);


--
-- Name: idx_fund_accounts_type; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_fund_accounts_type ON public.fund_separation_accounts USING btree (account_type);


--
-- Name: idx_generated_emails_provider; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_generated_emails_provider ON public.generated_emails USING btree (provider);


--
-- Name: idx_generated_emails_purpose; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_generated_emails_purpose ON public.generated_emails USING btree (purpose);


--
-- Name: idx_health_check_results_endpoint; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_health_check_results_endpoint ON public.health_check_results USING btree (endpoint_id);


--
-- Name: idx_health_check_results_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_health_check_results_status ON public.health_check_results USING btree (status);


--
-- Name: idx_health_check_results_timestamp; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_health_check_results_timestamp ON public.health_check_results USING btree ("timestamp");


--
-- Name: idx_historical_timelines_entity; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_historical_timelines_entity ON public.historical_timelines USING btree (entity_id, entity_type);


--
-- Name: idx_key_shares_wallet; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_key_shares_wallet ON public.key_shares USING btree (wallet_id);


--
-- Name: idx_legal_compliance_due_date; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_legal_compliance_due_date ON public.legal_compliance USING btree (due_date);


--
-- Name: idx_legal_compliance_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_legal_compliance_status ON public.legal_compliance USING btree (status);


--
-- Name: idx_legal_compliance_type; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_legal_compliance_type ON public.legal_compliance USING btree (check_type);


--
-- Name: idx_munchmaps_chain; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_munchmaps_chain ON public.munchmaps_scans USING btree (chain);


--
-- Name: idx_munchmaps_created_at; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_munchmaps_created_at ON public.munchmaps_scans USING btree (created_at);


--
-- Name: idx_munchmaps_user_id; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_munchmaps_user_id ON public.munchmaps_scans USING btree (user_id);


--
-- Name: idx_munchmaps_wallet; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_munchmaps_wallet ON public.munchmaps_scans USING btree (wallet_address);


--
-- Name: idx_munchmaps_wallet_type; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_munchmaps_wallet_type ON public.munchmaps_scans USING btree (wallet_type);


--
-- Name: idx_newsletter_subscribers_crm_v1; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_newsletter_subscribers_crm_v1 ON public.newsletter_subscribers USING btree (is_crm_v1_holder);


--
-- Name: idx_newsletter_subscribers_crm_v2; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_newsletter_subscribers_crm_v2 ON public.newsletter_subscribers USING btree (is_crm_v2_holder);


--
-- Name: idx_newsletter_subscribers_email; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_newsletter_subscribers_email ON public.newsletter_subscribers USING btree (email);


--
-- Name: idx_newsletter_subscribers_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_newsletter_subscribers_status ON public.newsletter_subscribers USING btree (status);


--
-- Name: idx_newsletter_subscribers_tier; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_newsletter_subscribers_tier ON public.newsletter_subscribers USING btree (tier);


--
-- Name: idx_notifications_user; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_notifications_user ON public.notifications USING btree (user_id, is_read, created_at DESC);


--
-- Name: idx_provisioned_accounts_pool; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_provisioned_accounts_pool ON public.provisioned_accounts USING btree (credential_pool_id);


--
-- Name: idx_provisioned_accounts_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_provisioned_accounts_status ON public.provisioned_accounts USING btree (status);


--
-- Name: idx_route_requests_endpoint; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_route_requests_endpoint ON public.route_requests USING btree (endpoint_id);


--
-- Name: idx_route_requests_group; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_route_requests_group ON public.route_requests USING btree (routing_group_id);


--
-- Name: idx_route_requests_success; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_route_requests_success ON public.route_requests USING btree (success);


--
-- Name: idx_route_requests_timestamp; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_route_requests_timestamp ON public.route_requests USING btree ("timestamp");


--
-- Name: idx_routing_alerts_created_at; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_routing_alerts_created_at ON public.routing_alerts USING btree (created_at);


--
-- Name: idx_routing_alerts_endpoint; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_routing_alerts_endpoint ON public.routing_alerts USING btree (endpoint_id);


--
-- Name: idx_routing_alerts_severity; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_routing_alerts_severity ON public.routing_alerts USING btree (severity);


--
-- Name: idx_routing_alerts_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_routing_alerts_status ON public.routing_alerts USING btree (status);


--
-- Name: idx_routing_analytics_hourly_group; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_routing_analytics_hourly_group ON public.routing_analytics_hourly USING btree (routing_group_id);


--
-- Name: idx_routing_analytics_hourly_time; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_routing_analytics_hourly_time ON public.routing_analytics_hourly USING btree (hour);


--
-- Name: idx_routing_group_endpoints_endpoint; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_routing_group_endpoints_endpoint ON public.routing_group_endpoints USING btree (endpoint_id);


--
-- Name: idx_routing_group_endpoints_group; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_routing_group_endpoints_group ON public.routing_group_endpoints USING btree (routing_group_id);


--
-- Name: idx_routing_rules_enabled; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_routing_rules_enabled ON public.routing_rules USING btree (enabled);


--
-- Name: idx_routing_rules_priority; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_routing_rules_priority ON public.routing_rules USING btree (priority);


--
-- Name: idx_security_alerts_severity; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_security_alerts_severity ON public.security_alerts USING btree (severity);


--
-- Name: idx_security_alerts_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_security_alerts_status ON public.security_alerts USING btree (status);


--
-- Name: idx_security_alerts_type; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_security_alerts_type ON public.security_alerts USING btree (alert_type);


--
-- Name: idx_security_alerts_wallet; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_security_alerts_wallet ON public.security_alerts USING btree (wallet_id);


--
-- Name: idx_stored_credentials_category; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_stored_credentials_category ON public.stored_credentials USING btree (service_category);


--
-- Name: idx_stored_credentials_service; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_stored_credentials_service ON public.stored_credentials USING btree (service_name);


--
-- Name: idx_stored_credentials_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_stored_credentials_status ON public.stored_credentials USING btree (status);


--
-- Name: idx_stored_credentials_type; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_stored_credentials_type ON public.stored_credentials USING btree (credential_type);


--
-- Name: idx_token_launches_platform; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_token_launches_platform ON public.token_launches USING btree (platform);


--
-- Name: idx_token_launches_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_token_launches_status ON public.token_launches USING btree (launch_status);


--
-- Name: idx_token_launches_symbol; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_token_launches_symbol ON public.token_launches USING btree (token_symbol);


--
-- Name: idx_transaction_requests_created; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_transaction_requests_created ON public.transaction_requests USING btree (created_at);


--
-- Name: idx_transaction_requests_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_transaction_requests_status ON public.transaction_requests USING btree (status);


--
-- Name: idx_transaction_requests_wallet; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_transaction_requests_wallet ON public.transaction_requests USING btree (wallet_id);


--
-- Name: idx_transactions_created_at; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_transactions_created_at ON public.transactions USING btree (created_at);


--
-- Name: idx_transactions_product; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_transactions_product ON public.transactions USING btree (product);


--
-- Name: idx_transactions_product_created; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_transactions_product_created ON public.transactions USING btree (product, created_at);


--
-- Name: idx_transactions_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_transactions_status ON public.transactions USING btree (status);


--
-- Name: idx_transactions_user_id; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_transactions_user_id ON public.transactions USING btree (user_id);


--
-- Name: idx_transition_milestones_phase; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_transition_milestones_phase ON public.transition_milestones USING btree (phase);


--
-- Name: idx_transition_milestones_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_transition_milestones_status ON public.transition_milestones USING btree (status);


--
-- Name: idx_trending_topics_platform; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_trending_topics_platform ON public.trending_topics USING btree (platform);


--
-- Name: idx_trending_topics_score; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_trending_topics_score ON public.trending_topics USING btree (trend_score);


--
-- Name: idx_user_badges_badge_id; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_user_badges_badge_id ON public.user_badges USING btree (badge_id);


--
-- Name: idx_user_badges_earned_at; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_user_badges_earned_at ON public.user_badges USING btree (earned_at DESC);


--
-- Name: idx_user_badges_user_id; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_user_badges_user_id ON public.user_badges USING btree (user_id);


--
-- Name: idx_user_stats_total_xp; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_user_stats_total_xp ON public.user_stats USING btree (total_xp DESC);


--
-- Name: idx_user_stats_user_id; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_user_stats_user_id ON public.user_stats USING btree (user_id);


--
-- Name: idx_users_created_at; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_users_created_at ON public.users USING btree (created_at);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_is_admin; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_users_is_admin ON public.users USING btree (is_admin);


--
-- Name: idx_users_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_users_status ON public.users USING btree (status);


--
-- Name: idx_wallet_rotations_old_wallet; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_wallet_rotations_old_wallet ON public.wallet_rotations USING btree (old_wallet_id);


--
-- Name: idx_wallet_rotations_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_wallet_rotations_status ON public.wallet_rotations USING btree (status);


--
-- Name: idx_website_pages_project; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_website_pages_project ON public.website_pages USING btree (project_id);


--
-- Name: idx_website_pages_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_website_pages_status ON public.website_pages USING btree (status);


--
-- Name: idx_website_projects_status; Type: INDEX; Schema: public; Owner: rmi_user
--

CREATE INDEX idx_website_projects_status ON public.website_projects USING btree (status);


--
-- Name: forum_comments trigger_update_comment_count; Type: TRIGGER; Schema: public; Owner: rmi_user
--

CREATE TRIGGER trigger_update_comment_count AFTER INSERT OR UPDATE ON public.forum_comments FOR EACH ROW EXECUTE FUNCTION public.update_post_comment_count();


--
-- Name: api_endpoints update_api_endpoints_updated_at; Type: TRIGGER; Schema: public; Owner: rmi_user
--

CREATE TRIGGER update_api_endpoints_updated_at BEFORE UPDATE ON public.api_endpoints FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: badges update_badges_updated_at; Type: TRIGGER; Schema: public; Owner: rmi_user
--

CREATE TRIGGER update_badges_updated_at BEFORE UPDATE ON public.badges FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: ban_prevention_configs update_ban_prevention_configs_updated_at; Type: TRIGGER; Schema: public; Owner: rmi_user
--

CREATE TRIGGER update_ban_prevention_configs_updated_at BEFORE UPDATE ON public.ban_prevention_configs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: credential_pools update_credential_pools_updated_at; Type: TRIGGER; Schema: public; Owner: rmi_user
--

CREATE TRIGGER update_credential_pools_updated_at BEFORE UPDATE ON public.credential_pools FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: dashboard_configs update_dashboard_configs_updated_at; Type: TRIGGER; Schema: public; Owner: rmi_user
--

CREATE TRIGGER update_dashboard_configs_updated_at BEFORE UPDATE ON public.dashboard_configs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: education_content update_education_content_updated_at; Type: TRIGGER; Schema: public; Owner: rmi_user
--

CREATE TRIGGER update_education_content_updated_at BEFORE UPDATE ON public.education_content FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: forum_comments update_forum_comments_updated_at; Type: TRIGGER; Schema: public; Owner: rmi_user
--

CREATE TRIGGER update_forum_comments_updated_at BEFORE UPDATE ON public.forum_comments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: forum_posts update_forum_posts_updated_at; Type: TRIGGER; Schema: public; Owner: rmi_user
--

CREATE TRIGGER update_forum_posts_updated_at BEFORE UPDATE ON public.forum_posts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: notification_configs update_notification_configs_updated_at; Type: TRIGGER; Schema: public; Owner: rmi_user
--

CREATE TRIGGER update_notification_configs_updated_at BEFORE UPDATE ON public.notification_configs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: routing_groups update_routing_groups_updated_at; Type: TRIGGER; Schema: public; Owner: rmi_user
--

CREATE TRIGGER update_routing_groups_updated_at BEFORE UPDATE ON public.routing_groups FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: routing_rules update_routing_rules_updated_at; Type: TRIGGER; Schema: public; Owner: rmi_user
--

CREATE TRIGGER update_routing_rules_updated_at BEFORE UPDATE ON public.routing_rules FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: rmi_user
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: access_logs access_logs_performed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.access_logs
    ADD CONSTRAINT access_logs_performed_by_fkey FOREIGN KEY (performed_by) REFERENCES public.users(id);


--
-- Name: access_logs access_logs_tx_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.access_logs
    ADD CONSTRAINT access_logs_tx_request_id_fkey FOREIGN KEY (tx_request_id) REFERENCES public.transaction_requests(id);


--
-- Name: access_logs access_logs_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.access_logs
    ADD CONSTRAINT access_logs_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.encrypted_wallets(id);


--
-- Name: admin_logs admin_logs_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.admin_logs
    ADD CONSTRAINT admin_logs_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.users(id);


--
-- Name: admin_recovery_requests admin_recovery_requests_initiated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.admin_recovery_requests
    ADD CONSTRAINT admin_recovery_requests_initiated_by_fkey FOREIGN KEY (initiated_by) REFERENCES public.users(id);


--
-- Name: ai_website_requests ai_website_requests_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.ai_website_requests
    ADD CONSTRAINT ai_website_requests_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: ai_website_requests ai_website_requests_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.ai_website_requests
    ADD CONSTRAINT ai_website_requests_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.website_projects(id);


--
-- Name: ai_website_results ai_website_results_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.ai_website_results
    ADD CONSTRAINT ai_website_results_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.ai_website_requests(id);


--
-- Name: airdrop_eligible_wallets airdrop_eligible_wallets_claimed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.airdrop_eligible_wallets
    ADD CONSTRAINT airdrop_eligible_wallets_claimed_by_fkey FOREIGN KEY (claimed_by) REFERENCES public.users(id);


--
-- Name: api_credential_updates api_credential_updates_credential_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.api_credential_updates
    ADD CONSTRAINT api_credential_updates_credential_id_fkey FOREIGN KEY (credential_id) REFERENCES public.stored_credentials(id);


--
-- Name: api_credential_updates api_credential_updates_initiated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.api_credential_updates
    ADD CONSTRAINT api_credential_updates_initiated_by_fkey FOREIGN KEY (initiated_by) REFERENCES public.users(id);


--
-- Name: api_endpoints api_endpoints_parent_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.api_endpoints
    ADD CONSTRAINT api_endpoints_parent_endpoint_id_fkey FOREIGN KEY (parent_endpoint_id) REFERENCES public.api_endpoints(id);


--
-- Name: api_logs api_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.api_logs
    ADD CONSTRAINT api_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: badge_progress badge_progress_badge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.badge_progress
    ADD CONSTRAINT badge_progress_badge_id_fkey FOREIGN KEY (badge_id) REFERENCES public.badges(id) ON DELETE CASCADE;


--
-- Name: badge_unlock_log badge_unlock_log_badge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.badge_unlock_log
    ADD CONSTRAINT badge_unlock_log_badge_id_fkey FOREIGN KEY (badge_id) REFERENCES public.badges(id) ON DELETE CASCADE;


--
-- Name: badges badges_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.badges
    ADD CONSTRAINT badges_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.badge_categories(id);


--
-- Name: bot_advisor_insights bot_advisor_insights_acknowledged_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.bot_advisor_insights
    ADD CONSTRAINT bot_advisor_insights_acknowledged_by_fkey FOREIGN KEY (acknowledged_by) REFERENCES public.users(id);


--
-- Name: bot_logs bot_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.bot_logs
    ADD CONSTRAINT bot_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: compliance_requirements compliance_requirements_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.compliance_requirements
    ADD CONSTRAINT compliance_requirements_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: content_performance content_performance_content_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.content_performance
    ADD CONSTRAINT content_performance_content_id_fkey FOREIGN KEY (content_id) REFERENCES public.content_pieces(id);


--
-- Name: content_pieces content_pieces_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.content_pieces
    ADD CONSTRAINT content_pieces_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: content_pieces content_pieces_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.content_pieces
    ADD CONSTRAINT content_pieces_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: contract_deployments contract_deployments_deployed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.contract_deployments
    ADD CONSTRAINT contract_deployments_deployed_by_fkey FOREIGN KEY (deployed_by) REFERENCES public.users(id);


--
-- Name: credential_access_logs credential_access_logs_credential_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.credential_access_logs
    ADD CONSTRAINT credential_access_logs_credential_id_fkey FOREIGN KEY (credential_id) REFERENCES public.stored_credentials(id);


--
-- Name: credential_access_logs credential_access_logs_performed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.credential_access_logs
    ADD CONSTRAINT credential_access_logs_performed_by_fkey FOREIGN KEY (performed_by) REFERENCES public.users(id);


--
-- Name: credential_pool_credentials credential_pool_credentials_pool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.credential_pool_credentials
    ADD CONSTRAINT credential_pool_credentials_pool_id_fkey FOREIGN KEY (pool_id) REFERENCES public.credential_pools(id) ON DELETE CASCADE;


--
-- Name: critical_alerts critical_alerts_acknowledged_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.critical_alerts
    ADD CONSTRAINT critical_alerts_acknowledged_by_fkey FOREIGN KEY (acknowledged_by) REFERENCES public.users(id);


--
-- Name: critical_alerts critical_alerts_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.critical_alerts
    ADD CONSTRAINT critical_alerts_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: crm_staking crm_staking_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.crm_staking
    ADD CONSTRAINT crm_staking_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: crm_v1_wallets crm_v1_wallets_verified_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.crm_v1_wallets
    ADD CONSTRAINT crm_v1_wallets_verified_by_fkey FOREIGN KEY (verified_by) REFERENCES public.users(id);


--
-- Name: cross_checks cross_checks_checked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.cross_checks
    ADD CONSTRAINT cross_checks_checked_by_fkey FOREIGN KEY (checked_by) REFERENCES public.users(id);


--
-- Name: cross_checks cross_checks_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.cross_checks
    ADD CONSTRAINT cross_checks_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.crm_v1_wallets(id) ON DELETE CASCADE;


--
-- Name: dao_proposals dao_proposals_executed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.dao_proposals
    ADD CONSTRAINT dao_proposals_executed_by_fkey FOREIGN KEY (executed_by) REFERENCES public.users(id);


--
-- Name: dao_proposals dao_proposals_proposer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.dao_proposals
    ADD CONSTRAINT dao_proposals_proposer_fkey FOREIGN KEY (proposer) REFERENCES public.users(id);


--
-- Name: design_revisions design_revisions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.design_revisions
    ADD CONSTRAINT design_revisions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: design_revisions design_revisions_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.design_revisions
    ADD CONSTRAINT design_revisions_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.website_pages(id) ON DELETE CASCADE;


--
-- Name: design_revisions design_revisions_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.design_revisions
    ADD CONSTRAINT design_revisions_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: discount_code_usage discount_code_usage_code_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.discount_code_usage
    ADD CONSTRAINT discount_code_usage_code_id_fkey FOREIGN KEY (code_id) REFERENCES public.discount_codes(id) ON DELETE CASCADE;


--
-- Name: discount_code_usage discount_code_usage_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.discount_code_usage
    ADD CONSTRAINT discount_code_usage_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: discount_codes discount_codes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.discount_codes
    ADD CONSTRAINT discount_codes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: discount_codes discount_codes_eligible_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.discount_codes
    ADD CONSTRAINT discount_codes_eligible_wallet_id_fkey FOREIGN KEY (eligible_wallet_id) REFERENCES public.airdrop_eligible_wallets(id);


--
-- Name: education_bookmarks education_bookmarks_content_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.education_bookmarks
    ADD CONSTRAINT education_bookmarks_content_id_fkey FOREIGN KEY (content_id) REFERENCES public.education_content(id) ON DELETE CASCADE;


--
-- Name: education_bookmarks education_bookmarks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.education_bookmarks
    ADD CONSTRAINT education_bookmarks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: education_content education_content_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.education_content
    ADD CONSTRAINT education_content_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: education_content education_content_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.education_content
    ADD CONSTRAINT education_content_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.education_categories(id) ON DELETE SET NULL;


--
-- Name: education_content education_content_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.education_content
    ADD CONSTRAINT education_content_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: education_likes education_likes_content_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.education_likes
    ADD CONSTRAINT education_likes_content_id_fkey FOREIGN KEY (content_id) REFERENCES public.education_content(id) ON DELETE CASCADE;


--
-- Name: education_likes education_likes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.education_likes
    ADD CONSTRAINT education_likes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: education_progress education_progress_content_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.education_progress
    ADD CONSTRAINT education_progress_content_id_fkey FOREIGN KEY (content_id) REFERENCES public.education_content(id) ON DELETE CASCADE;


--
-- Name: education_progress education_progress_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.education_progress
    ADD CONSTRAINT education_progress_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: encrypted_wallets encrypted_wallets_last_accessed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.encrypted_wallets
    ADD CONSTRAINT encrypted_wallets_last_accessed_by_fkey FOREIGN KEY (last_accessed_by) REFERENCES public.users(id);


--
-- Name: final_investigations final_investigations_lead_investigator_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.final_investigations
    ADD CONSTRAINT final_investigations_lead_investigator_fkey FOREIGN KEY (lead_investigator) REFERENCES public.users(id);


--
-- Name: forum_categories forum_categories_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_categories
    ADD CONSTRAINT forum_categories_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: forum_comment_votes forum_comment_votes_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_comment_votes
    ADD CONSTRAINT forum_comment_votes_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.forum_comments(id) ON DELETE CASCADE;


--
-- Name: forum_comment_votes forum_comment_votes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_comment_votes
    ADD CONSTRAINT forum_comment_votes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forum_comments forum_comments_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_comments
    ADD CONSTRAINT forum_comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: forum_comments forum_comments_parent_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_comments
    ADD CONSTRAINT forum_comments_parent_comment_id_fkey FOREIGN KEY (parent_comment_id) REFERENCES public.forum_comments(id) ON DELETE CASCADE;


--
-- Name: forum_comments forum_comments_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_comments
    ADD CONSTRAINT forum_comments_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.forum_posts(id) ON DELETE CASCADE;


--
-- Name: forum_posts forum_posts_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: forum_posts forum_posts_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.forum_categories(id) ON DELETE CASCADE;


--
-- Name: forum_subscriptions forum_subscriptions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_subscriptions
    ADD CONSTRAINT forum_subscriptions_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.forum_categories(id) ON DELETE CASCADE;


--
-- Name: forum_subscriptions forum_subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_subscriptions
    ADD CONSTRAINT forum_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forum_votes forum_votes_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_votes
    ADD CONSTRAINT forum_votes_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.forum_posts(id) ON DELETE CASCADE;


--
-- Name: forum_votes forum_votes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.forum_votes
    ADD CONSTRAINT forum_votes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: generated_emails generated_emails_password_credential_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.generated_emails
    ADD CONSTRAINT generated_emails_password_credential_id_fkey FOREIGN KEY (password_credential_id) REFERENCES public.stored_credentials(id);


--
-- Name: health_check_results health_check_results_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.health_check_results
    ADD CONSTRAINT health_check_results_endpoint_id_fkey FOREIGN KEY (endpoint_id) REFERENCES public.api_endpoints(id) ON DELETE CASCADE;


--
-- Name: investigation_findings investigation_findings_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.investigation_findings
    ADD CONSTRAINT investigation_findings_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: investigation_findings investigation_findings_investigation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.investigation_findings
    ADD CONSTRAINT investigation_findings_investigation_id_fkey FOREIGN KEY (investigation_id) REFERENCES public.final_investigations(id);


--
-- Name: key_shares key_shares_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.key_shares
    ADD CONSTRAINT key_shares_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.encrypted_wallets(id) ON DELETE CASCADE;


--
-- Name: launch_failure_analyses launch_failure_analyses_investigated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.launch_failure_analyses
    ADD CONSTRAINT launch_failure_analyses_investigated_by_fkey FOREIGN KEY (investigated_by) REFERENCES public.users(id);


--
-- Name: launch_failure_analyses launch_failure_analyses_token_launch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.launch_failure_analyses
    ADD CONSTRAINT launch_failure_analyses_token_launch_id_fkey FOREIGN KEY (token_launch_id) REFERENCES public.token_launches(id);


--
-- Name: legal_compliance legal_compliance_verified_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.legal_compliance
    ADD CONSTRAINT legal_compliance_verified_by_fkey FOREIGN KEY (verified_by) REFERENCES public.users(id);


--
-- Name: munchmaps_scans munchmaps_scans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.munchmaps_scans
    ADD CONSTRAINT munchmaps_scans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: newsletter_campaigns newsletter_campaigns_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.newsletter_campaigns
    ADD CONSTRAINT newsletter_campaigns_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: notifications notifications_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: password_parts password_parts_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.password_parts
    ADD CONSTRAINT password_parts_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.encrypted_wallets(id) ON DELETE CASCADE;


--
-- Name: platform_infiltrations platform_infiltrations_token_launch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.platform_infiltrations
    ADD CONSTRAINT platform_infiltrations_token_launch_id_fkey FOREIGN KEY (token_launch_id) REFERENCES public.token_launches(id);


--
-- Name: provisioned_accounts provisioned_accounts_credential_pool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.provisioned_accounts
    ADD CONSTRAINT provisioned_accounts_credential_pool_id_fkey FOREIGN KEY (credential_pool_id) REFERENCES public.credential_pools(id);


--
-- Name: provisioned_accounts provisioned_accounts_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.provisioned_accounts
    ADD CONSTRAINT provisioned_accounts_endpoint_id_fkey FOREIGN KEY (endpoint_id) REFERENCES public.api_endpoints(id);


--
-- Name: provisioned_accounts provisioned_accounts_triggered_by_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.provisioned_accounts
    ADD CONSTRAINT provisioned_accounts_triggered_by_endpoint_id_fkey FOREIGN KEY (triggered_by_endpoint_id) REFERENCES public.api_endpoints(id);


--
-- Name: route_requests route_requests_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.route_requests
    ADD CONSTRAINT route_requests_endpoint_id_fkey FOREIGN KEY (endpoint_id) REFERENCES public.api_endpoints(id);


--
-- Name: route_requests route_requests_routing_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.route_requests
    ADD CONSTRAINT route_requests_routing_group_id_fkey FOREIGN KEY (routing_group_id) REFERENCES public.routing_groups(id);


--
-- Name: routing_alerts routing_alerts_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.routing_alerts
    ADD CONSTRAINT routing_alerts_endpoint_id_fkey FOREIGN KEY (endpoint_id) REFERENCES public.api_endpoints(id);


--
-- Name: routing_alerts routing_alerts_routing_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.routing_alerts
    ADD CONSTRAINT routing_alerts_routing_group_id_fkey FOREIGN KEY (routing_group_id) REFERENCES public.routing_groups(id);


--
-- Name: routing_analytics_hourly routing_analytics_hourly_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.routing_analytics_hourly
    ADD CONSTRAINT routing_analytics_hourly_endpoint_id_fkey FOREIGN KEY (endpoint_id) REFERENCES public.api_endpoints(id);


--
-- Name: routing_analytics_hourly routing_analytics_hourly_routing_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.routing_analytics_hourly
    ADD CONSTRAINT routing_analytics_hourly_routing_group_id_fkey FOREIGN KEY (routing_group_id) REFERENCES public.routing_groups(id);


--
-- Name: routing_group_endpoints routing_group_endpoints_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.routing_group_endpoints
    ADD CONSTRAINT routing_group_endpoints_endpoint_id_fkey FOREIGN KEY (endpoint_id) REFERENCES public.api_endpoints(id) ON DELETE CASCADE;


--
-- Name: routing_group_endpoints routing_group_endpoints_routing_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.routing_group_endpoints
    ADD CONSTRAINT routing_group_endpoints_routing_group_id_fkey FOREIGN KEY (routing_group_id) REFERENCES public.routing_groups(id) ON DELETE CASCADE;


--
-- Name: routing_rules routing_rules_target_routing_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.routing_rules
    ADD CONSTRAINT routing_rules_target_routing_group_id_fkey FOREIGN KEY (target_routing_group_id) REFERENCES public.routing_groups(id);


--
-- Name: security_alerts security_alerts_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.security_alerts
    ADD CONSTRAINT security_alerts_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: security_alerts security_alerts_tx_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.security_alerts
    ADD CONSTRAINT security_alerts_tx_request_id_fkey FOREIGN KEY (tx_request_id) REFERENCES public.transaction_requests(id);


--
-- Name: security_alerts security_alerts_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.security_alerts
    ADD CONSTRAINT security_alerts_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.encrypted_wallets(id);


--
-- Name: stored_credentials stored_credentials_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.stored_credentials
    ADD CONSTRAINT stored_credentials_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: stored_credentials stored_credentials_last_accessed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.stored_credentials
    ADD CONSTRAINT stored_credentials_last_accessed_by_fkey FOREIGN KEY (last_accessed_by) REFERENCES public.users(id);


--
-- Name: system_alerts system_alerts_acknowledged_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.system_alerts
    ADD CONSTRAINT system_alerts_acknowledged_by_fkey FOREIGN KEY (acknowledged_by) REFERENCES public.users(id);


--
-- Name: system_alerts system_alerts_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.system_alerts
    ADD CONSTRAINT system_alerts_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: system_config system_config_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: token_holder_snapshots token_holder_snapshots_token_launch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.token_holder_snapshots
    ADD CONSTRAINT token_holder_snapshots_token_launch_id_fkey FOREIGN KEY (token_launch_id) REFERENCES public.token_launches(id);


--
-- Name: transaction_requests transaction_requests_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.transaction_requests
    ADD CONSTRAINT transaction_requests_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: transaction_requests transaction_requests_executed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.transaction_requests
    ADD CONSTRAINT transaction_requests_executed_by_fkey FOREIGN KEY (executed_by) REFERENCES public.users(id);


--
-- Name: transaction_requests transaction_requests_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.transaction_requests
    ADD CONSTRAINT transaction_requests_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.encrypted_wallets(id);


--
-- Name: transactions transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: transition_milestones transition_milestones_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.transition_milestones
    ADD CONSTRAINT transition_milestones_owner_fkey FOREIGN KEY (owner) REFERENCES public.users(id);


--
-- Name: transition_reports transition_reports_generated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.transition_reports
    ADD CONSTRAINT transition_reports_generated_by_fkey FOREIGN KEY (generated_by) REFERENCES public.users(id);


--
-- Name: user_activity user_activity_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.user_activity
    ADD CONSTRAINT user_activity_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_badges user_badges_badge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_badge_id_fkey FOREIGN KEY (badge_id) REFERENCES public.badges(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_social_connections user_social_connections_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.user_social_connections
    ADD CONSTRAINT user_social_connections_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_le_verified_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_le_verified_by_fkey FOREIGN KEY (le_verified_by) REFERENCES public.users(id);


--
-- Name: users users_suspended_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_suspended_by_fkey FOREIGN KEY (suspended_by) REFERENCES public.users(id);


--
-- Name: wallet_rotations wallet_rotations_initiated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.wallet_rotations
    ADD CONSTRAINT wallet_rotations_initiated_by_fkey FOREIGN KEY (initiated_by) REFERENCES public.users(id);


--
-- Name: wallet_rotations wallet_rotations_new_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.wallet_rotations
    ADD CONSTRAINT wallet_rotations_new_wallet_id_fkey FOREIGN KEY (new_wallet_id) REFERENCES public.encrypted_wallets(id);


--
-- Name: wallet_rotations wallet_rotations_old_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.wallet_rotations
    ADD CONSTRAINT wallet_rotations_old_wallet_id_fkey FOREIGN KEY (old_wallet_id) REFERENCES public.encrypted_wallets(id);


--
-- Name: wallet_verification_attempts wallet_verification_attempts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.wallet_verification_attempts
    ADD CONSTRAINT wallet_verification_attempts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: website_pages website_pages_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.website_pages
    ADD CONSTRAINT website_pages_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.website_projects(id) ON DELETE CASCADE;


--
-- Name: website_projects website_projects_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rmi_user
--

ALTER TABLE ONLY public.website_projects
    ADD CONSTRAINT website_projects_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: admin_logs admin_log_policy; Type: POLICY; Schema: public; Owner: rmi_user
--

CREATE POLICY admin_log_policy ON public.admin_logs USING ((current_setting('app.is_admin'::text))::boolean);


--
-- Name: admin_logs; Type: ROW SECURITY; Schema: public; Owner: rmi_user
--

ALTER TABLE public.admin_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: api_endpoints; Type: ROW SECURITY; Schema: public; Owner: rmi_user
--

ALTER TABLE public.api_endpoints ENABLE ROW LEVEL SECURITY;

--
-- Name: api_logs api_log_isolation; Type: POLICY; Schema: public; Owner: rmi_user
--

CREATE POLICY api_log_isolation ON public.api_logs USING (((user_id = (current_setting('app.current_user_id'::text))::uuid) OR (current_setting('app.is_admin'::text))::boolean));


--
-- Name: api_logs; Type: ROW SECURITY; Schema: public; Owner: rmi_user
--

ALTER TABLE public.api_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: credential_pools; Type: ROW SECURITY; Schema: public; Owner: rmi_user
--

ALTER TABLE public.credential_pools ENABLE ROW LEVEL SECURITY;

--
-- Name: encrypted_wallets; Type: ROW SECURITY; Schema: public; Owner: rmi_user
--

ALTER TABLE public.encrypted_wallets ENABLE ROW LEVEL SECURITY;

--
-- Name: key_shares; Type: ROW SECURITY; Schema: public; Owner: rmi_user
--

ALTER TABLE public.key_shares ENABLE ROW LEVEL SECURITY;

--
-- Name: key_shares key_shares_admin_only; Type: POLICY; Schema: public; Owner: rmi_user
--

CREATE POLICY key_shares_admin_only ON public.key_shares USING ((current_setting('app.is_admin'::text))::boolean);


--
-- Name: password_parts; Type: ROW SECURITY; Schema: public; Owner: rmi_user
--

ALTER TABLE public.password_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: password_parts password_parts_admin_only; Type: POLICY; Schema: public; Owner: rmi_user
--

CREATE POLICY password_parts_admin_only ON public.password_parts USING ((current_setting('app.is_admin'::text))::boolean);


--
-- Name: route_requests; Type: ROW SECURITY; Schema: public; Owner: rmi_user
--

ALTER TABLE public.route_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: routing_alerts; Type: ROW SECURITY; Schema: public; Owner: rmi_user
--

ALTER TABLE public.routing_alerts ENABLE ROW LEVEL SECURITY;

--
-- Name: routing_groups; Type: ROW SECURITY; Schema: public; Owner: rmi_user
--

ALTER TABLE public.routing_groups ENABLE ROW LEVEL SECURITY;

--
-- Name: transactions transaction_isolation; Type: POLICY; Schema: public; Owner: rmi_user
--

CREATE POLICY transaction_isolation ON public.transactions USING (((user_id = (current_setting('app.current_user_id'::text))::uuid) OR (current_setting('app.is_admin'::text))::boolean));


--
-- Name: transaction_requests; Type: ROW SECURITY; Schema: public; Owner: rmi_user
--

ALTER TABLE public.transaction_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: transactions; Type: ROW SECURITY; Schema: public; Owner: rmi_user
--

ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: transaction_requests transactions_admin_only; Type: POLICY; Schema: public; Owner: rmi_user
--

CREATE POLICY transactions_admin_only ON public.transaction_requests USING ((current_setting('app.is_admin'::text))::boolean);


--
-- Name: users user_isolation; Type: POLICY; Schema: public; Owner: rmi_user
--

CREATE POLICY user_isolation ON public.users USING (((id = (current_setting('app.current_user_id'::text))::uuid) OR (current_setting('app.is_admin'::text))::boolean));


--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: rmi_user
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: encrypted_wallets wallet_admin_only; Type: POLICY; Schema: public; Owner: rmi_user
--

CREATE POLICY wallet_admin_only ON public.encrypted_wallets USING ((current_setting('app.is_admin'::text))::boolean);


--
-- PostgreSQL database dump complete
--

\unrestrict IxEfzzDWRWMK8dTs3YfXUNth6wmW8CNjkazBGwaGoVzqz2PSNQZIFFQGWyomfwD

